chetchiki 2.58

Fixes 2.57 build error:
- Added missing electricityReportPrepareLoginScript(job) function referenced by MainActivity.kt.
- The script fills electricity cabinet login fields only and does NOT automatically submit the login form, so CAPTCHA remains available for manual completion.
- versionCode 258, versionName 2.58.
- Based on 2.57.
