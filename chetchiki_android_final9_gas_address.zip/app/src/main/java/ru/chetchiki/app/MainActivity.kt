@file:OptIn(ExperimentalMaterial3Api::class)
package ru.chetchiki.app

import android.annotation.SuppressLint
import android.content.Context
import android.os.Bundle
import android.webkit.WebView
import android.webkit.WebViewClient
import android.webkit.WebChromeClient
import org.json.JSONObject
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.viewinterop.AndroidView

enum class MeterType { ELECTRICITY, WATER, GAS }

data class Meter(
    val id: Int,
    val type: MeterType,
    val title: String,
    val serial: String = "",
    val reading: String = "",
    val status: String = "Не передано"
)

data class Apartment(val id: Int, val address: String, val meters: List<Meter>)

data class Credentials(
    val energySurname: String = "",
    val energyAccount: String = "",
    val energySerial: String = "",
    val waterLogin: String = "",
    val waterPassword: String = "",
    val gasLogin: String = "",
    val gasPassword: String = ""
)

data class Job(
    val apartmentId: Int,
    val address: String,
    val meterId: Int,
    val type: MeterType,
    val title: String,
    val reading: String,
    val serial: String = "",
    val credentials: Credentials = Credentials()
)

private const val ENERGY = "https://sevenergosbyt.ru/flk/index.php"
private const val WATER = "https://sevvodokanal.org.ru/pages/licevoy"
private const val GAS = "https://lk.gup-sevgaz.ru:8443/irb/login.xhtml"

private fun defaultApartments() = listOf(
    Apartment(1, "Адрес квартиры 1", listOf(
        Meter(1, MeterType.ELECTRICITY, "Электричество"), Meter(2, MeterType.WATER, "Вода №1"), Meter(3, MeterType.WATER, "Вода №2"), Meter(4, MeterType.GAS, "Газ")
    )),
    Apartment(2, "Адрес квартиры 2", listOf(
        Meter(5, MeterType.ELECTRICITY, "Электричество"), Meter(6, MeterType.WATER, "Вода"), Meter(7, MeterType.GAS, "Газ")
    )),
    Apartment(3, "Адрес квартиры 3", listOf(
        Meter(8, MeterType.ELECTRICITY, "Электричество"), Meter(9, MeterType.WATER, "Вода"), Meter(10, MeterType.GAS, "Газ")
    )),
    Apartment(4, "Адрес квартиры 4", listOf(
        Meter(11, MeterType.ELECTRICITY, "Электричество"), Meter(12, MeterType.WATER, "Вода №1"), Meter(13, MeterType.WATER, "Вода №2")
    ))
)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { MeterApp(applicationContext) }
    }
}

private class LocalStore(context: Context) {
    private val p = context.getSharedPreferences("meter_store", Context.MODE_PRIVATE)
    fun get(k: String, d: String = "") = p.getString(k, d) ?: d
    fun put(k: String, v: String) { p.edit().putString(k, v).apply() }
    fun credentials(id: Int) = Credentials(
        get("energy_surname_$id"), get("energy_account_$id"), get("energy_serial_$id"),
        get("water_login_$id"), get("water_password_$id"), get("gas_login_$id"), get("gas_password_$id")
    )
}

@Composable
fun MeterApp(context: Context) {
    val store = remember { LocalStore(context) }
    var apartments by remember {
        mutableStateOf(defaultApartments().map { a -> a.copy(address = store.get("address_${a.id}", a.address), meters = a.meters.map { m -> m.copy(serial = store.get("serial_${m.id}"), reading = store.get("reading_${m.id}")) }) })
    }
    var credentialsVersion by remember { mutableIntStateOf(0) }
    var jobs by remember { mutableStateOf(listOf<Job>()) }
    var activeJobIndex by remember { mutableIntStateOf(0) }
    var webUrl by remember { mutableStateOf<String?>(null) }
    var webViewRef by remember { mutableStateOf<WebView?>(null) }
    var settings by remember { mutableStateOf(false) }

    fun updateMeter(apartmentId: Int, meterId: Int, reading: String? = null, serial: String? = null, status: String? = null) {
        apartments = apartments.map { a -> if (a.id != apartmentId) a else a.copy(meters = a.meters.map { m -> if (m.id != meterId) m else m.copy(reading = reading ?: m.reading, serial = serial ?: m.serial, status = status ?: m.status) }) }
        if (reading != null) store.put("reading_$meterId", reading)
        if (serial != null) store.put("serial_$meterId", serial)
    }
    fun updateStatus(job: Job, status: String) = updateMeter(job.apartmentId, job.meterId, status = status)
    fun makeJob(a: Apartment, m: Meter) = Job(a.id, a.address, m.id, m.type, m.title, m.reading, m.serial, store.credentials(a.id))
    fun startJobs(newJobs: List<Job>) { if (newJobs.isNotEmpty()) { jobs = newJobs; activeJobIndex = 0; webUrl = providerUrl(newJobs[0].type) } }
    fun nextJob() { val next = activeJobIndex + 1; if (next >= jobs.size) { webUrl = null } else { activeJobIndex = next; webUrl = providerUrl(jobs[next].type) } }

    if (settings) {
        SettingsScreen(
            apartments = apartments,
            store = store,
            onUpdateAddress = { id, value -> apartments = apartments.map { if (it.id == id) it.copy(address = value) else it }; store.put("address_$id", value) },
            onUpdateSerial = { id, value -> apartments = apartments.map { a -> a.copy(meters = a.meters.map { m -> if (m.id == id) m.copy(serial = value) else m }) }; store.put("serial_$id", value) },
            onSaved = { credentialsVersion++ },
            onBack = { settings = false }
        )
        return
    }

    if (webUrl != null && jobs.isNotEmpty()) {
        val job = jobs[activeJobIndex]
        ProviderScreen(url = webUrl!!, job = job, index = activeJobIndex + 1, total = jobs.size, onWebViewReady = { webViewRef = it }, onStatus = { updateStatus(job, it) }, onNext = { nextJob() }, onBack = { webUrl = null })
        return
    }

    Scaffold(topBar = { TopAppBar(title = { Text("Счётчики") }, actions = { TextButton({ settings = true }) { Text("Настройки") } }) }, bottomBar = {
        Button(onClick = { startJobs(apartments.flatMap { a -> a.meters.filter { it.reading.isNotBlank() }.map { makeJob(a, it) } }) }, modifier = Modifier.fillMaxWidth().padding(12.dp)) { Text("Передать всё — все квартиры") }
    }) { padding ->
        LazyColumn(Modifier.padding(padding).padding(12.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            items(apartments, key = { it.id }) { apartment ->
                Card(Modifier.fillMaxWidth()) { Column(Modifier.padding(12.dp)) {
                    Text(apartment.address, style = MaterialTheme.typography.titleMedium)
                    Spacer(Modifier.height(8.dp))
                    apartment.meters.forEach { meter ->
                        OutlinedTextField(value = meter.reading, onValueChange = { v -> updateMeter(apartment.id, meter.id, reading = v, status = "Не передано") }, label = { Text("${meter.title} — показание") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text(meter.status)
                            TextButton({ startJobs(listOf(makeJob(apartment, meter))) }) { Text("Передать") }
                        }
                    }
                    Button(onClick = { startJobs(apartment.meters.filter { it.reading.isNotBlank() }.map { makeJob(apartment, it) }) }, Modifier.fillMaxWidth()) { Text("Передать показания этой квартиры") }
                } }
            }
        }
    }
    @Suppress("UNUSED_VARIABLE") val _keep = credentialsVersion
}

@Composable
private fun SettingsScreen(apartments: List<Apartment>, store: LocalStore, onUpdateAddress: (Int, String) -> Unit, onUpdateSerial: (Int, String) -> Unit, onSaved: () -> Unit, onBack: () -> Unit) {
    var selectedId by remember { mutableIntStateOf(1) }
    val a = apartments.first { it.id == selectedId }
    var address by remember(selectedId) { mutableStateOf(a.address) }
    var energySurname by remember(selectedId) { mutableStateOf(store.get("energy_surname_$selectedId")) }
    var energyAccount by remember(selectedId) { mutableStateOf(store.get("energy_account_$selectedId")) }
    var energySerial by remember(selectedId) { mutableStateOf(store.get("energy_serial_$selectedId")) }
    var waterLogin by remember(selectedId) { mutableStateOf(store.get("water_login_$selectedId")) }
    var waterPassword by remember(selectedId) { mutableStateOf(store.get("water_password_$selectedId")) }
    var gasLogin by remember(selectedId) { mutableStateOf(store.get("gas_login_$selectedId")) }
    var gasPassword by remember(selectedId) { mutableStateOf(store.get("gas_password_$selectedId")) }

    fun save() {
        onUpdateAddress(selectedId, address)
        store.put("address_$selectedId", address)
        store.put("energy_surname_$selectedId", energySurname); store.put("energy_account_$selectedId", energyAccount); store.put("energy_serial_$selectedId", energySerial)
        store.put("water_login_$selectedId", waterLogin); store.put("water_password_$selectedId", waterPassword); store.put("gas_login_$selectedId", gasLogin); store.put("gas_password_$selectedId", gasPassword)
        a.meters.forEach { m -> if (m.type == MeterType.ELECTRICITY && energySerial.isNotBlank()) onUpdateSerial(m.id, energySerial) }
        onSaved()
    }
    Scaffold(topBar = { TopAppBar(title = { Text("Настройки") }, navigationIcon = { TextButton(onClick = onBack) { Text("Назад") } }) }) { padding ->
        LazyColumn(Modifier.padding(padding).padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            item { Text("Квартира", style = MaterialTheme.typography.titleMedium); Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) { apartments.forEach { Button(onClick = { save(); selectedId = it.id }, enabled = selectedId != it.id) { Text("${it.id}") } } } }
            item { OutlinedTextField(address, { address = it }, label = { Text("Адрес") }, modifier = Modifier.fillMaxWidth()) }
            item { Text("Севэнергосбыт", style = MaterialTheme.typography.titleMedium) }
            item { OutlinedTextField(energySurname, { energySurname = it }, label = { Text("Фамилия") }, modifier = Modifier.fillMaxWidth()) }
            item { OutlinedTextField(energyAccount, { energyAccount = it }, label = { Text("Лицевой счёт") }, modifier = Modifier.fillMaxWidth()) }
            item { OutlinedTextField(energySerial, { energySerial = it }, label = { Text("Номер счётчика") }, modifier = Modifier.fillMaxWidth()) }
            item { Text("Водоканал", style = MaterialTheme.typography.titleMedium) }
            item { OutlinedTextField(waterLogin, { waterLogin = it }, label = { Text("Лицевой счёт / логин") }, modifier = Modifier.fillMaxWidth()) }
            item { OutlinedTextField(waterPassword, { waterPassword = it }, label = { Text("Пароль") }, visualTransformation = PasswordVisualTransformation(), modifier = Modifier.fillMaxWidth()) }
            item { Text("Севгаз", style = MaterialTheme.typography.titleMedium) }
            item { OutlinedTextField(gasLogin, { gasLogin = it }, label = { Text("Логин") }, modifier = Modifier.fillMaxWidth()) }
            item { OutlinedTextField(gasPassword, { gasPassword = it }, label = { Text("Пароль") }, visualTransformation = PasswordVisualTransformation(), modifier = Modifier.fillMaxWidth()) }
            item { Text("Пароли сохраняются только на этом телефоне.") }
            item { Button(onClick = { save(); onBack() }, modifier = Modifier.fillMaxWidth()) { Text("Сохранить") } }
        }
    }
}

private fun providerUrl(type: MeterType) = when (type) { MeterType.ELECTRICITY -> ENERGY; MeterType.WATER -> WATER; MeterType.GAS -> GAS }

private fun autoFillScript(job: Job): String {
    val reading = JSONObject.quote(job.reading); val serial = JSONObject.quote(job.serial)
    val surname = JSONObject.quote(job.credentials.energySurname); val account = JSONObject.quote(job.credentials.energyAccount)
    val waterLogin = JSONObject.quote(job.credentials.waterLogin); val waterPassword = JSONObject.quote(job.credentials.waterPassword)
    val gasLogin = JSONObject.quote(job.credentials.gasLogin); val gasPassword = JSONObject.quote(job.credentials.gasPassword)
    return """
    (function(){
      const reading=$reading, serial=$serial, surname=$surname, account=$account, wl=$waterLogin, wp=$waterPassword, gl=$gasLogin, gp=$gasPassword;
      function all(){ return [...document.querySelectorAll('input,textarea,[contenteditable="true"]')]; }
      function txt(e){
        let parent='';
        try{parent=(e.parentElement&&e.parentElement.innerText)||'';}catch(_){}
        return ((e.getAttribute('aria-label')||'')+' '+(e.getAttribute('placeholder')||'')+' '+(e.getAttribute('name')||'')+' '+(e.id||'')+' '+((e.labels&&e.labels[0])?e.labels[0].innerText:'')+' '+(e.getAttribute('title')||'')+' '+parent).toLowerCase()
      }
      function visible(e){return e && (e.offsetWidth||e.offsetHeight||e.getClientRects().length)}
      function unlock(e){ if(!e)return; e.removeAttribute('disabled'); e.removeAttribute('readonly'); }
      function set(e,v){
        if(!e||v===undefined||v===null||v==='')return false;
        unlock(e); e.focus();
        try{
          const proto=e instanceof HTMLTextAreaElement?HTMLTextAreaElement.prototype:HTMLInputElement.prototype;
          const d=Object.getOwnPropertyDescriptor(proto,'value'); if(d&&d.set)d.set.call(e,v); else e.value=v;
        }catch(_){e.value=v;}
        e.dispatchEvent(new Event('input',{bubbles:true}));
        e.dispatchEvent(new Event('change',{bubbles:true}));
        e.dispatchEvent(new Event('blur',{bubbles:true}));
        try{e.dispatchEvent(new KeyboardEvent('keyup',{bubbles:true,key:'1'}));}catch(_){ }
        return true;
      }
      function first(words, extra){
        return all().find(e=>visible(e)&&(!extra||extra(e))&&words.some(w=>txt(e).includes(w)));
      }
      function clickSubmit(){
        const btn=[...document.querySelectorAll('button,input[type=submit],input[type=button],a')].find(b=>visible(b)&&/(войти|вход|login|sign in|авториз|продолж|войти в личный кабинет)/i.test((b.innerText||b.value||b.getAttribute('aria-label')||'')));
        if(btn){unlock(btn); btn.click(); return true;} return false;
      }
      let filled=[];
      let found=0;
      if(location.host.includes('sevenergosbyt')){
        const f=first(['фамил','surname']); if(f)found++; filled.push(set(f,surname));
        const a=first(['лицев','лицевой','account','абонент']); if(a)found++; filled.push(set(a,account));
        const sn=first(['номер счётчика','номер счетчика','serial','серийн','счётчик','счетчик']); if(sn)found++; filled.push(set(sn,serial));
      } else if(location.host.includes('sevvodokanal')){
        // У Водоканала подпись «Лицевой счет» находится рядом с формой,
        // поэтому поиск по parent.innerText может выбрать не тот input.
        // Надёжнее брать первый текстовый input в той же форме, что и пароль.
        let pw=all().find(e=>visible(e)&&e.type==='password');
        let form=pw ? (pw.form || pw.closest('form')) : null;
        let l=null;
        if(form){
          l=[...form.querySelectorAll('input')].find(e=>visible(e)&&e!==pw&&['text','number','tel'].includes((e.type||'text').toLowerCase()));
        }
        if(!l){
          l=all().find(e=>visible(e)&&e!==pw&&['text','number','tel'].includes((e.type||'text').toLowerCase())&&/(лицев|account|login|ls|lic)/i.test((e.name||'')+' '+(e.id||'')+' '+(e.getAttribute('placeholder')||'')));
        }
        if(!l){
          l=all().find(e=>visible(e)&&e!==pw&&['text','number','tel'].includes((e.type||'text').toLowerCase()));
        }
        if(l)found++; if(pw)found++;
        filled.push(set(l,wl));
        filled.push(set(pw,wp));
        if(l){
          setTimeout(function(){set(l,wl)},300);
          setTimeout(function(){set(l,wl)},1000);
          setTimeout(function(){set(l,wl)},2000);
        }
      } else if(location.host.includes('gup-sevgaz')){
        let pw=all().find(e=>visible(e)&&e.type==='password');
        let form=pw ? (pw.form || pw.closest('form')) : null;
        let l=form ? [...form.querySelectorAll('input')].find(e=>visible(e)&&e!==pw&&['text','tel'].includes((e.type||'text').toLowerCase())) : null;
        if(!l) l=first(['логин','login','пользователь','username','имя пользователя']);
        if(!l) l=all().find(e=>visible(e)&&e!==pw&&['text','tel'].includes((e.type||'text').toLowerCase()));
        if(l)found++; if(pw)found++; filled.push(set(l,gl)); filled.push(set(pw,gp));
        if(l&&pw) setTimeout(clickSubmit,700);
      }
      const meterWords=['показани','показан','потреблен','потребл','текущие показ','текущее показ','объём','объем','reading','meter reading','значение счетчика','значение счётчика'];
      const badWords=['captcha','капч','код с картинки','код картинки','цифр с картинки','изображен','код подтвержден','проверочн','security','защит','с картинки'];
      let candidates=all().filter(e=>visible(e)&&!e.disabled&&e.type!=='hidden'&&e.type!=='password'&&!badWords.some(w=>txt(e).includes(w))&&(e.type==='text'||e.type==='number'||e.tagName==='TEXTAREA'));
      let target=candidates.find(e=>meterWords.some(w=>txt(e).includes(w)));
      if(!target && location.host.includes('sevenergosbyt')){
        target=candidates.find(e=>{
          const x=txt(e);
          return !['фамил','лицев','account','счётчик','счетчик','serial','серийн','captcha','капч','картин','код','парол','login'].some(w=>x.includes(w));
        });
      }
      if(target){found++; filled.push(set(target,reading)); try{target.scrollIntoView({block:'center'});}catch(_){} }
      else filled.push(false);
      function retry(){
        let again=null;
        if(location.host.includes('sevenergosbyt') && reading){
          again=all().find(e=>visible(e)&&!badWords.some(w=>txt(e).includes(w))&&meterWords.some(w=>txt(e).includes(w)));
        } else if(location.host.includes('sevvodokanal') && wl){
          again=all().find(e=>visible(e)&&(/(лицев|account|login|ls)/i.test(txt(e)))&&e.type!=='password');
        } else if(location.host.includes('gup-sevgaz') && gl){
          again=all().find(e=>visible(e)&&(/(логин|login|username|пользоват)/i.test(txt(e)))&&e.type!=='password');
        }
        if(again)set(again, location.host.includes('sevenergosbyt')?reading:(location.host.includes('sevvodokanal')?wl:gl));
      }
      setTimeout(retry,700); setTimeout(retry,1600); setTimeout(retry,3000);
      return JSON.stringify({ok:true,found:found,filledCount:filled.filter(Boolean).length});
    })()
    """.trimIndent()
}

@SuppressLint("SetJavaScriptEnabled")
@Composable
fun ProviderScreen(url: String, job: Job, index: Int, total: Int, onWebViewReady: (WebView) -> Unit, onStatus: (String) -> Unit, onNext: () -> Unit, onBack: () -> Unit) {
    var message by remember(url, job.meterId) { mutableStateOf("${job.address}\n${job.title}: ${job.reading}\nШаг $index из $total") }
    var webViewRef by remember { mutableStateOf<WebView?>(null) }

    fun runFill() {
        val w = webViewRef
        if (w == null) {
            message = "Страница ещё загружается. Подожди и нажми «Заполнить» ещё раз."
            return
        }
        onStatus("Заполняется")
        message = "Ищем поля и заполняем данные..."
        w.evaluateJavascript(autoFillScript(job)) { result ->
            val r = result ?: ""
            if (r.contains("\"ok\":true")) {
                val found = Regex("\"found\":(\\d+)").find(r)?.groupValues?.getOrNull(1) ?: "0"
                val filled = Regex("\"filledCount\":(\\d+)").find(r)?.groupValues?.getOrNull(1) ?: "0"
                message = "Найдено подходящих полей: $found. Заполнено: $filled.\nПроверь данные на сайте. CAPTCHA вводится вручную."
                onStatus(if (filled != "0") "Данные заполнены" else "Требуется ввод")
            } else {
                message = "Не удалось выполнить автозаполнение. Попробуй ещё раз после полной загрузки страницы."
                onStatus("Требуется ввод")
            }
        }
    }

    Column(Modifier.fillMaxSize()) {
        Row(Modifier.fillMaxWidth().padding(8.dp), horizontalArrangement = Arrangement.SpaceBetween) {
            Text("Передача", style = MaterialTheme.typography.titleMedium)
            TextButton(onClick = onBack) { Text("Назад") }
        }
        Text(message, Modifier.padding(horizontal = 12.dp))
        Row(Modifier.padding(8.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Button(onClick = { runFill() }) { Text("Заполнить") }
            Button(onClick = {
                onStatus("Передано")
                message = "Проверь результат на сайте. CAPTCHA — вручную."
            }) { Text("Готово") }
            Button(onClick = { onNext() }) { Text(if (index < total) "Следующее" else "Завершить") }
        }
        AndroidView(factory = { context ->
            WebView(context).apply {
                webViewRef = this
                onWebViewReady(this)
                settings.javaScriptEnabled = true
                settings.domStorageEnabled = true
                settings.databaseEnabled = true
                settings.loadsImagesAutomatically = true
                settings.javaScriptCanOpenWindowsAutomatically = true
                settings.useWideViewPort = true
                settings.loadWithOverviewMode = true
                settings.setSupportZoom(false)
                settings.userAgentString = settings.userAgentString + " ChetchikiApp/0.9"
                webChromeClient = WebChromeClient()
                webViewClient = object : WebViewClient() {
                    override fun onPageFinished(view: WebView, loadedUrl: String) {
                        onWebViewReady(view)
                        message = "Страница загружена. Нажми «Заполнить»."
                        if (job.type == MeterType.GAS) {
                            view.postDelayed({
                                webViewRef = view
                                runFill()
                            }, 1200)
                            view.postDelayed({
                                webViewRef = view
                                runFill()
                            }, 3000)
                        }
                    }
                }
                loadUrl(url)
            }
        }, modifier = Modifier.fillMaxSize())
    }
}
