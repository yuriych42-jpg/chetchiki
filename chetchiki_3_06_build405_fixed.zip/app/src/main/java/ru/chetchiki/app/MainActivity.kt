@file:OptIn(ExperimentalMaterial3Api::class, ExperimentalFoundationApi::class)
package ru.chetchiki.app

import android.annotation.SuppressLint
import android.app.Activity
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Typeface
import android.net.Uri
import android.os.Bundle
import android.os.SystemClock
import java.io.OutputStream
import java.io.BufferedReader
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.roundToInt
import android.view.MotionEvent
import android.webkit.WebView
import android.webkit.WebViewClient
import android.webkit.WebChromeClient
import org.json.JSONObject
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.compose.setContent
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.viewinterop.AndroidView
import androidx.compose.ui.platform.LocalContext

enum class MeterType { ELECTRICITY, WATER, GAS }

data class Meter(
    val id: Int,
    val type: MeterType,
    val title: String,
    val serial: String = "",
    val reading: String = "",
    val status: String = "Не передано"
)

data class Apartment(val id: Int, val address: String, val meters: List<Meter>)

data class Credentials(
    val energySurname: String = "",
    val energyAccount: String = "",
    val energySerial: String = "",
    val waterLogin: String = "",
    val waterPassword: String = "",
    val gasLogin: String = "",
    val gasPassword: String = ""
)

data class Job(
    val apartmentId: Int,
    val address: String,
    val meterId: Int,
    val type: MeterType,
    val title: String,
    val reading: String,
    val serial: String = "",
    val credentials: Credentials = Credentials(),
    val providerUrl: String = ""
)

private const val ENERGY = "https://sevenergosbyt.ru/flk/index.php"
private const val WATER = "https://sevvodokanal.org.ru/app/webroot/account.php"
private const val GAS = "http://lk.sevgas.ru:8080/irb/login.xhtml"
private const val APP_VERSION = BuildConfig.VERSION_NAME

private fun defaultApartments() = listOf(
    Apartment(1, "Адрес квартиры 1", listOf(
        Meter(1, MeterType.ELECTRICITY, "Электричество №1"), Meter(2, MeterType.WATER, "Вода №1"), Meter(3, MeterType.WATER, "Вода №2"), Meter(4, MeterType.GAS, "Газ")
    )),
    Apartment(2, "Адрес квартиры 2", listOf(
        Meter(5, MeterType.ELECTRICITY, "Электричество №1"), Meter(6, MeterType.WATER, "Вода"), Meter(7, MeterType.GAS, "Газ")
    )),
    Apartment(3, "Адрес квартиры 3", listOf(
        Meter(8, MeterType.ELECTRICITY, "Электричество №1"), Meter(9, MeterType.WATER, "Вода"), Meter(10, MeterType.GAS, "Газ")
    )),
    Apartment(4, "Адрес квартиры 4", listOf(
        Meter(11, MeterType.ELECTRICITY, "Электричество №1"), Meter(12, MeterType.WATER, "Вода №1"), Meter(13, MeterType.WATER, "Вода №2"), Meter(14, MeterType.GAS, "Газ")
    ))
)

private fun newApartment(id: Int) = Apartment(id, "Адрес квартиры $id", listOf(
    Meter(id * 100 + 1, MeterType.ELECTRICITY, "Электричество №1"),
    Meter(id * 100 + 2, MeterType.WATER, "Вода"),
    Meter(id * 100 + 3, MeterType.GAS, "Газ")
))

// ГАЗ КВАРТИР 1–4: автоматический вход и подготовка показания — ВЕРСИЯ 0.92
class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { MeterApp(applicationContext) }
    }
}

private class LocalStore(context: Context) {
    private val p = context.getSharedPreferences("meter_store", Context.MODE_PRIVATE)
    fun get(k: String, d: String = "") = p.getString(k, d) ?: d
    fun put(k: String, v: String) { p.edit().putString(k, v).commit() }
    fun gasCookies(id: Int): String = get("gas_cookies_$id")
    fun putGasCookies(id: Int, v: String) { p.edit().putString("gas_cookies_$id", v).apply() }
    fun commitAddress(k: String, v: String) { p.edit().putString(k, v).commit() }
    fun apartmentIds(): List<Int> {
        val saved = get("apartment_ids")
        if (saved.isBlank()) {
            val ids = defaultApartments().map { it.id }
            p.edit().putString("apartment_ids", ids.joinToString(",")).commit()
            return ids
        }
        return saved.split(",").mapNotNull { it.trim().toIntOrNull() }.distinct().sorted()
    }
    fun saveApartmentIds(ids: List<Int>) { p.edit().putString("apartment_ids", ids.distinct().sorted().joinToString(",")).commit() }
    fun providerUrl(id: Int, type: MeterType): String {
        val fallback = when (type) {
            MeterType.ELECTRICITY -> ENERGY
            MeterType.WATER -> WATER
            MeterType.GAS -> GAS
        }
        val saved = get("provider_url_${type.name}_$id", fallback)
        return if (type == MeterType.GAS) {
            when {
                saved.contains("lk.gup-sevgaz.ru", ignoreCase = true) -> saved.replace("https://lk.gup-sevgaz.ru:8081", "http://lk.sevgas.ru:8080", ignoreCase = true).replace("http://lk.gup-sevgaz.ru:8080", "http://lk.sevgas.ru:8080", ignoreCase = true)
                saved.contains(":8081", ignoreCase = true) -> saved.replace(":8081", ":8080").replace("https://", "http://")
                else -> saved
            }
        } else saved
    }
    fun saveProviderUrl(id: Int, type: MeterType, value: String) { put("provider_url_${type.name}_$id", value) }
    fun meterIds(id: Int, fallback: List<Meter>): List<Int> {
        val saved = get("meter_ids_$id")
        if (saved.isBlank()) {
            val ids = fallback.map { it.id }
            put("meter_ids_$id", ids.joinToString(","))
            return ids
        }
        return saved.split(",").mapNotNull { it.trim().toIntOrNull() }.distinct()
    }
    fun saveMeterIds(id: Int, ids: List<Int>) { put("meter_ids_$id", ids.distinct().joinToString(",")) }
    fun meterType(id: Int, meterId: Int, fallback: MeterType): MeterType = try { MeterType.valueOf(get("meter_type_${id}_$meterId", fallback.name)) } catch (_: Exception) { fallback }
    fun meterTitle(id: Int, meterId: Int, fallback: String): String = get("meter_title_${id}_$meterId", fallback)
    fun saveMeter(id: Int, meter: Meter) {
        put("meter_type_${id}_${meter.id}", meter.type.name)
        put("meter_title_${id}_${meter.id}", meter.title)
    }
    fun previousReading(meterId: Int): String = get("previous_reading_$meterId")
    fun savePreviousReading(meterId: Int, value: String) { if (value.isNotBlank()) put("previous_reading_$meterId", value) }
    fun clearReading(meterId: Int) {
        val current = get("reading_$meterId")
        if (current.isNotBlank()) savePreviousReading(meterId, current)
        p.edit().remove("reading_$meterId").putString("status_$meterId", "Не передано").apply()
    }
    fun deleteMeterData(meterId: Int) { p.edit().remove("reading_$meterId").remove("previous_reading_$meterId").remove("serial_$meterId").remove("status_$meterId").apply() }
    fun waterLogin(id: Int): String = get("water_login_$id")
    fun credentials(id: Int) = Credentials(
        get("energy_surname_$id"), get("energy_account_$id"), get("energy_serial_$id"),
        waterLogin(id), get("water_password_$id"), get("gas_login_$id"), get("gas_password_$id")
    )

    fun exportJson(): String {
        val root = JSONObject()
        root.put("format", "chetchiki-settings")
        root.put("formatVersion", 1)
        val values = JSONObject()
        p.all.forEach { (key, value) ->
            when (value) {
                is String -> values.put(key, value)
                is Boolean -> values.put(key, value)
                is Int -> values.put(key, value)
                is Long -> values.put(key, value)
                is Float -> values.put(key, value.toDouble())
            }
        }
        root.put("values", values)
        return root.toString(2)
    }

    fun importJson(json: String) {
        val root = JSONObject(json)
        require(root.optString("format") == "chetchiki-settings") { "Неверный файл настроек" }
        val values = root.optJSONObject("values") ?: error("В файле нет настроек")
        val editor = p.edit().clear()
        val keys = values.keys()
        while (keys.hasNext()) {
            val key = keys.next()
            when (val value = values.get(key)) {
                is String -> editor.putString(key, value)
                is Boolean -> editor.putBoolean(key, value)
                is Int -> editor.putInt(key, value)
                is Long -> editor.putLong(key, value)
                is Double -> editor.putFloat(key, value.toFloat())
            }
        }
        check(editor.commit()) { "Не удалось сохранить настройки" }
    }
}


private data class AppColors(
    val background: String = "#FFF7FB",
    val surface: String = "#FFFFFF",
    val primary: String = "#C2185B",
    val onPrimary: String = "#FFFFFF",
    val secondary: String = "#8E4A68",
    val onSecondary: String = "#FFFFFF",
    val text: String = "#2A2024",
    val mutedText: String = "#756A70",
    val outline: String = "#B9AAB2",
    val fieldBackground: String = "#FFF0F6",
    val fieldText: String = "#2A2024",
    val headerBackground: String = "#F8BBD0",
    val headerText: String = "#5A1735",
    val progress: String = "#C2185B",
    val cardBackground: String = "#FFFFFF"
) {
    fun color(hex: String, fallback: Color): Color = runCatching { Color(android.graphics.Color.parseColor(hex)) }.getOrDefault(fallback)
    fun scheme() = lightColorScheme(
        primary = color(primary, Color(0xFFC2185B)),
        onPrimary = color(onPrimary, Color.White),
        secondary = color(secondary, Color(0xFF8E4A68)),
        onSecondary = color(onSecondary, Color.White),
        background = color(background, Color(0xFFFFF7FB)),
        onBackground = color(text, Color(0xFF2A2024)),
        surface = color(surface, Color.White),
        onSurface = color(text, Color(0xFF2A2024)),
        surfaceVariant = color(fieldBackground, Color(0xFFFFF0F6)),
        onSurfaceVariant = color(mutedText, Color(0xFF756A70)),
        outline = color(outline, Color(0xFFB9AAB2)),
        outlineVariant = color(outline, Color(0xFFB9AAB2))
    )
    companion object {
        fun from(store: LocalStore) = AppColors(
            background = store.get("color_background", "#FFF7FB"),
            surface = store.get("color_surface", "#FFFFFF"),
            primary = store.get("color_primary", "#C2185B"),
            onPrimary = store.get("color_on_primary", "#FFFFFF"),
            secondary = store.get("color_secondary", "#8E4A68"),
            onSecondary = store.get("color_on_secondary", "#FFFFFF"),
            text = store.get("color_text", "#2A2024"),
            mutedText = store.get("color_muted_text", "#756A70"),
            outline = store.get("color_outline", "#B9AAB2"),
            fieldBackground = store.get("color_field_background", "#FFF0F6"),
            fieldText = store.get("color_field_text", "#2A2024"),
            headerBackground = store.get("color_header_background", "#F8BBD0"),
            headerText = store.get("color_header_text", "#5A1735"),
            progress = store.get("color_progress", "#C2185B"),
            cardBackground = store.get("color_card_background", "#FFFFFF")
        )
    }
}

private val LocalAppColors = staticCompositionLocalOf { AppColors() }

private fun AppColors.saveTo(store: LocalStore) {
    store.put("color_background", background)
    store.put("color_surface", surface)
    store.put("color_primary", primary)
    store.put("color_on_primary", onPrimary)
    store.put("color_secondary", secondary)
    store.put("color_on_secondary", onSecondary)
    store.put("color_text", text)
    store.put("color_muted_text", mutedText)
    store.put("color_outline", outline)
    store.put("color_field_background", fieldBackground)
    store.put("color_field_text", fieldText)
    store.put("color_header_background", headerBackground)
    store.put("color_header_text", headerText)
    store.put("color_progress", progress)
    store.put("color_card_background", cardBackground)
}

private fun AppColors.saveCustomTo(store: LocalStore, name: String) {
    store.put("custom_theme_name", name)
    store.put("custom_theme_background", background)
    store.put("custom_theme_surface", surface)
    store.put("custom_theme_primary", primary)
    store.put("custom_theme_on_primary", onPrimary)
    store.put("custom_theme_secondary", secondary)
    store.put("custom_theme_on_secondary", onSecondary)
    store.put("custom_theme_text", text)
    store.put("custom_theme_muted_text", mutedText)
    store.put("custom_theme_outline", outline)
    store.put("custom_theme_field_background", fieldBackground)
    store.put("custom_theme_field_text", fieldText)
    store.put("custom_theme_header_background", headerBackground)
    store.put("custom_theme_header_text", headerText)
    store.put("custom_theme_progress", progress)
    store.put("custom_theme_card_background", cardBackground)
}

private fun loadCustomColors(store: LocalStore): AppColors? {
    val name = store.get("custom_theme_name", "")
    if (name.isBlank()) return null
    return AppColors(
        background = store.get("custom_theme_background", "#FFF7FB"),
        surface = store.get("custom_theme_surface", "#FFFFFF"),
        primary = store.get("custom_theme_primary", "#C2185B"),
        onPrimary = store.get("custom_theme_on_primary", "#FFFFFF"),
        secondary = store.get("custom_theme_secondary", "#8E4A68"),
        onSecondary = store.get("custom_theme_on_secondary", "#FFFFFF"),
        text = store.get("custom_theme_text", "#2A2024"),
        mutedText = store.get("custom_theme_muted_text", "#756A70"),
        outline = store.get("custom_theme_outline", "#B9AAB2"),
        fieldBackground = store.get("custom_theme_field_background", "#FFF0F6"),
        fieldText = store.get("custom_theme_field_text", "#2A2024"),
        headerBackground = store.get("custom_theme_header_background", "#F8BBD0"),
        headerText = store.get("custom_theme_header_text", "#5A1735"),
        progress = store.get("custom_theme_progress", "#C2185B"),
        cardBackground = store.get("custom_theme_card_background", "#FFFFFF")
    )
}


private data class SavedColorTheme(val name: String, val colors: AppColors)

private fun AppColors.toJson(name: String): JSONObject = JSONObject().apply {
    put("name", name)
    put("background", background); put("surface", surface); put("primary", primary); put("onPrimary", onPrimary)
    put("secondary", secondary); put("onSecondary", onSecondary); put("text", text); put("mutedText", mutedText)
    put("outline", outline); put("fieldBackground", fieldBackground); put("fieldText", fieldText)
    put("headerBackground", headerBackground); put("headerText", headerText); put("progress", progress); put("cardBackground", cardBackground)
}

private fun JSONObject.toAppColors(): AppColors = AppColors(
    background = optString("background", "#FFF7FB"), surface = optString("surface", "#FFFFFF"),
    primary = optString("primary", "#C2185B"), onPrimary = optString("onPrimary", "#FFFFFF"),
    secondary = optString("secondary", "#8E4A68"), onSecondary = optString("onSecondary", "#FFFFFF"),
    text = optString("text", "#2A2024"), mutedText = optString("mutedText", "#756A70"),
    outline = optString("outline", "#B9AAB2"), fieldBackground = optString("fieldBackground", "#FFF0F6"),
    fieldText = optString("fieldText", "#2A2024"), headerBackground = optString("headerBackground", "#F8BBD0"),
    headerText = optString("headerText", "#5A1735"), progress = optString("progress", "#C2185B"),
    cardBackground = optString("cardBackground", "#FFFFFF")
)

private fun loadSavedColorThemes(store: LocalStore): List<SavedColorTheme> {
    val raw = store.get("saved_color_themes", "")
    if (raw.isNotBlank()) runCatching {
        val arr = org.json.JSONArray(raw)
        return (0 until arr.length()).mapNotNull { i ->
            val obj = arr.optJSONObject(i) ?: return@mapNotNull null
            val name = obj.optString("name", "Моя тема").trim().ifBlank { "Моя тема" }
            SavedColorTheme(name, obj.toAppColors())
        }
    }
    // Миграция старой единственной пользовательской темы в новый список.
    return loadCustomColors(store)?.let { listOf(SavedColorTheme(store.get("custom_theme_name", "Моя тема"), it)) } ?: emptyList()
}

private fun saveSavedColorThemes(store: LocalStore, themes: List<SavedColorTheme>) {
    val arr = org.json.JSONArray()
    themes.forEach { arr.put(it.colors.toJson(it.name)) }
    store.put("saved_color_themes", arr.toString())
}

private fun LocalStore.resetColors() {
    val keys = listOf("background","surface","primary","on_primary","secondary","on_secondary","text","muted_text","outline","field_background","field_text","header_background","header_text","progress","card_background")
    keys.forEach { put("color_$it", AppColors().let { c -> when(it) {
        "background" -> c.background; "surface" -> c.surface; "primary" -> c.primary; "on_primary" -> c.onPrimary
        "secondary" -> c.secondary; "on_secondary" -> c.onSecondary; "text" -> c.text; "muted_text" -> c.mutedText
        "outline" -> c.outline; "field_background" -> c.fieldBackground; "field_text" -> c.fieldText
        "header_background" -> c.headerBackground; "header_text" -> c.headerText; "progress" -> c.progress; else -> c.cardBackground
    }}) }
}

@Composable
fun MeterApp(context: Context) {
    val store = remember { LocalStore(context) }
    var themeVersion by remember { mutableIntStateOf(0) }
    val appColors = remember(themeVersion) { AppColors.from(store) }
    CompositionLocalProvider(LocalAppColors provides appColors) {
        MaterialTheme(colorScheme = appColors.scheme()) {
            MeterAppContent(context, onColorsChanged = { themeVersion++ })
        }
    }
}

@Composable
private fun MeterAppContent(context: Context, onColorsChanged: () -> Unit) {

    val store = remember { LocalStore(context) }
    var apartments by remember {
        mutableStateOf(store.apartmentIds().map { id ->
            val base = defaultApartments().firstOrNull { it.id == id } ?: newApartment(id)
            val baseById = base.meters.associateBy { it.id }
            val ids = store.meterIds(id, base.meters)
            val configuredMeters = ids.mapNotNull { meterId ->
                val fallback = baseById[meterId]
                if (fallback != null) fallback else {
                    val type = store.meterType(id, meterId, MeterType.WATER)
                    val title = store.meterTitle(id, meterId, if (type == MeterType.ELECTRICITY) "Электричество №1" else "Вода")
                    Meter(meterId, type, title)
                }
            }.map { m -> m.copy(type = store.meterType(id, m.id, m.type), title = store.meterTitle(id, m.id, m.title), serial = store.get("serial_${m.id}"), reading = store.get("reading_${m.id}"), status = store.get("status_${m.id}", "Не передано")) }
            base.copy(address = store.get("address_${id}", base.address), meters = configuredMeters)
        })
    }
    var credentialsVersion by remember { mutableIntStateOf(0) }
    var jobs by remember { mutableStateOf(listOf<Job>()) }
    var activeJobIndex by remember { mutableIntStateOf(0) }
    var returnApartmentId by remember { mutableStateOf<Int?>(null) }
    var webUrl by remember { mutableStateOf<String?>(null) }
    var webViewRef by remember { mutableStateOf<WebView?>(null) }
    var settings by remember { mutableStateOf(false) }
    var settingsApartmentId by remember { mutableStateOf<Int?>(null) }
    var help by remember { mutableStateOf(false) }
    var reports by remember { mutableStateOf(false) }
    var electricityReport by remember { mutableStateOf(false) }
    var electricityReportApartmentScreenId by remember { mutableStateOf<Int?>(null) }
    var electricityReportFetchApartmentId by remember { mutableStateOf<Int?>(null) }
    var electricityReportRefreshVersion by remember { mutableIntStateOf(0) }
    var gasReport by remember { mutableStateOf(false) }
    var gasReportApartmentId by remember { mutableStateOf<Int?>(1) }
    var gasReportApartmentScreenId by remember { mutableStateOf<Int?>(null) }
    var gasReportFetchApartmentId by remember { mutableStateOf<Int?>(null) }
    var gasReportAllFetch by remember { mutableStateOf(false) }
    var gasReportAllIndex by remember { mutableIntStateOf(0) }
    var gasReportAllIds by remember { mutableStateOf<List<Int>>(emptyList()) }
    var gasReportAllScreen by remember { mutableStateOf(false) }
    var gasReportRefreshVersion by remember { mutableIntStateOf(0) }
    var waterReport by remember { mutableStateOf(false) }
    var waterReportFetchApartmentId by remember { mutableStateOf<Int?>(null) }
    var waterReportAllFetch by remember { mutableStateOf(false) }
    var waterReportAllIndex by remember { mutableIntStateOf(0) }
    var waterReportAllScreen by remember { mutableStateOf(false) }
    var waterReportApartmentScreenId by remember { mutableStateOf<Int?>(null) }
    var waterReportRefreshVersion by remember { mutableIntStateOf(0) }
    val activity = LocalContext.current as? Activity

    // Системная кнопка «Назад» телефона: внутри экранов возвращает назад,
    // а на главном экране полностью закрывает приложение — как кнопка «Выход».
    BackHandler {
        when {
            webUrl != null -> webUrl = null
            settings -> settings = false
            help -> help = false
            gasReportFetchApartmentId != null || gasReportAllFetch -> {
                gasReportFetchApartmentId = null
                gasReportAllFetch = false
                gasReport = true
            }
            gasReportAllScreen -> { gasReportAllScreen = false; gasReport = true }
            gasReportApartmentScreenId != null -> { gasReportApartmentScreenId = null; gasReport = true }
            gasReport -> { gasReport = false; reports = true }
            waterReportApartmentScreenId != null -> {
                waterReportFetchApartmentId = null
                waterReportApartmentScreenId = null
                waterReport = true
            }
            waterReportAllScreen -> { waterReportAllScreen = false; waterReport = true }
            waterReportFetchApartmentId != null || waterReportAllFetch -> {
                waterReportFetchApartmentId = null
                waterReportAllFetch = false
                waterReport = true
            }
            waterReport -> { waterReport = false; reports = true }
            electricityReportFetchApartmentId != null -> { electricityReportFetchApartmentId = null; electricityReportApartmentScreenId = null; electricityReport = true }
            electricityReportApartmentScreenId != null -> { electricityReportApartmentScreenId = null; electricityReport = true }
            electricityReport -> { electricityReport = false; reports = true }
            reports -> reports = false
            else -> activity?.finishAffinity()
        }
    }
    val exportLauncher = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
        if (result.resultCode == Activity.RESULT_OK) {
            result.data?.data?.let { uri ->
                runCatching {
                    context.contentResolver.openOutputStream(uri)?.use { output ->
                        output.write(store.exportJson().toByteArray(Charsets.UTF_8))
                    } ?: error("Не удалось открыть файл")
                }
            }
        }
    }
    val importLauncher = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
        if (result.resultCode == Activity.RESULT_OK) {
            result.data?.data?.let { uri ->
                runCatching {
                    val json = context.contentResolver.openInputStream(uri)?.use { it.readBytes().toString(Charsets.UTF_8) }
                        ?: error("Не удалось открыть файл")
                    store.importJson(json)
                    activity?.recreate()
                }
            }
        }
    }

    fun updateMeter(apartmentId: Int, meterId: Int, reading: String? = null, serial: String? = null, status: String? = null) {
        apartments = apartments.map { a -> if (a.id != apartmentId) a else a.copy(meters = a.meters.map { m -> if (m.id != meterId) m else m.copy(reading = reading ?: m.reading, serial = serial ?: m.serial, status = status ?: m.status) }) }
        if (reading != null) store.put("reading_$meterId", reading)
        if (serial != null) store.put("serial_$meterId", serial)
        if (status != null) store.put("status_$meterId", status)
    }
    fun updateStatus(job: Job, status: String) = updateMeter(job.apartmentId, job.meterId, status = status)
    fun clearMeterReading(apartmentId: Int, meterId: Int) {
        apartments = apartments.map { a -> if (a.id != apartmentId) a else a.copy(meters = a.meters.map { m -> if (m.id == meterId) m.copy(reading = "", status = "Не передано") else m }) }
        store.clearReading(meterId)
    }
    fun clearApartmentReadings(apartmentId: Int) {
        val apartment = apartments.firstOrNull { it.id == apartmentId } ?: return
        apartment.meters.forEach { store.clearReading(it.id) }
        apartments = apartments.map { a -> if (a.id != apartmentId) a else a.copy(meters = a.meters.map { it.copy(reading = "", status = "Не передано") }) }
    }
    fun clearAllReadings() {
        apartments.flatMap { it.meters }.forEach { store.clearReading(it.id) }
        apartments = apartments.map { a -> a.copy(meters = a.meters.map { it.copy(reading = "", status = "Не передано") }) }
    }

    fun makeJob(a: Apartment, m: Meter): Job {
        // Критично: серийный номер и показание берём по ID конкретного счётчика
        // из постоянного хранилища. Это исключает подмену Вода №2 значениями Вода №1
        // при повторном создании списка заданий после сохранения настроек.
        val credentials = store.credentials(a.id)
        val serial = store.get("serial_${m.id}", m.serial).trim()
        val reading = store.get("reading_${m.id}", m.reading).trim()
        return Job(
            apartmentId = a.id,
            address = a.address,
            meterId = m.id,
            type = m.type,
            title = m.title,
            reading = reading,
            serial = serial,
            credentials = credentials,
            providerUrl = store.providerUrl(a.id, m.type)
        )
    }

    // Единый алгоритм передачи для каждой квартиры:
    // 1) электричество -> 2) вода -> 3) газ.
    // Порядок не зависит от того, как счётчики записаны в конфигурации квартиры.
    fun orderedJobs(a: Apartment, meters: List<Meter> = a.meters): List<Job> {
        val order = listOf(MeterType.ELECTRICITY, MeterType.WATER, MeterType.GAS)
        return order.flatMap { type ->
            meters.filter { it.type == type }.map { makeJob(a, it) }
        }
    }

    fun startJobs(newJobs: List<Job>) {
        if (newJobs.isNotEmpty()) {
            jobs = newJobs
            activeJobIndex = 0
            returnApartmentId = newJobs[0].apartmentId
            webUrl = newJobs[0].providerUrl
        }
    }
    fun nextJob() {
        val next = activeJobIndex + 1
        if (next >= jobs.size) {
            returnApartmentId = jobs.getOrNull(activeJobIndex)?.apartmentId
            webUrl = null
        } else {
            activeJobIndex = next
            returnApartmentId = jobs[next].apartmentId
            webUrl = jobs[next].providerUrl
        }
    }

    if (help) {
        Scaffold(
            topBar = {
                TopAppBar(
                    title = { Text("Справка") },
                    navigationIcon = { TextButton(onClick = { help = false }) { Text("Назад") } }
                )
            }
        ) { padding ->
            Column(Modifier.fillMaxSize().padding(padding).padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Text("Счётчики", style = MaterialTheme.typography.titleLarge)
                Text("Версия приложения: $APP_VERSION", style = MaterialTheme.typography.bodyLarge)
                Text("Здесь будет размещена подробная справка по работе приложения.", style = MaterialTheme.typography.bodyMedium)
            }
        }
        return
    }

    if (settings) {
        SettingsScreen(
            apartments = apartments,
            store = store,
            initialApartmentId = settingsApartmentId,
            onUpdateAddress = { id, value -> apartments = apartments.map { if (it.id == id) it.copy(address = value) else it }; store.commitAddress("address_$id", value) },
            onUpdateSerial = { id, value -> apartments = apartments.map { a -> a.copy(meters = a.meters.map { m -> if (m.id == id) m.copy(serial = value) else m }) }; store.put("serial_$id", value) },
            onUpdateTitle = { id, value -> apartments = apartments.map { a -> a.copy(meters = a.meters.map { m -> if (m.id == id) m.copy(title = value) else m }) } },
            onAddMeter = addMeter@{ apartmentId, type ->
                val apartment = apartments.firstOrNull { it.id == apartmentId }
                if (apartment == null) return@addMeter
                val newMeterId = (apartments.flatMap { it.meters }.maxOfOrNull { it.id } ?: 0) + 1
                val count = apartment.meters.count { it.type == type } + 1
                val title = if (type == MeterType.ELECTRICITY) { "Электричество №$count" } else { "Вода №$count" }
                val meter = Meter(newMeterId, type, title)
                val orderedMeters = buildList {
                    addAll(apartment.meters.filter { it.type == MeterType.ELECTRICITY })
                    if (type == MeterType.ELECTRICITY) add(meter)
                    addAll(apartment.meters.filter { it.type == MeterType.WATER })
                    if (type == MeterType.WATER) add(meter)
                    addAll(apartment.meters.filter { it.type == MeterType.GAS })
                }
                apartments = apartments.map { if (it.id == apartmentId) it.copy(meters = orderedMeters) else it }
                store.saveMeter(apartmentId, meter)
                store.saveMeterIds(apartmentId, apartments.first { it.id == apartmentId }.meters.map { it.id })
            },
            onDeleteMeter = deleteMeter@{ apartmentId, meterId ->
                val apartment = apartments.firstOrNull { it.id == apartmentId }
                if (apartment == null) return@deleteMeter
                val meter = apartment.meters.firstOrNull { it.id == meterId }
                if (meter == null || (meter.type != MeterType.ELECTRICITY && meter.type != MeterType.WATER)) return@deleteMeter
                val remaining = apartment.meters.filterNot { it.id == meterId }
                apartments = apartments.map { if (it.id == apartmentId) it.copy(meters = remaining) else it }
                store.saveMeterIds(apartmentId, remaining.map { it.id })
                store.deleteMeterData(meterId)
            },
            onAddApartment = {
                val newId = ((apartments.maxOfOrNull { it.id } ?: 0) + 1)
                val added = newApartment(newId)
                apartments = apartments + added
                store.saveApartmentIds(apartments.map { it.id })
            },
            onDeleteApartment = { id ->
                if (apartments.size > 1) {
                    apartments = apartments.filterNot { it.id == id }
                    store.saveApartmentIds(apartments.map { it.id })
                }
            },
            onSaved = { credentialsVersion++ },
            onExportSettings = {
                val intent = Intent(Intent.ACTION_CREATE_DOCUMENT).apply {
                    addCategory(Intent.CATEGORY_OPENABLE)
                    type = "application/json"
                    putExtra(Intent.EXTRA_TITLE, "chetchiki-settings.json")
                }
                exportLauncher.launch(intent)
            },
            onImportSettings = {
                val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
                    addCategory(Intent.CATEGORY_OPENABLE)
                    type = "application/json"
                }
                importLauncher.launch(intent)
            },
            onColorsChanged = onColorsChanged,
            onBack = { settings = false }
        )
        return
    }

    if (electricityReportFetchApartmentId != null) {
        val reportApartmentId = electricityReportFetchApartmentId
        val reportApartment = apartments.firstOrNull { it.id == reportApartmentId }
        val em = reportApartment?.meters?.firstOrNull { it.type == MeterType.ELECTRICITY }
        if (reportApartment != null && em != null) {
            val energyJob = Job(reportApartment.id, store.apartmentAddress(reportApartment), em.id, MeterType.ELECTRICITY, em.title, "", em.serial, store.credentials(reportApartment.id), store.providerUrl(reportApartment.id, MeterType.ELECTRICITY))
            key("electricity-report-fetch-${reportApartment.id}") {
                ProviderScreen(url = energyJob.providerUrl, job = energyJob, index = 1, total = 1, store = store,
                    reportMode = true, electricityReportMode = true,
                    onElectricityReportData = { debt, accrued, paid, reading ->
                        store.put("electricity_report_debt_${reportApartment.id}", debt)
                        store.put("electricity_report_accrued_${reportApartment.id}", accrued)
                        store.put("electricity_report_paid_${reportApartment.id}", paid)
                        store.put("electricity_report_reading_${reportApartment.id}", reading)
                        store.put("electricity_report_generated_${reportApartment.id}", SimpleDateFormat("dd.MM.yyyy HH:mm", Locale.getDefault()).format(Date()))
                        electricityReportRefreshVersion++
                        electricityReportFetchApartmentId = null
                        electricityReportApartmentScreenId = reportApartment.id
                    }, onWebViewReady = { webViewRef = it }, onStatus = {}, onNext = {}, onBack = {})
            }
        } else { electricityReportFetchApartmentId = null; electricityReport = true }
        return
    }

    if (electricityReportApartmentScreenId != null) {
        val id = electricityReportApartmentScreenId!!
        ElectricityReportScreen(apartments.firstOrNull { it.id == id }, store, electricityReportRefreshVersion,
            onFetch = { electricityReportFetchApartmentId = it },
            onBack = { electricityReportApartmentScreenId = null; electricityReport = true })
        return
    }

    if (electricityReport) {
        ElectricityReportHubScreen(apartments, store,
            onFetchApartment = { id -> electricityReportApartmentScreenId = id },
            onBack = { electricityReport = false; reports = true })
        return
    }

    if (gasReportFetchApartmentId != null) {
        val reportApartmentId = gasReportFetchApartmentId
        val reportApartment = apartments.firstOrNull { it.id == reportApartmentId }
        if (reportApartment != null) {
            val gm = reportApartment.meters.firstOrNull { it.type == MeterType.GAS }
            if (gm != null) {
                val gasJob = Job(
                    apartmentId = reportApartment.id,
                    address = store.apartmentAddress(reportApartment),
                    meterId = gm.id,
                    type = MeterType.GAS,
                    title = gm.title,
                    reading = "",
                    serial = gm.serial,
                    credentials = store.credentials(reportApartment.id),
                    providerUrl = store.providerUrl(reportApartment.id, MeterType.GAS)
                )
                key("gas-report-fetch-${reportApartment.id}") {
                    ProviderScreen(
                        url = gasJob.providerUrl,
                        job = gasJob,
                        index = 1,
                        total = 1,
                        store = store,
                        reportMode = true,
                        gasReportMode = true,
                        gasReportAllFetch = gasReportAllFetch,
                        onGasReportData = { supply, maintenance, _, _ ->
                            store.put("gas_report_supply_${reportApartment.id}", supply)
                            store.put("gas_report_maintenance_${reportApartment.id}", maintenance)
                            store.put("gas_report_generated_${reportApartment.id}", SimpleDateFormat("dd.MM.yyyy HH:mm", Locale.getDefault()).format(Date()))
                            gasReportRefreshVersion++
                            if (gasReportAllFetch && gasReportAllIds.isNotEmpty()) {
                                val nextIndex = gasReportAllIndex + 1
                                if (nextIndex < gasReportAllIds.size) {
                                    gasReportAllIndex = nextIndex
                                    val nextId = gasReportAllIds[nextIndex]
                                    gasReportApartmentId = nextId
                                    gasReportFetchApartmentId = nextId
                                } else {
                                    gasReportAllFetch = false
                                    gasReportAllIndex = 0
                                    gasReportAllIds = emptyList()
                                    gasReportFetchApartmentId = null
                                    gasReportAllScreen = true
                                }
                            } else {
                                gasReportFetchApartmentId = null
                                gasReportApartmentId = reportApartment.id
                                gasReport = true
                            }
                        },
                        onWebViewReady = { webViewRef = it },
                        onStatus = {},
                        onNext = {},
                        onBack = {}
                    )
                }
            } else {
                gasReportFetchApartmentId = null
                gasReport = true
            }
        } else {
            gasReportFetchApartmentId = null
            gasReport = true
        }
        return
    }

    // Water report UI stays visible while the hidden WebView fetches the data.
    // This avoids replacing the report screen with a blank WebView during loading.
    if (gasReportAllScreen) {
        GasReportAllScreen(
            apartments = apartments,
            store = store,
            onBack = { gasReportAllScreen = false; gasReportAllFetch = false; gasReportAllIndex = 0; gasReportAllIds = emptyList(); gasReport = true }
        )
        return
    }

    if (gasReportAllFetch && gasReportAllIds.isNotEmpty() && gasReportFetchApartmentId == null) {
        val targetId = gasReportAllIds.getOrNull(gasReportAllIndex)
        if (targetId != null) {
            gasReportApartmentId = targetId
            gasReportFetchApartmentId = targetId
        }
    }

    if (gasReportApartmentScreenId != null) {
        val id = gasReportApartmentScreenId!!
        GasReportScreen(
            apartment = apartments.firstOrNull { it.id == id },
            store = store,
            refreshVersion = gasReportRefreshVersion,
            onFetch = { gasReportApartmentId = it; gasReportFetchApartmentId = it },
            onBack = { gasReportApartmentScreenId = null; gasReport = true }
        )
        return
    }

    if (gasReport) {
        GasReportHubScreen(
            apartments = apartments,
            store = store,
            onFetchApartment = { id -> gasReportApartmentScreenId = id },
            onFetchAll = {
                val ids = apartments.filter { store.hasConfiguredGasReport(it.id) }.map { it.id }
                gasReportAllIds = ids
                gasReportAllIndex = 0
                gasReportAllFetch = ids.isNotEmpty()
                gasReportApartmentId = ids.firstOrNull()
                gasReportFetchApartmentId = ids.firstOrNull()
                if (ids.isEmpty()) gasReportAllScreen = true
            },
            onBack = { gasReport = false; reports = true }
        )
        return
    }

    if (reports) {
        ReportsHubScreen(
            onElectricity = { electricityReport = true; reports = false },
            onWater = { waterReport = true; reports = false },
            onGas = { gasReport = true; reports = false },
            onBack = { reports = false }
        )
        return
    }

    if (waterReportApartmentScreenId != null) {
        val reportApartmentId = waterReportApartmentScreenId
        val reportApartment = apartments.firstOrNull { it.id == reportApartmentId }
        Column(Modifier.fillMaxSize()) {
            WaterReportScreen(
                apartment = reportApartment,
                store = store,
                refreshVersion = waterReportRefreshVersion,
                onFetch = { id ->
                    waterReportFetchApartmentId = id
                    waterReportApartmentScreenId = id
                    waterReport = false
                },
                onBack = { 
                    waterReportFetchApartmentId = null
                    waterReportApartmentScreenId = null
                    waterReport = true
                }
            )
            if (waterReportFetchApartmentId == reportApartmentId) {
                val a = reportApartment
                val wm = a?.meters?.firstOrNull { it.type == MeterType.WATER }
                if (a != null && wm != null) {
                    val reportJob = Job(
                        apartmentId = a.id,
                        address = store.apartmentAddress(a),
                        meterId = wm.id,
                        type = MeterType.WATER,
                        title = wm.title,
                        reading = "",
                        serial = wm.serial,
                        credentials = store.credentials(a.id),
                        providerUrl = store.providerUrl(a.id, MeterType.WATER)
                    )
                    key("water-report-fetch-${a.id}") {
                        ProviderScreen(
                            url = reportJob.providerUrl,
                            job = reportJob,
                            index = 1,
                            total = 1,
                            store = store,
                            reportMode = true,
                            onReportData = { over, debt, penalty ->
                                store.put("water_report_overpayment_${a.id}", over)
                                store.put("water_report_debt_${a.id}", debt)
                                store.put("water_report_penalty_${a.id}", penalty)
                                waterReportRefreshVersion++
                                if (waterReportAllFetch) {
                                    val waterIds = apartments.filter { ap ->
                                            ap.meters.any { it.type == MeterType.WATER } &&
                                                store.waterLogin(ap.id).isNotBlank() &&
                                                store.get("water_password_${ap.id}").isNotBlank()
                                        }.map { it.id }
                                    val nextIndex = waterReportAllIndex + 1
                                    if (nextIndex < waterIds.size) {
                                        waterReportAllIndex = nextIndex
                                        waterReportApartmentScreenId = waterIds[nextIndex]
                                        waterReportFetchApartmentId = waterIds[nextIndex]
                                    } else {
                                        waterReportAllFetch = false
                                        waterReportFetchApartmentId = null
                                        waterReportApartmentScreenId = null
                                        waterReportAllScreen = true
                                    }
                                } else {
                                    waterReportFetchApartmentId = null
                                }
                            },
                            onWebViewReady = { webViewRef = it },
                            onStatus = {},
                            onNext = {},
                            onBack = {}
                        )
                    }
                }
            }
        }
        return
    }

    if (waterReportAllScreen) {
        WaterReportAllScreen(
            apartments = apartments,
            store = store,
            onBack = { waterReportAllScreen = false; waterReport = true }
        )
        return
    }

    if (waterReportFetchApartmentId != null || waterReportAllFetch) {
        // Для общего отчёта берём ТОЛЬКО квартиры, для которых действительно
        // настроены счётчик воды + логин + пароль. Раньше здесь попадали все
        // квартиры с водой, включая квартиры без ЛК, и общий отчёт останавливался
        // на первой такой квартире.
        val configuredWaterIds = apartments
            .filter { store.hasConfiguredWaterReport(it.id) }
            .map { it.id }

        val targetId = if (waterReportAllFetch) {
            configuredWaterIds.getOrNull(waterReportAllIndex)
        } else waterReportFetchApartmentId
        val a = apartments.firstOrNull { it.id == targetId }
        if (a != null) {
            waterReportApartmentScreenId = a.id
            waterReportFetchApartmentId = a.id
            return
        } else {
            waterReportAllFetch = false
            waterReportFetchApartmentId = null
            waterReport = true
            return
        }
    }

    if (waterReport) {
        WaterReportHubScreen(
            apartments = apartments,
            store = store,
            onFetchApartment = { id ->
                val a = apartments.firstOrNull { it.id == id }
                if (a != null && a.meters.any { it.type == MeterType.WATER } &&
                    store.waterLogin(id).isNotBlank() &&
                    store.get("water_password_$id").isNotBlank()) {
                    waterReportApartmentScreenId = id
                    waterReportFetchApartmentId = id
                    waterReport = false
                }
            },
            onFetchAll = {
                val configuredIds = apartments
                    .filter { store.hasConfiguredWaterReport(it.id) }
                    .map { it.id }
                waterReportAllIndex = 0
                waterReportAllFetch = configuredIds.isNotEmpty()
                waterReport = false
            },
            onBack = { waterReport = false; reports = true }
        )
        return
    }

    if (webUrl != null && jobs.isNotEmpty()) {
        val job = jobs[activeJobIndex]
        ProviderScreen(
            url = webUrl!!,
            job = job,
            index = activeJobIndex + 1,
            total = jobs.size,
            store = store,
            onWebViewReady = { webViewRef = it },
            onStatus = { updateStatus(job, it) },
            onNext = { nextJob() },
            onBack = { returnApartmentId = job.apartmentId; webUrl = null }
        )
        return
    }

    val mainListState = rememberLazyListState()
    LaunchedEffect(returnApartmentId, apartments) {
        val targetId = returnApartmentId ?: return@LaunchedEffect
        val apartmentIndex = apartments.indexOfFirst { it.id == targetId }
        if (apartmentIndex >= 0) {
            // Перед квартирами есть один общий элемент, затем для каждой квартиры
            // идут stickyHeader + содержимое. Поэтому нужный header имеет такой индекс.
            val headerIndex = 1 + apartmentIndex * 2
            mainListState.scrollToItem(headerIndex)
        }
        returnApartmentId = null
    }

    Scaffold(topBar = { TopAppBar(title = {}, actions = { TextButton(onClick = { reports = true }) { Text("Отчёты") }; TextButton(onClick = { settingsApartmentId = null; settings = true }) { Text("Настройки") }; TextButton(onClick = { help = true }) { Text("Справка") }; TextButton(onClick = { activity?.finishAffinity() }) { Text("Выход") } }) }, bottomBar = {
        Button(onClick = { startJobs(apartments.flatMap { a -> orderedJobs(a) }) }, modifier = Modifier.fillMaxWidth().padding(12.dp)) { Text("Передать всё — все квартиры") }
    }) { padding ->
        Column(Modifier.fillMaxSize()) {
            Surface(Modifier.fillMaxWidth(), tonalElevation = 4.dp) {
                Text("КОНТРОЛЬНАЯ ВЕРСИЯ 1.04", modifier = Modifier.padding(16.dp), style = MaterialTheme.typography.headlineSmall)
            }
            LazyColumn(state = mainListState, modifier = Modifier.weight(1f).padding(padding).padding(12.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            item {
                OutlinedButton(onClick = { clearAllReadings() }, modifier = Modifier.fillMaxWidth()) { Text("Очистить показания всех квартир") }
            }
            apartments.forEach { apartment ->
                stickyHeader(key = "apartment-address-${apartment.id}") {
                    Surface(
                        Modifier
                            .fillMaxWidth()
                            .clickable { settingsApartmentId = apartment.id; settings = true },
                        color = LocalAppColors.current.color(LocalAppColors.current.headerBackground, MaterialTheme.colorScheme.primaryContainer),
                        contentColor = LocalAppColors.current.color(LocalAppColors.current.headerText, MaterialTheme.colorScheme.onPrimaryContainer),
                        tonalElevation = 6.dp
                    ) {
                        Column(
                            modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp),
                            verticalArrangement = Arrangement.spacedBy(2.dp)
                        ) {
                            Text(
                                store.get("apartment_label_${apartment.id}", "Кв. ${apartment.id}"),
                                color = LocalAppColors.current.color(LocalAppColors.current.headerText, MaterialTheme.colorScheme.onPrimaryContainer),
                                style = MaterialTheme.typography.bodySmall,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                            Text(
                                apartment.address,
                                color = LocalAppColors.current.color(LocalAppColors.current.headerText, MaterialTheme.colorScheme.onPrimaryContainer),
                                style = MaterialTheme.typography.titleMedium,
                                maxLines = 2,
                                overflow = TextOverflow.Ellipsis
                            )
                        }
                    }
                }
                item(key = "apartment-content-${apartment.id}") {
                Card(Modifier.fillMaxWidth()) { Column(Modifier.padding(12.dp)) {
                    val meterGroups = listOf(MeterType.ELECTRICITY, MeterType.WATER, MeterType.GAS)
                        .map { type -> type to apartment.meters.filter { it.type == type } }
                        .filter { it.second.isNotEmpty() }

                    meterGroups.forEach { (type, groupMeters) ->
                        val typeJobs = orderedJobs(apartment, groupMeters)
                        Column(
                            modifier = Modifier.fillMaxWidth(),
                            verticalArrangement = Arrangement.spacedBy(0.dp)
                        ) {
                            groupMeters.forEachIndexed { index, meter ->
                                val previous = store.previousReading(meter.id)
                                Box(modifier = Modifier.fillMaxWidth()) {
                                    OutlinedTextField(
                                        value = meter.reading,
                                        onValueChange = { v -> updateMeter(apartment.id, meter.id, reading = v, status = "Не передано") },
                                        label = { Text("${meter.title} — новое показание") },
                                        singleLine = true,
                                        modifier = Modifier.fillMaxWidth()
                                    )
                                    if (previous.isNotBlank()) {
                                        Text(
                                            text = "Предыдущее: $previous",
                                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                                            style = MaterialTheme.typography.bodySmall,
                                            maxLines = 1,
                                            softWrap = false,
                                            overflow = TextOverflow.Ellipsis,
                                            modifier = Modifier
                                                .align(Alignment.BottomStart)
                                                .padding(start = 16.dp, bottom = 6.dp)
                                        )
                                    }
                                }
                                if (meter.type == MeterType.WATER && meter.serial.isNotBlank()) {
                                    Text(
                                        text = "Заводской №: ${meter.serial}",
                                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                                        style = MaterialTheme.typography.bodySmall,
                                        maxLines = 1,
                                        softWrap = false,
                                        overflow = TextOverflow.Ellipsis,
                                        modifier = Modifier.padding(start = 16.dp, top = 2.dp, bottom = 2.dp)
                                    )
                                }
                                Row(
                                    Modifier
                                        .fillMaxWidth()
                                        .height(36.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text(
                                        meter.status,
                                        modifier = Modifier.weight(1f),
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis
                                    )
                                    if (index == groupMeters.lastIndex) {
                                        Button(
                                            onClick = { startJobs(typeJobs) },
                                            enabled = typeJobs.isNotEmpty(),
                                            contentPadding = PaddingValues(horizontal = 14.dp, vertical = 0.dp),
                                            modifier = Modifier.height(36.dp).padding(start = 6.dp)
                                        ) {
                                            Text("Передать")
                                        }
                                    }
                                    TextButton(
                                        onClick = { clearMeterReading(apartment.id, meter.id) },
                                        contentPadding = PaddingValues(horizontal = 8.dp, vertical = 0.dp),
                                        modifier = Modifier.height(36.dp)
                                    ) {
                                        Text("Очистить")
                                    }
                                }
                            }
                        }
                    }
                    Spacer(Modifier.height(6.dp))
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        OutlinedButton(onClick = { clearApartmentReadings(apartment.id) }, modifier = Modifier.weight(1f).height(40.dp)) { Text("Очистить всё") }
                        Button(onClick = { startJobs(orderedJobs(apartment)) }, modifier = Modifier.weight(1f).height(40.dp)) { Text("Передать всё") }
                    }
                } }
                }
            }
        }
        }
    }
    @Suppress("UNUSED_VARIABLE") val _keep = credentialsVersion
}

@Composable
private fun SettingsScreen(
    apartments: List<Apartment>,
    store: LocalStore,
    initialApartmentId: Int?,
    onUpdateAddress: (Int, String) -> Unit,
    onUpdateSerial: (Int, String) -> Unit,
    onUpdateTitle: (Int, String) -> Unit,
    onAddMeter: (Int, MeterType) -> Unit,
    onDeleteMeter: (Int, Int) -> Unit,
    onAddApartment: () -> Unit,
    onDeleteApartment: (Int) -> Unit,
    onSaved: () -> Unit,
    onExportSettings: () -> Unit,
    onImportSettings: () -> Unit,
    onColorsChanged: () -> Unit,
    onBack: () -> Unit
) {
    var selectedId by remember(initialApartmentId) { mutableIntStateOf(initialApartmentId ?: apartments.firstOrNull()?.id ?: 1) }
    var selectedTab by remember { mutableIntStateOf(0) }
    var address by remember { mutableStateOf("") }
    var apartmentLabel by remember { mutableStateOf("") }
    var showDeleteConfirmation by remember { mutableStateOf(false) }
    var showDeleteMeterConfirmation by remember { mutableStateOf(false) }
    var pendingDeleteMeterId by remember { mutableIntStateOf(-1) }
    var pendingDeleteMeterTitle by remember { mutableStateOf("") }
    var energySurname by remember { mutableStateOf("") }
    var energyAccount by remember { mutableStateOf("") }
    var energySerial by remember { mutableStateOf("") }
    var waterLogin by remember { mutableStateOf("") }
    var waterPassword by remember { mutableStateOf("") }
    var gasLogin by remember { mutableStateOf("") }
    var gasPassword by remember { mutableStateOf("") }
    var energyUrl by remember { mutableStateOf(ENERGY) }
    var waterUrl by remember { mutableStateOf(WATER) }
    var gasUrl by remember { mutableStateOf(GAS) }
    var showWaterPassword by remember { mutableStateOf(false) }
    var showGasPassword by remember { mutableStateOf(false) }
    val waterSerials = remember { mutableStateMapOf<Int, String>() }
    val meterTitles = remember { mutableStateMapOf<Int, String>() }

    fun loadApartment(id: Int) {
        val a = apartments.firstOrNull { it.id == id } ?: return
        selectedId = id
        address = store.get("address_$id", a.address)
        apartmentLabel = store.get("apartment_label_$id", "Кв. $id")
        energySurname = store.get("energy_surname_$id")
        energyAccount = store.get("energy_account_$id")
        energySerial = store.get("energy_serial_$id")
        waterLogin = store.waterLogin(id)
        waterPassword = store.get("water_password_$id")
        gasLogin = store.get("gas_login_$id")
        gasPassword = store.get("gas_password_$id")
        energyUrl = store.providerUrl(id, MeterType.ELECTRICITY)
        waterUrl = store.providerUrl(id, MeterType.WATER)
        gasUrl = store.providerUrl(id, MeterType.GAS)
        waterSerials.clear()
        meterTitles.clear()
        a.meters.filter { it.type == MeterType.WATER }.forEach { m ->
            waterSerials[m.id] = store.get("serial_${m.id}")
            meterTitles[m.id] = store.meterTitle(id, m.id, m.title)
        }
        showWaterPassword = false
        showGasPassword = false
    }

    LaunchedEffect(initialApartmentId) {
        loadApartment(initialApartmentId ?: selectedId)
    }

    fun saveApartment(id: Int = selectedId) {
        // IMPORTANT: only write fields when id is the currently displayed apartment.
        // This prevents a stale Compose field from being written to another apartment.
        if (id != selectedId) return
        store.commitAddress("address_$id", address)
        store.put("apartment_label_$id", apartmentLabel.trim().ifBlank { "Кв. $id" })
        onUpdateAddress(id, address)
        store.put("energy_surname_$id", energySurname)
        store.put("energy_account_$id", energyAccount)
        store.put("energy_serial_$id", energySerial)
        store.put("water_login_$id", waterLogin)
        store.put("water_password_$id", waterPassword)
        store.put("gas_login_$id", gasLogin)
        store.put("gas_password_$id", gasPassword)
        store.saveProviderUrl(id, MeterType.ELECTRICITY, energyUrl.trim().ifBlank { ENERGY })
        store.saveProviderUrl(id, MeterType.WATER, waterUrl.trim().ifBlank { WATER })
        store.saveProviderUrl(id, MeterType.GAS, gasUrl.trim().ifBlank { GAS })
        apartments.firstOrNull { it.id == id }?.meters?.filter { it.type == MeterType.WATER }?.forEach { m ->
            val title = meterTitles[m.id].orEmpty().trim().ifBlank { m.title }
            val serial = waterSerials[m.id].orEmpty().trim()
            store.put("meter_title_${id}_${m.id}", title)
            onUpdateTitle(m.id, title)
            store.put("serial_${m.id}", serial)
            onUpdateSerial(m.id, serial)
        }
        apartments.firstOrNull { it.id == id }?.meters?.forEach { m ->
            if (m.type == MeterType.ELECTRICITY) {
                store.put("meter_title_${id}_${m.id}", m.title.trim().ifBlank { m.title })
            }
        }
        apartments.firstOrNull { it.id == id }?.meters?.forEach { m ->
            if (m.type == MeterType.ELECTRICITY && energySerial.isNotBlank()) onUpdateSerial(m.id, energySerial)
        }
        onSaved()
    }

    Scaffold(topBar = { TopAppBar(title = { Text("Настройки") }, navigationIcon = { TextButton(onClick = onBack) { Text("Назад") } }) }) { padding ->
        Column(Modifier.padding(padding)) {
            TabRow(selectedTabIndex = selectedTab) {
                Tab(selected = selectedTab == 0, onClick = { selectedTab = 0 }, text = { Text("Основные") })
                Tab(selected = selectedTab == 1, onClick = { selectedTab = 1 }, text = { Text("Цвета") })
            }
            if (selectedTab == 1) {
                ColorsSettingsScreen(store = store, onColorsChanged = onColorsChanged)
                return@Scaffold
            }
        LazyColumn(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            item {
                Text("Резервная копия настроек", style = MaterialTheme.typography.titleMedium)
                Text(
                    "При экспорте Android предложит выбрать имя и место сохранения файла. В файл входят квартиры, названия, показания, номера счётчиков, логины и другие настройки. Пароли также входят в файл резервной копии.",
                    style = MaterialTheme.typography.bodySmall
                )
                Spacer(Modifier.height(4.dp))
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedButton(onClick = onExportSettings, modifier = Modifier.weight(1f)) { Text("Экспорт настроек") }
                    OutlinedButton(onClick = onImportSettings, modifier = Modifier.weight(1f)) { Text("Импорт настроек") }
                }
            }
            item {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text("Квартиры", style = MaterialTheme.typography.titleMedium)
                    Button(onClick = { saveApartment(); onAddApartment() }) { Text("+ Добавить") }
                }
            }
            item {
                Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    apartments.forEach { apartment ->
                        Button(
                            onClick = {
                                if (selectedId != apartment.id) {
                                    saveApartment(selectedId)
                                    loadApartment(apartment.id)
                                }
                            },
                            enabled = selectedId != apartment.id,
                            contentPadding = PaddingValues(horizontal = 10.dp, vertical = 8.dp)
                        ) {
                            Column {
                                Text(
                                    store.get("apartment_label_${apartment.id}", "Кв. ${apartment.id}"),
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                                Text(
                                    store.apartmentAddress(apartment).ifBlank { "Без адреса" },
                                    maxLines = 2,
                                    overflow = TextOverflow.Ellipsis,
                                    style = MaterialTheme.typography.labelSmall
                                )
                            }
                        }
                    }
                }
            }
            item {
                OutlinedTextField(
                    apartmentLabel,
                    { apartmentLabel = it },
                    label = { Text("Название кнопки квартиры") },
                    supportingText = { Text("Это название будет показано вместо «Кв. $selectedId».") },
                    modifier = Modifier.fillMaxWidth()
                )
            }
            item { OutlinedTextField(address, { address = it }, label = { Text("Адрес") }, modifier = Modifier.fillMaxWidth()) }
            item {
                if (apartments.size > 1) {
                    OutlinedButton(
                        onClick = { showDeleteConfirmation = true },
                        modifier = Modifier.fillMaxWidth()
                    ) { Text("Удалить квартиру $selectedId") }
                }
            }
            item {
                Text("Поля для передачи показаний", style = MaterialTheme.typography.titleMedium)
                Text("Можно добавлять и удалять поля для воды и электричества. Газ остаётся отдельным полем.", style = MaterialTheme.typography.bodySmall)
            }
            item {
                Text("Электричество", style = MaterialTheme.typography.titleSmall)
                apartments.firstOrNull { it.id == selectedId }?.meters
                    ?.filter { it.type == MeterType.ELECTRICITY }
                    ?.forEach { meter ->
                        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                            OutlinedTextField(
                                value = meter.title,
                                onValueChange = { onUpdateTitle(meter.id, it) },
                                singleLine = true,
                                label = { Text("Название") },
                                modifier = Modifier.weight(1f)
                            )
                            TextButton(onClick = {
                                pendingDeleteMeterId = meter.id
                                pendingDeleteMeterTitle = meter.title
                                showDeleteMeterConfirmation = true
                            }) { Text("Удалить") }
                        }
                    }
            }
            item {
                Button(onClick = { onAddMeter(selectedId, MeterType.ELECTRICITY) }, modifier = Modifier.fillMaxWidth()) {
                    Text("+ Добавить свет")
                }
            }
            item {
                Text("Вода", style = MaterialTheme.typography.titleSmall)
                apartments.firstOrNull { it.id == selectedId }?.meters
                    ?.filter { it.type == MeterType.WATER }
                    ?.forEach { meter ->
                        Column(Modifier.fillMaxWidth()) {
                            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                                OutlinedTextField(
                                    value = meterTitles[meter.id].orEmpty().ifBlank { meter.title },
                                    onValueChange = { meterTitles[meter.id] = it },
                                    singleLine = true,
                                    label = { Text("Название") },
                                    modifier = Modifier.weight(1f)
                                )
                                TextButton(onClick = {
                                    pendingDeleteMeterId = meter.id
                                    pendingDeleteMeterTitle = meter.title
                                    showDeleteMeterConfirmation = true
                                }) { Text("Удалить") }
                            }
                            OutlinedTextField(
                                value = waterSerials[meter.id].orEmpty(),
                                onValueChange = { waterSerials[meter.id] = it },
                                label = { Text("Заводской номер ${meterTitles[meter.id].orEmpty().ifBlank { meter.title }}") },
                                singleLine = true,
                                supportingText = { Text("Этот номер используется для поиска такого же счётчика в ЛК Водоканала") },
                                modifier = Modifier.fillMaxWidth()
                            )
                        }
                    }
            }
            item {
                Button(onClick = { onAddMeter(selectedId, MeterType.WATER) }, modifier = Modifier.fillMaxWidth()) {
                    Text("+ Добавить воду")
                }
            }
            item { Text("Севэнергосбыт", style = MaterialTheme.typography.titleMedium) }
            item { OutlinedTextField(energySurname, { energySurname = it }, label = { Text("Фамилия") }, modifier = Modifier.fillMaxWidth()) }
            item { OutlinedTextField(energyAccount, { energyAccount = it }, label = { Text("Лицевой счёт") }, modifier = Modifier.fillMaxWidth()) }
            item { OutlinedTextField(energySerial, { energySerial = it }, label = { Text("Номер счётчика") }, modifier = Modifier.fillMaxWidth()) }
            item { OutlinedTextField(energyUrl, { energyUrl = it }, label = { Text("Адрес личного кабинета") }, modifier = Modifier.fillMaxWidth()) }
            item { Text("Водоканал", style = MaterialTheme.typography.titleMedium) }
            item { OutlinedTextField(waterLogin, { waterLogin = it }, label = { Text("Лицевой счёт / логин") }, modifier = Modifier.fillMaxWidth()) }
            item { OutlinedTextField(waterPassword, { waterPassword = it }, label = { Text("Пароль") }, visualTransformation = if (showWaterPassword) androidx.compose.ui.text.input.VisualTransformation.None else PasswordVisualTransformation(), trailingIcon = { TextButton(onClick = { showWaterPassword = !showWaterPassword }) { Text(if (showWaterPassword) "Скрыть" else "Показать") } }, modifier = Modifier.fillMaxWidth()) }
            item { OutlinedTextField(waterUrl, { waterUrl = it }, label = { Text("Адрес личного кабинета") }, modifier = Modifier.fillMaxWidth()) }
            item { Text("Севгаз", style = MaterialTheme.typography.titleMedium) }
            item { OutlinedTextField(gasLogin, { gasLogin = it }, label = { Text("Логин") }, modifier = Modifier.fillMaxWidth()) }
            item { OutlinedTextField(gasPassword, { gasPassword = it }, label = { Text("Пароль") }, visualTransformation = if (showGasPassword) androidx.compose.ui.text.input.VisualTransformation.None else PasswordVisualTransformation(), trailingIcon = { TextButton(onClick = { showGasPassword = !showGasPassword }) { Text(if (showGasPassword) "Скрыть" else "Показать") } }, modifier = Modifier.fillMaxWidth()) }
            item { OutlinedTextField(gasUrl, { gasUrl = it }, label = { Text("Адрес личного кабинета") }, modifier = Modifier.fillMaxWidth()) }
            item { Text("Адреса личных кабинетов сохраняются отдельно для каждой квартиры.") }
            item { Text("Пароли сохраняются только на этом телефоне.") }
            item { Button(onClick = { saveApartment() }, modifier = Modifier.fillMaxWidth()) { Text("Сохранить") } }
        }
    }

    if (showDeleteMeterConfirmation) {
        AlertDialog(
            onDismissRequest = { showDeleteMeterConfirmation = false },
            title = { Text("Удалить поле?") },
            text = { Text("Удалить поле «${pendingDeleteMeterTitle.ifBlank { "Счётчик" }}»? Показания этого счётчика будут удалены из настроек.") },
            confirmButton = {
                TextButton(onClick = {
                    showDeleteMeterConfirmation = false
                    if (pendingDeleteMeterId >= 0) onDeleteMeter(selectedId, pendingDeleteMeterId)
                    pendingDeleteMeterId = -1
                    pendingDeleteMeterTitle = ""
                }) { Text("Удалить") }
            },
            dismissButton = { TextButton(onClick = { showDeleteMeterConfirmation = false }) { Text("Отмена") } }
        )
    }

    if (showDeleteConfirmation) {
        AlertDialog(
            onDismissRequest = { showDeleteConfirmation = false },
            title = { Text("Удалить квартиру?") },
            text = {
                Text(
                    "Квартира «${apartmentLabel.ifBlank { "Кв. $selectedId" }}» будет удалена вместе с её настройками. Это действие нельзя отменить."
                )
            },
            confirmButton = {
                TextButton(
                    onClick = {
                        showDeleteConfirmation = false
                        val deletedId = selectedId
                        saveApartment(deletedId)
                        onDeleteApartment(deletedId)
                        val next = apartments.firstOrNull { it.id != deletedId }
                        if (next != null) loadApartment(next.id)
                    }
                ) { Text("Удалить") }
            },
            dismissButton = {
                TextButton(onClick = { showDeleteConfirmation = false }) { Text("Отмена") }
            }
        )
    }
}
}


data class ElectricityReportData(val apartment:String,val address:String,val generatedAt:String,val debt:String,val accrued:String,val paid:String,val reading:String)

private fun electricityReportKey(id:Int, field:String) = "electricity_report_${field}_$id"

@Composable private fun ElectricityReportHubScreen(apartments:List<Apartment>, store:LocalStore, onFetchApartment:(Int)->Unit, onBack:()->Unit) {
    Scaffold(topBar={ TopAppBar(title={Text("Отчёт по свету")}, navigationIcon={TextButton(onClick=onBack){Text("Назад")}}) }) { padding ->
        LazyColumn(Modifier.padding(padding).padding(12.dp), verticalArrangement=Arrangement.spacedBy(10.dp)) {
            item { Text("Пока доступен отчёт только для одной квартиры. Для входа в ЛК используется ручная CAPTCHA.", style=MaterialTheme.typography.bodySmall) }
            items(apartments.filter { it.id == 1 }, key={it.id}) { a ->
                Button(onClick={onFetchApartment(a.id)}, modifier=Modifier.fillMaxWidth()) { Text("Получить отчёт — Квартира ${a.id}") }
            }
        }
    }
}

@Composable private fun ElectricityReportScreen(apartment:Apartment?, store:LocalStore, refreshVersion:Int, onFetch:(Int)->Unit, onBack:()->Unit) {
    val id=apartment?.id ?: 1
    val data=ElectricityReportData("Квартира $id", apartment?.let{store.apartmentAddress(it)}.orEmpty(), store.get(electricityReportKey(id,"generated")).ifBlank{"Не выгружался"}, store.get(electricityReportKey(id,"debt")).ifBlank{"Не получено"}, store.get(electricityReportKey(id,"accrued")).ifBlank{"Не получено"}, store.get(electricityReportKey(id,"paid")).ifBlank{"Не получено"}, store.get(electricityReportKey(id,"reading")).ifBlank{"Не получено"})
    Scaffold(topBar={TopAppBar(title={Text("Отчёт по свету — Кв. $id")}, navigationIcon={TextButton(onClick=onBack){Text("Назад")}})}) { padding ->
        LazyColumn(Modifier.padding(padding).padding(12.dp), verticalArrangement=Arrangement.spacedBy(10.dp)) {
            item{Text(data.address,style=MaterialTheme.typography.titleMedium)}
            item{Text("Дата и время: ${data.generatedAt}",style=MaterialTheme.typography.bodySmall)}
            item{Text("Задолженность: ${data.debt}")}
            item{Text("Начислено: ${data.accrued}")}
            item{Text("Оплачено: ${data.paid}")}
            item{Text("Последнее показание: ${data.reading}")}
            item{Button(onClick={onFetch(id)},modifier=Modifier.fillMaxWidth()){Text("Получить отчёт")}}
            item{Text("При появлении CAPTCHA пройдите её вручную и нажмите «Войти». После входа данные считываются автоматически.",style=MaterialTheme.typography.bodySmall)}
        }
    }
}

data class GasReportData(
    val apartment: String,
    val address: String,
    val generatedAt: String,
    val supply: String,
    val maintenance: String
)

private fun gasReportHtml(data: GasReportData): String = """
<html><meta charset='utf-8'><body>
<h2>Отчёт по газу — ${data.apartment}</h2>
<p>${data.address}</p>
<table border='1' cellspacing='0' cellpadding='6'>
<tr><td>Газоснабжение</td><td>${data.supply}</td></tr>
<tr><td>Техобслуживание</td><td>${data.maintenance}</td></tr>
</table>
<p>Дата и время выгрузки: ${data.generatedAt}</p>
</body></html>
"""


private fun colorFromHex(value: String, fallback: Color = Color.Gray): Color =
    runCatching { Color(android.graphics.Color.parseColor(value)) }.getOrDefault(fallback)

private fun isLightColor(color: Color): Boolean {
    val r = color.red
    val g = color.green
    val b = color.blue
    return (0.299f * r + 0.587f * g + 0.114f * b) > 0.55f
}

private fun colorToHex(color: Color): String {
    val r = (color.red * 255f).roundToInt().coerceIn(0, 255)
    val g = (color.green * 255f).roundToInt().coerceIn(0, 255)
    val b = (color.blue * 255f).roundToInt().coerceIn(0, 255)
    return String.format(Locale.US, "#%02X%02X%02X", r, g, b)
}

private data class ColorThemePreset(val name: String, val colors: AppColors)

private fun colorThemePresets(): List<ColorThemePreset> = listOf(
    ColorThemePreset("Розовая", AppColors()),
    ColorThemePreset("Синяя", AppColors(
        background = "#F5F9FF", surface = "#FFFFFF", primary = "#1976D2", onPrimary = "#FFFFFF",
        secondary = "#455A64", onSecondary = "#FFFFFF", text = "#17212B", mutedText = "#607D8B",
        outline = "#90A4AE", fieldBackground = "#EAF3FF", fieldText = "#17212B",
        headerBackground = "#BBDEFB", headerText = "#0D47A1", progress = "#1976D2", cardBackground = "#FFFFFF"
    )),
    ColorThemePreset("Зелёная", AppColors(
        background = "#F5FBF6", surface = "#FFFFFF", primary = "#2E7D32", onPrimary = "#FFFFFF",
        secondary = "#558B2F", onSecondary = "#FFFFFF", text = "#1B2A1C", mutedText = "#607D63",
        outline = "#9BB59E", fieldBackground = "#EAF6EB", fieldText = "#1B2A1C",
        headerBackground = "#C8E6C9", headerText = "#1B5E20", progress = "#2E7D32", cardBackground = "#FFFFFF"
    )),
    ColorThemePreset("Тёмная", AppColors(
        background = "#17151A", surface = "#242127", primary = "#FF80AB", onPrimary = "#35101F",
        secondary = "#B39DDB", onSecondary = "#211A2D", text = "#F5EEF2", mutedText = "#C7BBC2",
        outline = "#5F5660", fieldBackground = "#302B34", fieldText = "#F5EEF2",
        headerBackground = "#5A3045", headerText = "#FFE5EE", progress = "#FF80AB", cardBackground = "#242127"
    )),
    ColorThemePreset("Песочная", AppColors(
        background = "#FFF9F0", surface = "#FFFFFF", primary = "#B56A1F", onPrimary = "#FFFFFF",
        secondary = "#7A5C3E", onSecondary = "#FFFFFF", text = "#33281F", mutedText = "#806F60",
        outline = "#C9B9A8", fieldBackground = "#FFF1DE", fieldText = "#33281F",
        headerBackground = "#FFE0B2", headerText = "#5D3510", progress = "#B56A1F", cardBackground = "#FFFFFF"
    )),
    ColorThemePreset("Windows XP", AppColors(
        background = "#ECE9D8", surface = "#FFFFFF", primary = "#316AC5", onPrimary = "#FFFFFF",
        secondary = "#3A8E3A", onSecondary = "#FFFFFF", text = "#003399", mutedText = "#666666",
        outline = "#7F9DB9", fieldBackground = "#FFFFFF", fieldText = "#000000",
        headerBackground = "#3A6EA5", headerText = "#FFFFFF", progress = "#316AC5", cardBackground = "#FFFFFF"
    )),
    ColorThemePreset("Windows 10", AppColors(
        background = "#F2F2F2", surface = "#FFFFFF", primary = "#0078D7", onPrimary = "#FFFFFF",
        secondary = "#5C5C5C", onSecondary = "#FFFFFF", text = "#1F1F1F", mutedText = "#666666",
        outline = "#BFBFBF", fieldBackground = "#FFFFFF", fieldText = "#1F1F1F",
        headerBackground = "#0078D7", headerText = "#FFFFFF", progress = "#0078D7", cardBackground = "#FFFFFF"
    )),
    ColorThemePreset("Windows 11", AppColors(
        background = "#F3F6FA", surface = "#FFFFFF", primary = "#0067C0", onPrimary = "#FFFFFF",
        secondary = "#4F5D6B", onSecondary = "#FFFFFF", text = "#202020", mutedText = "#6B7280",
        outline = "#D0D7DE", fieldBackground = "#F8FAFC", fieldText = "#202020",
        headerBackground = "#DDEEFF", headerText = "#004A8F", progress = "#0067C0", cardBackground = "#FFFFFF"
    ))
)

@Composable
private fun PaletteColorDialog(
    colorTitle: String,
    initial: String,
    onSelect: (String) -> Unit,
    onDismiss: () -> Unit
) {
    val palette = listOf(
        "#000000", "#FFFFFF", "#F44336", "#E91E63", "#9C27B0", "#673AB7", "#3F51B5", "#2196F3",
        "#03A9F4", "#00BCD4", "#009688", "#4CAF50", "#8BC34A", "#CDDC39", "#FFEB3B", "#FFC107",
        "#FF9800", "#FF5722", "#795548", "#9E9E9E", "#607D8B", "#F8BBD0", "#C2185B", "#8E4A68",
        "#FFF7FB", "#FFF0F6", "#E3F2FD", "#E8F5E9", "#FFF3E0", "#F3E5F5", "#FFFDE7", "#ECEFF1"
    )
    var selected by remember(initial) { mutableStateOf(colorFromHex(initial)) }
    var hsv by remember(initial) {
        mutableStateOf(FloatArray(3).also { android.graphics.Color.colorToHSV(colorFromHex(initial).toArgb(), it) })
    }
    var hexText by remember(initial) { mutableStateOf(colorToHex(colorFromHex(initial))) }
    var hexError by remember(initial) { mutableStateOf(false) }

    fun setSelected(color: Color, exactHex: String? = null) {
        selected = color
        android.graphics.Color.colorToHSV(color.toArgb(), hsv)
        hsv = hsv.copyOf()
        hexText = exactHex ?: colorToHex(color)
        hexError = false
    }

    fun setFromHex(raw: String) {
        val normalized = raw.trim().let { if (it.startsWith("#")) it else "#$it" }
        if (normalized.matches(Regex("#[0-9A-Fa-f]{6}"))) {
            setSelected(colorFromHex(normalized))
        }
    }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Цвет: $colorTitle") },
        text = {
            Column(
                modifier = Modifier.verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Text("Готовая палитра", style = MaterialTheme.typography.titleSmall)
                Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    palette.chunked(8).forEach { row ->
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            row.forEach { hex ->
                                Box(
                                    Modifier.size(34.dp)
                                        .background(colorFromHex(hex), MaterialTheme.shapes.small)
                                        .clickable { setSelected(colorFromHex(hex), hex) }
                                )
                            }
                        }
                    }
                }
                HorizontalDivider()
                Text("Точный цвет", style = MaterialTheme.typography.titleSmall)
                Text("Введите HEX — пример справа/ниже должен совпадать с ним точно.", style = MaterialTheme.typography.bodySmall)
                OutlinedTextField(
                    value = hexText,
                    onValueChange = { value ->
                        val filtered = value.uppercase(Locale.US).filter { it == '#' || it.isDigit() || it in 'A'..'F' }.take(7)
                        hexText = filtered
                        val normalized = filtered.let { if (it.startsWith("#")) it else "#$it" }
                        if (normalized.matches(Regex("#[0-9A-F]{6}"))) {
                            setSelected(colorFromHex(normalized))
                        } else {
                            hexError = filtered.isNotEmpty()
                        }
                    },
                    label = { Text("HEX") },
                    placeholder = { Text("#RRGGBB") },
                    singleLine = true,
                    isError = hexError,
                    supportingText = { if (hexError) Text("Формат: #RRGGBB") },
                    modifier = Modifier.fillMaxWidth()
                )
                Surface(Modifier.fillMaxWidth(), color = selected, shape = MaterialTheme.shapes.medium) {
                    Column(Modifier.padding(12.dp)) {
                        Text("Пример цвета", color = if (isLightColor(selected)) Color.Black else Color.White, style = MaterialTheme.typography.bodySmall)
                        Text(colorToHex(selected), color = if (isLightColor(selected)) Color.Black else Color.White, style = MaterialTheme.typography.titleMedium)
                    }
                }
                Box(
                    Modifier.fillMaxWidth().height(190.dp).background(
                        Brush.verticalGradient(listOf(Color.White, Color.Transparent, Color.Black)),
                        MaterialTheme.shapes.medium
                    )
                ) {
                    Box(
                        Modifier.fillMaxSize().background(
                            Brush.horizontalGradient((0..360 step 30).map { Color(android.graphics.Color.HSVToColor(floatArrayOf(it.toFloat(), 1f, 1f))) }),
                            MaterialTheme.shapes.medium
                        ).pointerInput(Unit) {
                            detectDragGestures(
                                onDragStart = { offset ->
                                    val sat = (offset.x / size.width.toFloat()).coerceIn(0f, 1f)
                                    val value = (1f - offset.y / size.height.toFloat()).coerceIn(0f, 1f)
                                    hsv = hsv.copyOf().also { it[1] = sat; it[2] = value }
                                    setSelected(Color(android.graphics.Color.HSVToColor(hsv)))
                                },
                                onDrag = { change, _ ->
                                    val sat = (change.position.x / size.width.toFloat()).coerceIn(0f, 1f)
                                    val value = (1f - change.position.y / size.height.toFloat()).coerceIn(0f, 1f)
                                    hsv = hsv.copyOf().also { it[1] = sat; it[2] = value }
                                    setSelected(Color(android.graphics.Color.HSVToColor(hsv)))
                                }
                            )
                        }
                    )
                }
                Text("Оттенок", style = MaterialTheme.typography.titleSmall)
                Text("Переместите ползунок, чтобы изменить оттенок выбранного цвета.", style = MaterialTheme.typography.bodySmall)
                Box(
                    Modifier.fillMaxWidth().height(44.dp)
                        .background(
                            Brush.horizontalGradient((0..360 step 30).map { Color(android.graphics.Color.HSVToColor(floatArrayOf(it.toFloat(), 1f, 1f))) }),
                            MaterialTheme.shapes.small
                        )
                        .pointerInput(Unit) {
                            detectDragGestures(
                                onDragStart = { offset ->
                                    hsv = hsv.copyOf().also {
                                        it[0] = (offset.x / size.width.toFloat() * 360f).coerceIn(0f, 360f)
                                        it[1] = 1f
                                        it[2] = 1f
                                    }
                                    setSelected(Color(android.graphics.Color.HSVToColor(hsv)))
                                },
                                onDrag = { change, _ ->
                                    hsv = hsv.copyOf().also {
                                        it[0] = (change.position.x / size.width.toFloat() * 360f).coerceIn(0f, 360f)
                                        it[1] = 1f
                                        it[2] = 1f
                                    }
                                    setSelected(Color(android.graphics.Color.HSVToColor(hsv)))
                                }
                            )
                        }) {
                    androidx.compose.foundation.Canvas(Modifier.matchParentSize()) {
                        val x = (hsv[0] / 360f).coerceIn(0f, 1f) * size.width
                        drawCircle(
                            color = Color.White,
                            radius = 10.dp.toPx(),
                            center = androidx.compose.ui.geometry.Offset(x, size.height / 2f)
                        )
                        drawCircle(
                            color = Color.Black,
                            radius = 7.dp.toPx(),
                            center = androidx.compose.ui.geometry.Offset(x, size.height / 2f),
                            style = androidx.compose.ui.graphics.drawscope.Stroke(width = 2.dp.toPx())
                        )
                    }
                }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    val normalized = hexText.trim().let { if (it.startsWith("#")) it else "#$it" }
                    if (normalized.matches(Regex("#[0-9A-Fa-f]{6}"))) {
                        onSelect(normalized.uppercase(Locale.US))
                        onDismiss()
                    } else {
                        hexError = true
                    }
                }
            ) { Text("Выбрать") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Отмена") } }
    )
}

@Composable
private fun ColorsSettingsScreen(store: LocalStore, onColorsChanged: () -> Unit) {
    val defaults = AppColors()
    var colors by remember { mutableStateOf(AppColors.from(store)) }
    var pickerKey by remember { mutableStateOf<String?>(null) }
    var saveThemeDialog by remember { mutableStateOf(false) }
    var renameThemeIndex by remember { mutableIntStateOf(-1) }
    var themeName by remember { mutableStateOf("") }
    var savedThemes by remember { mutableStateOf(loadSavedColorThemes(store)) }
    val themeListState = rememberLazyListState()

    fun set(key: String, value: String) {
        colors = when (key) {
            "background" -> colors.copy(background = value); "surface" -> colors.copy(surface = value)
            "primary" -> colors.copy(primary = value); "onPrimary" -> colors.copy(onPrimary = value)
            "secondary" -> colors.copy(secondary = value); "onSecondary" -> colors.copy(onSecondary = value)
            "text" -> colors.copy(text = value); "mutedText" -> colors.copy(mutedText = value)
            "outline" -> colors.copy(outline = value); "fieldBackground" -> colors.copy(fieldBackground = value)
            "fieldText" -> colors.copy(fieldText = value); "headerBackground" -> colors.copy(headerBackground = value)
            "headerText" -> colors.copy(headerText = value); "progress" -> colors.copy(progress = value)
            else -> colors.copy(cardBackground = value)
        }
        colors.saveTo(store); onColorsChanged(); pickerKey = null
    }

    val items = listOf(
        Triple("Фон приложения", "background", colors.background), Triple("Фон областей", "surface", colors.surface),
        Triple("Кнопки", "primary", colors.primary), Triple("Текст кнопок", "onPrimary", colors.onPrimary),
        Triple("Дополнительные кнопки", "secondary", colors.secondary), Triple("Текст дополнительных кнопок", "onSecondary", colors.onSecondary),
        Triple("Основной текст", "text", colors.text), Triple("Вторичный текст", "mutedText", colors.mutedText),
        Triple("Контуры полей", "outline", colors.outline), Triple("Фон полей ввода", "fieldBackground", colors.fieldBackground),
        Triple("Текст полей ввода", "fieldText", colors.fieldText), Triple("Фон stickyHeader", "headerBackground", colors.headerBackground),
        Triple("Текст stickyHeader", "headerText", colors.headerText), Triple("Прогресс", "progress", colors.progress),
        Triple("Фон карточек", "cardBackground", colors.cardBackground)
    )

    LazyColumn(Modifier.fillMaxSize().padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        item {
            Text("Настройка цветов", style = MaterialTheme.typography.titleMedium)
            Text("Нажмите на цвет — откроется палитра. HEX вводить не нужно.", style = MaterialTheme.typography.bodySmall)
        }
        item {
            Text("Готовые темы", style = MaterialTheme.typography.titleMedium)
            Text("Выберите готовое оформление одним нажатием.", style = MaterialTheme.typography.bodySmall)
        }
        items(colorThemePresets().chunked(2)) { row ->
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                row.forEach { preset ->
                    OutlinedButton(onClick = { colors = preset.colors; preset.colors.saveTo(store); onColorsChanged() }, modifier = Modifier.weight(1f), contentPadding = PaddingValues(8.dp)) {
                        Surface(Modifier.size(28.dp), color = colorFromHex(preset.colors.primary), shape = MaterialTheme.shapes.small) {}
                        Spacer(Modifier.width(8.dp)); Text(preset.name, maxLines = 1)
                    }
                }
                if (row.size == 1) Spacer(Modifier.weight(1f))
            }
        }
        item {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Button(onClick = { themeName = ""; saveThemeDialog = true }, modifier = Modifier.weight(1f)) { Text("Добавить свою тему") }
                OutlinedButton(onClick = { colors = defaults; defaults.saveTo(store); onColorsChanged() }, modifier = Modifier.weight(1f)) { Text("Сбросить") }
            }
        }
        item {
            Text("Мои темы", style = MaterialTheme.typography.titleMedium)
            Text("Можно сохранять любое количество тем. Список прокручивается влево; одновременно видно не более 5 столбцов.", style = MaterialTheme.typography.bodySmall)
            if (savedThemes.isEmpty()) {
                Text("Сохранённых тем пока нет.", style = MaterialTheme.typography.bodySmall, modifier = Modifier.padding(top = 8.dp))
            } else {
                LaunchedEffect(savedThemes.size) { themeListState.animateScrollToItem(0) }
                BoxWithConstraints(Modifier.fillMaxWidth()) {
                    val themeCardWidth = ((maxWidth - 32.dp) / 5f).coerceAtLeast(60.dp)
                    LazyRow(
                        state = themeListState,
                        modifier = Modifier.fillMaxWidth().padding(top = 8.dp),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        itemsIndexed(savedThemes, key = { index, _ -> "saved-theme-$index" }) { index, theme ->
                        OutlinedButton(
                            onClick = { colors = theme.colors; theme.colors.saveTo(store); onColorsChanged() },
                            modifier = Modifier.width(themeCardWidth).height(76.dp),
                            contentPadding = PaddingValues(8.dp)
                        ) {
                            Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(4.dp)) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Surface(Modifier.size(22.dp), color = colorFromHex(theme.colors.primary), shape = MaterialTheme.shapes.small) {}
                                    Spacer(Modifier.width(6.dp))
                                    Text(theme.name, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                }
                                TextButton(onClick = { renameThemeIndex = index; themeName = theme.name }, contentPadding = PaddingValues(horizontal = 8.dp, vertical = 0.dp)) { Text("Переименовать") }
                            }
                        }
                    }
                }
            }
        }
        items(items, key = { it.second }) { (label, key, value) ->
            OutlinedButton(onClick = { pickerKey = key }, modifier = Modifier.fillMaxWidth(), contentPadding = PaddingValues(10.dp)) {
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                    Surface(Modifier.size(38.dp), color = colorFromHex(value), shape = MaterialTheme.shapes.small) {}
                    Spacer(Modifier.width(12.dp)); Text(label, modifier = Modifier.weight(1f), textAlign = androidx.compose.ui.text.style.TextAlign.Start)
                    Text("Выбрать", style = MaterialTheme.typography.bodySmall)
                }
            }
        }
        item {
            Surface(Modifier.fillMaxWidth(), color = colors.color(colors.headerBackground, MaterialTheme.colorScheme.primaryContainer), shape = MaterialTheme.shapes.medium) {
                Column(Modifier.padding(12.dp)) {
                    Text("Пример stickyHeader", color = colors.color(colors.headerText, MaterialTheme.colorScheme.onPrimaryContainer), style = MaterialTheme.typography.titleMedium)
                    Text("Кв. 1", color = colors.color(colors.headerText, MaterialTheme.colorScheme.onPrimaryContainer), style = MaterialTheme.typography.bodySmall)
                    Text("Адрес квартиры", color = colors.color(colors.headerText, MaterialTheme.colorScheme.onPrimaryContainer), style = MaterialTheme.typography.titleMedium)
                }
            }
        }
    }

    pickerKey?.let { key ->
        val current = items.first { it.second == key }.third
        PaletteColorDialog(colorTitle = items.first { it.second == key }.first, initial = current, onSelect = { set(key, it) }, onDismiss = { pickerKey = null })
    }

    if (saveThemeDialog || renameThemeIndex >= 0) {
        val renaming = renameThemeIndex >= 0
        AlertDialog(
            onDismissRequest = { saveThemeDialog = false; renameThemeIndex = -1 },
            title = { Text(if (renaming) "Переименовать тему" else "Сохранить свою тему") },
            text = {
                OutlinedTextField(value = themeName, onValueChange = { themeName = it }, label = { Text("Название темы") }, singleLine = true, modifier = Modifier.fillMaxWidth())
            },
            confirmButton = {
                Button(onClick = {
                    val name = themeName.trim().ifBlank { "Моя тема" }
                    if (renaming) {
                        savedThemes = savedThemes.mapIndexed { i, t -> if (i == renameThemeIndex) t.copy(name = name) else t }
                    } else {
                        savedThemes = listOf(SavedColorTheme(name, colors)) + savedThemes
                    }
                    saveSavedColorThemes(store, savedThemes)
                    saveThemeDialog = false; renameThemeIndex = -1; themeName = ""
                }) { Text(if (renaming) "Переименовать" else "Сохранить") }
            },
            dismissButton = { TextButton(onClick = { saveThemeDialog = false; renameThemeIndex = -1 }) { Text("Отмена") } }
        )
    }
}
}

private fun saveGasReportAsDoc(context: Context, uri: Uri, data: GasReportData) {
    context.contentResolver.openOutputStream(uri)?.use { it.write(gasReportHtml(data).toByteArray(Charsets.UTF_8)) }
}

private fun saveGasReportAsExcel(context: Context, uri: Uri, data: GasReportData) {
    context.contentResolver.openOutputStream(uri)?.use { it.write(gasReportHtml(data).toByteArray(Charsets.UTF_8)) }
}

private fun saveGasReportAsImage(context: Context, uri: Uri, data: GasReportData) {
    val bitmap = Bitmap.createBitmap(1200, 520, Bitmap.Config.ARGB_8888)
    val canvas = Canvas(bitmap)
    canvas.drawColor(android.graphics.Color.WHITE)
    val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = android.graphics.Color.BLACK; textSize = 34f }
    canvas.drawText("Отчёт по газу — ${data.apartment}", 60f, 70f, paint)
    paint.textSize = 25f
    canvas.drawText(data.address, 60f, 115f, paint)
    paint.textSize = 28f
    canvas.drawText("Газоснабжение:", 70f, 205f, paint); canvas.drawText(data.supply, 560f, 205f, paint)
    canvas.drawText("Техобслуживание:", 70f, 285f, paint); canvas.drawText(data.maintenance, 560f, 285f, paint)
    paint.textSize = 22f
    canvas.drawText("Дата и время выгрузки: ${data.generatedAt}", 60f, 365f, paint)
    context.contentResolver.openOutputStream(uri)?.use { bitmap.compress(Bitmap.CompressFormat.PNG, 100, it) }
    bitmap.recycle()
}

private fun gasReportKey(id: Int, field: String) = "gas_report_${field}_$id"

@Composable
private fun ReportsHubScreen(
    onElectricity: () -> Unit,
    onWater: () -> Unit,
    onGas: () -> Unit,
    onBack: () -> Unit
) {
    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Отчёты") },
                navigationIcon = { TextButton(onClick = onBack) { Text("Назад") } }
            )
        }
    ) { padding ->
        LazyColumn(
            Modifier.padding(padding).padding(12.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            item {
                Button(onClick = onElectricity, modifier = Modifier.fillMaxWidth()) {
                    Text("Отчёт по свету")
                }
            }
            item {
                Button(onClick = onWater, modifier = Modifier.fillMaxWidth()) {
                    Text("Отчёт по воде")
                }
            }
            item {
                Button(onClick = onGas, modifier = Modifier.fillMaxWidth()) {
                    Text("Отчёт по газу")
                }
            }
        }
    }
}

@Composable
private fun GasReportScreen(apartment: Apartment?, store: LocalStore, refreshVersion: Int, onFetch: (Int) -> Unit, onBack: () -> Unit) {
    val id = apartment?.id ?: 1
    val supply = remember(id, refreshVersion) { store.get(gasReportKey(id, "supply")) }
    val maintenance = remember(id, refreshVersion) { store.get(gasReportKey(id, "maintenance")) }
    val generatedAt = remember(id, refreshVersion) { store.get(gasReportKey(id, "generated")) }
    val data = GasReportData(
        "Квартира $id", apartment?.let { store.apartmentAddress(it) }.orEmpty(),
        generatedAt.ifBlank { "Не выгружался" },
        supply.ifBlank { "Не получено" }, maintenance.ifBlank { "Не получено" }
    )
    val context = LocalContext.current
    val docLauncher = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/msword")) { uri -> if (uri != null) saveGasReportAsDoc(context, uri, data) }
    val excelLauncher = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/vnd.ms-excel")) { uri -> if (uri != null) saveGasReportAsExcel(context, uri, data) }
    val imageLauncher = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("image/png")) { uri -> if (uri != null) saveGasReportAsImage(context, uri, data) }
    Scaffold(topBar = { TopAppBar(title = { Text("Отчёт по газу — Кв. $id") }, navigationIcon = { TextButton(onClick = onBack) { Text("Назад") } }) }) { padding ->
        LazyColumn(Modifier.padding(padding).padding(12.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            item { Text(data.address, style = MaterialTheme.typography.titleMedium) }
            item { Text("Дата и время выгрузки: ${data.generatedAt}", style = MaterialTheme.typography.bodySmall) }
            item { Text("Газоснабжение: ${data.supply}") }
            item { Text("Техобслуживание: ${data.maintenance}") }
            item { Button(onClick = { onFetch(id) }, modifier = Modifier.fillMaxWidth()) { Text("Получить отчёт — ${data.address.ifBlank { "Квартира $id" }}") } }
            item { Button(onClick = { docLauncher.launch("Отчёт_газ_кв_${id}.doc") }, modifier = Modifier.fillMaxWidth()) { Text("Сохранить DOC") } }
            item { Button(onClick = { excelLauncher.launch("Отчёт_газ_кв_${id}.xls") }, modifier = Modifier.fillMaxWidth()) { Text("Сохранить Excel") } }
            item { Button(onClick = { imageLauncher.launch("Отчёт_газ_кв_${id}.png") }, modifier = Modifier.fillMaxWidth()) { Text("Сохранить изображение") } }
        }
    }
}

private fun gasReportAllHtml(rows: List<GasReportRow>, generatedAt: String): String = buildString {
    append("<html><meta charset='utf-8'><body><h2>Отчёт газа — все квартиры</h2>")
    append("<p>Дата и время выгрузки: ").append(generatedAt).append("</p>")
    append("<table border='1' cellspacing='0' cellpadding='6'><tr><th>Квартира</th><th>Адрес</th><th>Газоснабжение</th><th>Техобслуживание</th><th>Дата и время выгрузки</th></tr>")
    rows.forEach { r -> append("<tr><td>Кв. ").append(r.apartment.id).append("</td><td>").append(r.apartment.address).append("</td><td>").append(r.supply).append("</td><td>").append(r.maintenance).append("</td><td>").append(r.generatedAt.ifBlank { "Не выгружался" }).append("</td></tr>") }
    append("</table></body></html>")
}

private data class GasReportRow(
    val apartment: Apartment,
    val supply: String,
    val maintenance: String,
    val generatedAt: String
)

@Composable
private fun GasReportAllScreen(apartments: List<Apartment>, store: LocalStore, onBack: () -> Unit) {
    val context = LocalContext.current
    val rows = apartments.filter { store.hasConfiguredGasReport(it.id) }.map { a ->
        GasReportRow(
            a.copy(address = store.apartmentAddress(a)),
            store.get(gasReportKey(a.id, "supply")),
            store.get(gasReportKey(a.id, "maintenance")),
            store.get(gasReportKey(a.id, "generated"))
        )
    }
    val docLauncher = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/msword")) { uri -> if (uri != null) context.contentResolver.openOutputStream(uri)?.use { it.write(gasReportAllHtml(rows, SimpleDateFormat("dd.MM.yyyy HH:mm", Locale.getDefault()).format(Date())).toByteArray(Charsets.UTF_8)) } }
    val excelLauncher = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/vnd.ms-excel")) { uri -> if (uri != null) context.contentResolver.openOutputStream(uri)?.use { it.write(gasReportAllHtml(rows, SimpleDateFormat("dd.MM.yyyy HH:mm", Locale.getDefault()).format(Date())).toByteArray(Charsets.UTF_8)) } }
    Scaffold(topBar = { TopAppBar(title = { Text("Отчёт газа — все квартиры") }, navigationIcon = { TextButton(onClick = onBack) { Text("Назад") } }) }) { padding ->
        LazyColumn(Modifier.padding(padding).padding(12.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            rows.forEach { r ->
                item {
                    Text("Квартира ${r.apartment.id}", style = MaterialTheme.typography.titleMedium)
                    Text(r.apartment.address)
                    Text("Газоснабжение: ${r.supply.ifBlank { "Не выгружено" }}")
                    Text("Техобслуживание: ${r.maintenance.ifBlank { "Не выгружено" }}")
                    Text("Дата и время выгрузки: ${r.generatedAt.ifBlank { "Не выгружалось" }}", style = MaterialTheme.typography.bodySmall)
                }
            }
            item { Button(onClick = { docLauncher.launch("Отчёт_газ_все_квартиры.doc") }, modifier = Modifier.fillMaxWidth()) { Text("Сохранить общий DOC") } }
            item { Button(onClick = { excelLauncher.launch("Отчёт_газ_все_квартиры.xls") }, modifier = Modifier.fillMaxWidth()) { Text("Сохранить общий Excel") } }
        }
    }
}

@Composable
private fun GasReportHubScreen(
    apartments: List<Apartment>,
    store: LocalStore,
    onFetchApartment: (Int) -> Unit,
    onFetchAll: () -> Unit,
    onBack: () -> Unit
) {
    Scaffold(topBar = { TopAppBar(title = { Text("Отчёт по газу") }, navigationIcon = { TextButton(onClick = onBack) { Text("Назад") } }) }) { padding ->
        LazyColumn(Modifier.padding(padding).padding(12.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            apartments.filter { store.hasConfiguredGasReport(it.id) }.forEach { apartment ->
                item {
                    Button(onClick = { onFetchApartment(apartment.id) }, modifier = Modifier.fillMaxWidth()) {
                        Text("Получить отчёт — ${store.apartmentAddress(apartment)}")
                    }
                }
            }
            if (apartments.any { store.hasConfiguredGasReport(it.id) }) {
                item {
                    Spacer(Modifier.height(8.dp))
                    Button(onClick = onFetchAll, modifier = Modifier.fillMaxWidth()) { Text("Получить отчёт всех квартир") }
                }
            }
            item {
                Text("Данные каждой квартиры берутся из её собственного ЛК Севгаз.", style = MaterialTheme.typography.bodySmall)
            }
        }
    }
}

data class WaterReportData(
    val apartment: String,
    val address: String,
    val generatedAt: String,
    val overpayment: String,
    val debt: String,
    val penalty: String
)

private fun waterReportHtml(data: WaterReportData): String = """
<!DOCTYPE html><html><head><meta charset="UTF-8"><title>Отчёт по воде</title>
<style>body{font-family:Arial,sans-serif;font-size:14pt;margin:32px}h1{font-size:20pt}table{border-collapse:collapse;width:100%}td{border:1px solid #999;padding:10px}td:first-child{font-weight:bold;width:55%}.date{color:#555}</style>
</head><body><h1>Отчёт по воде — ${data.apartment}</h1><p>${data.address}</p>
<table><tr><td>Переплата</td><td>${data.overpayment}</td></tr><tr><td>Задолженность</td><td>${data.debt}</td></tr><tr><td>Пеня</td><td>${data.penalty}</td></tr></table>
<p class="date">Дата и время выгрузки: ${data.generatedAt}</p></body></html>
""".trimIndent()

private fun saveWaterReportAsDoc(context: Context, uri: Uri, data: WaterReportData) {
    context.contentResolver.openOutputStream(uri)?.use { it.write(waterReportHtml(data).toByteArray(Charsets.UTF_8)) }
}

private fun saveWaterReportAsExcel(context: Context, uri: Uri, data: WaterReportData) {
    // Excel открывает HTML-таблицу с расширением .xls без дополнительных библиотек.
    context.contentResolver.openOutputStream(uri)?.use { it.write(waterReportHtml(data).toByteArray(Charsets.UTF_8)) }
}

private fun saveWaterReportAsImage(context: Context, uri: Uri, data: WaterReportData) {
    val width = 1200
    val height = 760
    val bitmap = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888)
    val canvas = Canvas(bitmap)
    canvas.drawColor(android.graphics.Color.WHITE)
    val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = android.graphics.Color.BLACK; textSize = 42f; typeface = Typeface.DEFAULT }
    canvas.drawText("Отчёт по воде — ${data.apartment}", 60f, 80f, paint)
    paint.textSize = 28f
    canvas.drawText(data.address, 60f, 130f, paint)
    paint.textSize = 34f
    canvas.drawText("Переплата:", 80f, 230f, paint); canvas.drawText(data.overpayment, 620f, 230f, paint)
    canvas.drawText("Задолженность:", 80f, 310f, paint); canvas.drawText(data.debt, 620f, 310f, paint)
    canvas.drawText("Пеня:", 80f, 390f, paint); canvas.drawText(data.penalty, 620f, 390f, paint)
    paint.textSize = 25f
    paint.color = android.graphics.Color.DKGRAY
    canvas.drawText("Дата и время выгрузки: ${data.generatedAt}", 60f, 500f, paint)
    context.contentResolver.openOutputStream(uri)?.use { bitmap.compress(Bitmap.CompressFormat.PNG, 100, it) }
    bitmap.recycle()
}

@Composable
private fun WaterReportHubScreen(
    apartments: List<Apartment>,
    store: LocalStore,
    onFetchApartment: (Int) -> Unit,
    onFetchAll: () -> Unit,
    onBack: () -> Unit
) {
    Scaffold(topBar = { TopAppBar(title = { Text("Отчёты воды") }, navigationIcon = { TextButton(onClick = onBack) { Text("Назад") } }) }) { padding ->
        LazyColumn(Modifier.padding(padding).padding(12.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            item { Text("Получение отчёта отдельно для каждой квартиры", style = MaterialTheme.typography.titleMedium) }
            apartments
                .filter { apartment ->
                    store.hasConfiguredWaterReport(apartment.id)
                }
                .forEach { apartment ->
                    item {
                        Button(onClick = { onFetchApartment(apartment.id) }, modifier = Modifier.fillMaxWidth()) {
                            Text("Получить отчёт — ${store.apartmentAddress(apartment)}")
                        }
                    }
                }
            val configuredApartments = apartments.filter { store.hasConfiguredWaterReport(it.id) }
            if (configuredApartments.isNotEmpty()) {
                item {
                    Spacer(Modifier.height(8.dp))
                    Button(onClick = onFetchAll, modifier = Modifier.fillMaxWidth()) {
                        Text("Получить отчёт всех квартир")
                    }
                }
            }
            item { Text("Данные каждой квартиры берутся из её собственного ЛК Водоканала.", style = MaterialTheme.typography.bodySmall) }
        }
    }
}

private data class WaterReportRow(
    val apartment: Apartment,
    val overpayment: String,
    val debt: String,
    val penalty: String
)

private fun waterReportKey(id: Int, field: String) = "water_report_${field}_$id"

@Composable
private fun WaterReportScreen(apartment: Apartment?, store: LocalStore, refreshVersion: Int = 0, onFetch: (Int) -> Unit, onBack: () -> Unit) {
    val context = LocalContext.current
    val id = apartment?.id ?: 1
    val now = remember { SimpleDateFormat("dd.MM.yyyy HH:mm", Locale.getDefault()).format(Date()) }
    var overpayment by remember(id, refreshVersion) { mutableStateOf(store.get(waterReportKey(id, "overpayment"))) }
    var debt by remember(id, refreshVersion) { mutableStateOf(store.get(waterReportKey(id, "debt"))) }
    var penalty by remember(id, refreshVersion) { mutableStateOf(store.get(waterReportKey(id, "penalty"))) }
    val data = WaterReportData(
        apartment = "Квартира $id",
        address = apartment?.let { store.apartmentAddress(it) } ?: "",
        generatedAt = now,
        overpayment = overpayment.ifBlank { "Не получено" },
        debt = debt.ifBlank { "Не получено" },
        penalty = penalty.ifBlank { "Не получено" }
    )
    val docLauncher = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/msword")) { uri -> if (uri != null) saveWaterReportAsDoc(context, uri, data) }
    val excelLauncher = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/vnd.ms-excel")) { uri -> if (uri != null) saveWaterReportAsExcel(context, uri, data) }
    val imageLauncher = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("image/png")) { uri -> if (uri != null) saveWaterReportAsImage(context, uri, data) }
    fun persist() {
        store.put(waterReportKey(id, "overpayment"), overpayment.trim())
        store.put(waterReportKey(id, "debt"), debt.trim())
        store.put(waterReportKey(id, "penalty"), penalty.trim())
    }
    Scaffold(topBar = { TopAppBar(title = { Text("Отчёт воды — Кв. $id") }, navigationIcon = { TextButton(onClick = { persist(); onBack() }) { Text("Назад") } }) }) { padding ->
        LazyColumn(Modifier.padding(padding).padding(12.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            item { Text(data.address, style = MaterialTheme.typography.titleMedium) }
            item { Text("Дата и время выгрузки: $now", style = MaterialTheme.typography.bodySmall) }
            item { Text("Финансовая информация", style = MaterialTheme.typography.titleMedium) }
            item { Button(onClick = { onFetch(id) }, modifier = Modifier.fillMaxWidth()) { Text("Получить данные из ЛК Водоканала") } }
            item { OutlinedTextField(overpayment, { overpayment = it; persist() }, label = { Text("Переплата") }, singleLine = true, modifier = Modifier.fillMaxWidth()) }
            item { OutlinedTextField(debt, { debt = it; persist() }, label = { Text("Задолженность") }, singleLine = true, modifier = Modifier.fillMaxWidth()) }
            item { OutlinedTextField(penalty, { penalty = it; persist() }, label = { Text("Пеня") }, singleLine = true, modifier = Modifier.fillMaxWidth()) }
            item { Text("Сохранить отчёт", style = MaterialTheme.typography.titleMedium) }
            item { Button(onClick = { persist(); docLauncher.launch("Отчёт_вода_Кв$id.doc") }, modifier = Modifier.fillMaxWidth()) { Text("Сохранить DOC") } }
            item { Button(onClick = { persist(); excelLauncher.launch("Отчёт_вода_Кв$id.xls") }, modifier = Modifier.fillMaxWidth()) { Text("Сохранить Excel") } }
            item { Button(onClick = { persist(); imageLauncher.launch("Отчёт_вода_Кв$id.png") }, modifier = Modifier.fillMaxWidth()) { Text("Сохранить как картинку") } }
        }
    }
}

private fun waterReportAllHtml(rows: List<WaterReportRow>, generatedAt: String): String = buildString {
    append("<html><meta charset='utf-8'><body><h2>Отчёт воды — все квартиры</h2>")
    append("<p>Дата и время выгрузки: ").append(generatedAt).append("</p>")
    append("<table border='1' cellspacing='0' cellpadding='6'><tr><th>Квартира</th><th>Адрес</th><th>Переплата</th><th>Задолженность</th><th>Пеня</th></tr>")
    rows.forEach { r -> append("<tr><td>Кв. ").append(r.apartment.id).append("</td><td>").append(r.apartment.address).append("</td><td>").append(r.overpayment).append("</td><td>").append(r.debt).append("</td><td>").append(r.penalty).append("</td></tr>") }
    append("</table></body></html>")
}

@Composable
private fun WaterReportAllScreen(apartments: List<Apartment>, store: LocalStore, onBack: () -> Unit) {
    val context = LocalContext.current
    val now = remember { SimpleDateFormat("dd.MM.yyyy HH:mm", Locale.getDefault()).format(Date()) }
    val rows = apartments
        .filter { a ->
            store.hasConfiguredWaterReport(a.id)
        }
        .map { a ->
            val address = store.apartmentAddress(a)
            WaterReportRow(
                a.copy(address = address),
                store.get(waterReportKey(a.id, "overpayment")),
                store.get(waterReportKey(a.id, "debt")),
                store.get(waterReportKey(a.id, "penalty"))
            )
        }
    val docLauncher = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/msword")) { uri -> if (uri != null) context.contentResolver.openOutputStream(uri)?.use { it.write(waterReportAllHtml(rows, now).toByteArray(Charsets.UTF_8)) } }
    val excelLauncher = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/vnd.ms-excel")) { uri -> if (uri != null) context.contentResolver.openOutputStream(uri)?.use { it.write(waterReportAllHtml(rows, now).toByteArray(Charsets.UTF_8)) } }
    Scaffold(topBar = { TopAppBar(title = { Text("Отчёт воды — все квартиры") }, navigationIcon = { TextButton(onClick = onBack) { Text("Назад") } }) }) { padding ->
        LazyColumn(Modifier.padding(padding).padding(12.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            item { Text("Дата и время выгрузки: $now", style = MaterialTheme.typography.bodySmall) }
            rows.forEach { r ->
                item {
                    Text("Квартира ${r.apartment.id}", style = MaterialTheme.typography.titleMedium)
                    Text(r.apartment.address)
                    Text("Переплата: ${r.overpayment}")
                    Text("Задолженность: ${r.debt}")
                    Text("Пеня: ${r.penalty}")
                }
            }
            item { Button(onClick = { docLauncher.launch("Отчёт_вода_все_квартиры.doc") }, modifier = Modifier.fillMaxWidth()) { Text("Сохранить общий DOC") } }
            item { Button(onClick = { excelLauncher.launch("Отчёт_вода_все_квартиры.xls") }, modifier = Modifier.fillMaxWidth()) { Text("Сохранить общий Excel") } }
        }
    }
}


private fun LocalStore.hasConfiguredWaterReport(apartmentId: Int): Boolean {
    // The saved meter list can contain meters created by the settings screen.
    // For an existing default meter, use its real default type as the fallback;
    // for a newly-created/custom meter, the app creates it as WATER unless the
    // user explicitly selected another type. The previous implementation used
    // ELECTRICITY as the fallback for every saved meter, which made a valid
    // water meter invisible on the report screen after settings were restored.
    val base = defaultApartments().firstOrNull { it.id == apartmentId } ?: newApartment(apartmentId)
    val baseById = base.meters.associateBy { it.id }
    val ids = meterIds(apartmentId, base.meters)
    val hasWaterMeter = ids.any { meterId ->
        val fallbackType = baseById[meterId]?.type ?: MeterType.WATER
        meterType(apartmentId, meterId, fallbackType) == MeterType.WATER
    }
    return hasWaterMeter &&
        waterLogin(apartmentId).isNotBlank() &&
        get("water_password_$apartmentId").isNotBlank()
}

private fun LocalStore.hasConfiguredGasReport(apartmentId: Int): Boolean {
    // Gas reports are available only when this apartment has a gas meter AND
    // both SevGaz LK credentials are filled in Settings. An empty login or
    // password means there is no usable gas LK for this apartment, so it must
    // not appear in the gas report list or in "Получить отчёт всех квартир".
    val base = defaultApartments().firstOrNull { it.id == apartmentId } ?: newApartment(apartmentId)
    val baseById = base.meters.associateBy { it.id }
    val ids = meterIds(apartmentId, base.meters)
    val hasGasMeter = ids.any { meterId ->
        val fallbackType = baseById[meterId]?.type ?: MeterType.GAS
        meterType(apartmentId, meterId, fallbackType) == MeterType.GAS
    }
    return hasGasMeter &&
        get("gas_login_$apartmentId").isNotBlank() &&
        get("gas_password_$apartmentId").isNotBlank()
}

private fun LocalStore.apartmentAddress(apartment: Apartment): String =
    get("address_${apartment.id}", apartment.address)

private fun providerUrl(type: MeterType) = when (type) { MeterType.ELECTRICITY -> ENERGY; MeterType.WATER -> WATER; MeterType.GAS -> GAS }

private fun autoFillScript(job: Job): String {
    val reading = JSONObject.quote(job.reading); val serial = JSONObject.quote(job.serial)
    val surname = JSONObject.quote(job.credentials.energySurname); val account = JSONObject.quote(job.credentials.energyAccount)
    val waterLogin = JSONObject.quote(job.credentials.waterLogin); val waterPassword = JSONObject.quote(job.credentials.waterPassword)
    val gasLogin = JSONObject.quote(job.credentials.gasLogin); val gasPassword = JSONObject.quote(job.credentials.gasPassword)
    return """
    (function(){
      const reading=$reading, serial=$serial, surname=$surname, account=$account, wl=$waterLogin, wp=$waterPassword, gl=$gasLogin, gp=$gasPassword;
      function all(){ return [...document.querySelectorAll('input,textarea,[contenteditable="true"]')]; }
      function visible(e){return e && (e.offsetWidth||e.offsetHeight||e.getClientRects().length)}
      function unlock(e){ if(!e)return; e.removeAttribute('disabled'); e.removeAttribute('readonly'); }
      function desc(e){ return ((e.getAttribute('aria-label')||'')+' '+(e.getAttribute('placeholder')||'')+' '+(e.getAttribute('name')||'')+' '+(e.id||'')+' '+((e.labels&&e.labels[0])?e.labels[0].innerText:'')+' '+(e.getAttribute('title')||'')).toLowerCase(); }
      function set(e,v){
        if(!e||v===undefined||v===null||v==='')return false;
        unlock(e); e.focus();
        try{ const proto=e instanceof HTMLTextAreaElement?HTMLTextAreaElement.prototype:HTMLInputElement.prototype; const d=Object.getOwnPropertyDescriptor(proto,'value'); if(d&&d.set)d.set.call(e,v); else e.value=v; }catch(_){e.value=v;}
        try{e.dispatchEvent(new InputEvent('input',{bubbles:true,inputType:'insertText',data:String(v)}));}catch(_){e.dispatchEvent(new Event('input',{bubbles:true}));}
        e.dispatchEvent(new Event('change',{bubbles:true}));
        try{e.dispatchEvent(new KeyboardEvent('keyup',{bubbles:true,key:'1'}));}catch(_){ }
        return true;
      }
      function clickLogin(form){
        const scope=form||document;
        const bs=[...scope.querySelectorAll('button,input[type=submit],input[type=button],a')].filter(visible);
        const b=bs.find(x=>/(войти|вход|login|sign in|авториз|личный кабинет)/i.test((x.innerText||x.value||x.getAttribute('aria-label')||'')+' '+desc(x))) || bs.find(x=>x.type==='submit');
        if(b){unlock(b); b.click(); return true;} return false;
      }
      let found=0, filled=0;
      if(location.host.includes('gup-sevgaz.ru') && !location.host.includes('lk.gup-sevgaz.ru')){
        const links=[...document.querySelectorAll('a,button,[role=button],div[onclick],span[onclick]')].filter(visible);
        const lk=links.find(e=>/(личный кабинет|личный\s+кабинет)/i.test((e.innerText||e.textContent||e.getAttribute('aria-label')||'')+' '+desc(e)))
          || links.find(e=>/личный.?кабинет|lk\.|irb\/login|login/i.test((e.getAttribute('href')||'')+' '+(e.getAttribute('data-href')||'')+' '+(e.getAttribute('onclick')||'')));
        if(lk){ unlock(lk); try{lk.click();}catch(_){} return JSON.stringify({ok:false,phase:'gas_lk'}); }
        return JSON.stringify({ok:false,phase:'login_wait'});
      }
      if(location.host.includes('sevenergosbyt')){
        const f=all().find(e=>visible(e)&&/(фамил|surname)/i.test(desc(e))); if(f){found++; if(set(f,surname))filled++;}
        const a=all().find(e=>visible(e)&&/(лицев|account|абонент)/i.test(desc(e))); if(a){found++; if(set(a,account))filled++;}
        const sn=all().find(e=>visible(e)&&/(номер.*сч|serial|серийн)/i.test(desc(e))); if(sn){found++; if(set(sn,serial))filled++;}
      } else if(location.host.includes('sevvodokanal') || location.host.includes('gup-sevgaz') || location.host.includes('sevgas')) {
        const gas=location.host.includes('gup-sevgaz') || location.host.includes('sevgas'); const login=gas?gl:wl, pass=gas?gp:wp;
        const pw=all().find(e=>visible(e)&&String(e.type).toLowerCase()==='password');
        if(pw && login && pass){
          let form=pw.form || pw.closest('form'); let l=null;
          const loginRe=/(j_username|username|user(name)?|login|account(number)?|personal|lic|ls|лицев|абонент)/i;
          if(form) {
            const inputs=[...form.querySelectorAll('input')].filter(e=>visible(e)&&e!==pw&&!/(search|поиск)/i.test(desc(e)));
            l=inputs.find(e=>/j_username/i.test((e.name||'')+' '+(e.id||'')));
            if(!l) l=inputs.find(e=>loginRe.test(desc(e)) && ['text','number','tel'].includes(String(e.type||'text').toLowerCase()));
            if(!l) l=inputs.find(e=>/username|login|account|personal|j_username/i.test((e.name||'')+' '+(e.id||'')+' '+(e.autocomplete||'')));
            if(!l) l=inputs.find(e=>['text','number','tel'].includes(String(e.type||'text').toLowerCase()));
          }
          if(!l) l=all().find(e=>visible(e)&&e!==pw&&loginRe.test(desc(e))&&['text','number','tel'].includes(String(e.type||'text').toLowerCase()));
          if(!l) l=all().find(e=>visible(e)&&e!==pw&&['text','number','tel'].includes(String(e.type||'text').toLowerCase())&&!/(search|поиск)/i.test(desc(e)));
          if(l) { found++; if(set(l,login)) filled++; }
          found++; if(set(pw,pass)) filled++;
          const loginValue=()=>l ? String(l.value||'').trim() : '';
          const passValue=()=>String(pw.value||'');
          function doLogin(){
            if(l && loginValue()!==String(login).trim()) set(l,login);
            if(passValue()!==String(pass)) set(pw,pass);
            if(!form) return clickLogin(document);
            try{form.dispatchEvent(new Event('input',{bubbles:true})); form.dispatchEvent(new Event('change',{bubbles:true}));}catch(_){}
            const inForm=[...form.querySelectorAll('button,input[type=submit],input[type=button],input[type=image],a,[role=button]')];
            const allSubmit=[...document.querySelectorAll('button,input[type=submit],input[type=button],input[type=image],a,[role=button]')];
            const submit=inForm.find(b=>visible(b) && /(войти|вход|login|sign in|авториз|посмотреть)/i.test((b.innerText||b.value||b.getAttribute('aria-label')||'')+' '+desc(b)))
              || inForm.find(b=>visible(b))
              || allSubmit.find(b=>visible(b) && /(войти|вход|login|sign in|авториз|посмотреть)/i.test((b.innerText||b.value||b.getAttribute('aria-label')||'')+' '+desc(b)));
            if(submit){
              unlock(submit);
              try{submit.focus();}catch(_){}
              try{submit.dispatchEvent(new MouseEvent('mousedown',{bubbles:true,cancelable:true}));}catch(_){}
              try{submit.dispatchEvent(new MouseEvent('mouseup',{bubbles:true,cancelable:true}));}catch(_){}
              try{submit.click();}catch(_){}
              setTimeout(function(){try{if(typeof form.requestSubmit==='function')form.requestSubmit(submit);}catch(_){}},300);
              return true;
            }
            try{if(form.requestSubmit){form.requestSubmit(); return true;}}catch(_){}
            try{HTMLFormElement.prototype.submit.call(form); return true;}catch(_){}
            return clickLogin(form);
          }
          setTimeout(function(){
            doLogin();
            try{if(pw){pw.focus(); pw.dispatchEvent(new KeyboardEvent('keydown',{bubbles:true,key:'Enter',code:'Enter',keyCode:13,which:13})); pw.dispatchEvent(new KeyboardEvent('keyup',{bubbles:true,key:'Enter',code:'Enter',keyCode:13,which:13}));}}catch(_){}
          },700);
          setTimeout(doLogin,2200);
          return JSON.stringify({ok:filled===2,phase:'login',found:found,filledCount:filled,loginUsed:login});
        }
        return JSON.stringify({ok:false,phase:'login',found:found,filledCount:filled,loginUsed:login});
      }
      // IMPORTANT: login pages are handled above. Never search for a meter-reading
      // field while a provider login form is still visible.
      const pageText=(document.body&&document.body.innerText||'').toLowerCase();
      if(location.host.includes('gup-sevgaz') || location.host.includes('sevgas')){
        const clickables=[...document.querySelectorAll('button,input[type=button],input[type=submit],input[type=image],a,[role=button]')].filter(visible);
        const clickText=e=>((e.innerText||e.value||e.getAttribute('aria-label')||e.getAttribute('title')||'')+' '+desc(e)).toLowerCase();
        const hasCounters=/(сч[её]тчики|узлы\s*уч[её]та|приборы\s*уч[её]та)/i.test(pageText);
        const hasReadingForm=/(предоставление показаний|показания сч[её]тчика|передать показания)/i.test(pageText);
        if(!hasCounters){
          const b=clickables.find(e=>/^(сч[её]тчики|узлы\s*уч[её]та)$/i.test((e.innerText||e.value||'').trim()))
            || clickables.find(e=>/сч[её]тчики|узлы\s*уч[её]та/i.test(clickText(e)));
          if(b){unlock(b); b.click(); return JSON.stringify({ok:false,phase:'gas_counters'});}
        }
        if(hasCounters && !hasReadingForm){
          const b=clickables.find(e=>/предоставление показаний|показания сч[её]тчика|передать показания/i.test(clickText(e)));
          if(b){unlock(b); b.click(); return JSON.stringify({ok:false,phase:'gas_readings'});}
        }
      }
      const visiblePassword=[...document.querySelectorAll('input[type=password]')].find(visible);
      const loginButtons=[...document.querySelectorAll('button,input[type=submit],input[type=button],input[type=image],a,[role=button]')].filter(visible)
        .filter(e=>/(войти|вход|login|sign in|авториз|посмотреть)/i.test((e.innerText||e.value||e.getAttribute('aria-label')||e.getAttribute('title')||'')+' '+desc(e)));
      if((location.host.includes('sevvodokanal') || location.host.includes('gup-sevgaz') || location.host.includes('sevgas')) && visiblePassword && loginButtons.length){
        return JSON.stringify({ok:false,phase:'login',found:0,filledCount:0,loginUsed:''});
      }
      // HARD GUARD: on water/gas login screens never search or submit meter readings.
      if(location.host.includes('sevvodokanal') || location.host.includes('gup-sevgaz') || location.host.includes('sevgas')){
        const pwNow=[...document.querySelectorAll('input[type=password]')].find(visible);
        const bodyNow=(document.body&&document.body.innerText||'').toLowerCase();
        const loginFormNow=pwNow || /(лицевый\s*сч[её]т|личный кабинет|войти в систему|введите.*парол|логин|пароль)/i.test(bodyNow);
        if(loginFormNow) return JSON.stringify({ok:false,phase:'login_wait',found:0,filledCount:0,loginUsed:''});
      }
      const meterWords=['показани','показан','потреблен','потребл','текущие показ','текущее показ','объём','объем','reading','meter reading','значение счетчика','значение счётчика'];
      const badWords=['captcha','капч','код с картинки','код картинки','цифр с картинки','изображен','код подтвержден','проверочн','security','защит','с картинки'];
      let candidates=all().filter(e=>visible(e)&&!e.disabled&&e.type!=='hidden'&&e.type!=='password'&&!badWords.some(w=>desc(e).includes(w))&&(e.type==='text'||e.type==='number'||e.tagName==='TEXTAREA'));
      let target=candidates.find(e=>meterWords.some(w=>desc(e).includes(w)));
      if(!target && location.host.includes('sevenergosbyt')) target=candidates.find(e=>!['фамил','лицев','account','счётчик','счетчик','serial','серийн','captcha','капч','картин','код','парол','login'].some(w=>desc(e).includes(w)));
      if(target){found++; if(set(target,reading))filled++; try{target.scrollIntoView({block:'center'});}catch(_){} }
      if(!target && location.host.includes('sevenergosbyt')) {
        const clickable=[...document.querySelectorAll('button,input[type=button],a,[role=button]')].filter(visible);
        const nav=clickable.find(e=>/(показани|передач.*показ|сч[её]тчик|meter)/i.test((e.innerText||e.value||e.getAttribute('aria-label')||e.getAttribute('title')||'')+' '+desc(e)));
        if(nav){ unlock(nav); nav.click(); return JSON.stringify({ok:false,phase:'navigate'}); }
        const menu=clickable.find(e=>/(menu|меню|навигац)/i.test((e.innerText||e.value||e.getAttribute('aria-label')||e.getAttribute('title')||'')+' '+desc(e)));
        if(menu){ unlock(menu); menu.click(); return JSON.stringify({ok:false,phase:'menu'}); }
      }
      return JSON.stringify({ok:filled>0,phase:'meter',found:found,filledCount:filled});
    })()
    """.trimIndent()
}


private fun loginFillOnlyScript(job: Job): String {
    val waterLogin = JSONObject.quote(job.credentials.waterLogin)
    val waterPassword = JSONObject.quote(job.credentials.waterPassword)
    val gasLogin = JSONObject.quote(job.credentials.gasLogin)
    val gasPassword = JSONObject.quote(job.credentials.gasPassword)
    return """
    (function(){
      const wl=$waterLogin, wp=$waterPassword, gl=$gasLogin, gp=$gasPassword;
      const gas=location.host.includes('gup-sevgaz') || location.host.includes('sevgas');
      const login=gas?gl:wl, pass=gas?gp:wp;
      function visible(e){return e && (e.offsetWidth||e.offsetHeight||e.getClientRects().length)}
      function desc(e){ return ((e.getAttribute('aria-label')||'')+' '+(e.getAttribute('placeholder')||'')+' '+(e.getAttribute('name')||'')+' '+(e.id||'')+' '+((e.labels&&e.labels[0])?e.labels[0].innerText:'')+' '+(e.getAttribute('title')||'')).toLowerCase(); }
      function setValue(e,v){
        if(!e||v==null)return false;
        try{e.removeAttribute('disabled'); e.removeAttribute('readonly');}catch(_){}
        const proto=e instanceof HTMLTextAreaElement?HTMLTextAreaElement.prototype:HTMLInputElement.prototype;
        try{const d=Object.getOwnPropertyDescriptor(proto,'value'); if(d&&d.set)d.set.call(e,String(v)); else e.value=String(v);}catch(_){e.value=String(v);}
        try{e.dispatchEvent(new Event('focus',{bubbles:true}));}catch(_){}
        try{e.dispatchEvent(new InputEvent('input',{bubbles:true,inputType:'insertText',data:String(v)}));}catch(_){try{e.dispatchEvent(new Event('input',{bubbles:true}));}catch(_) {}}
        try{e.dispatchEvent(new Event('change',{bubbles:true}));}catch(_){}
        try{e.dispatchEvent(new KeyboardEvent('keydown',{bubbles:true,key:'End',code:'End'}));}catch(_){}
        try{e.dispatchEvent(new KeyboardEvent('keyup',{bubbles:true,key:'End',code:'End'}));}catch(_){}
        return true;
      }
      const inputs=[...document.querySelectorAll('input')].filter(visible);
      const pw=inputs.find(e=>String(e.type).toLowerCase()==='password');
      if(!pw) return JSON.stringify({ok:false,phase:'no_password',url:location.href});
      const form=pw.form || pw.closest('form');
      const candidates=form?[...form.querySelectorAll('input')].filter(e=>visible(e)&&e!==pw):inputs.filter(e=>e!==pw);
      const loginRe=/(j_username|username|user(name)?|login|account(number)?|personal|lic|ls|лицев|абонент)/i;
      let l=candidates.find(e=>/j_username/i.test((e.name||'')+' '+(e.id||'')));
      if(!l) l=candidates.find(e=>loginRe.test(desc(e))&&['text','number','tel'].includes(String(e.type||'text').toLowerCase()));
      if(!l) l=candidates.find(e=>/username|login|account|personal|j_username/i.test((e.name||'')+' '+(e.id||'')+' '+(e.autocomplete||'')));
      if(!l) l=candidates.find(e=>['text','number','tel'].includes(String(e.type||'text').toLowerCase()));
      if(!l) return JSON.stringify({ok:false,phase:'no_login',url:location.href});
      const a=setValue(l,login), b=setValue(pw,pass);
      const buttons=[...document.querySelectorAll('button,input[type=submit],input[type=button],a')].filter(visible);
      const submit=buttons.find(e=>/(войти в систему|войти|вход|login|sign in|авториз)/i.test((e.innerText||e.value||e.getAttribute('aria-label')||e.getAttribute('title')||'')+' '+desc(e)));
      if(submit){ try{submit.removeAttribute('disabled'); submit.removeAttribute('readonly');}catch(_){} }
      if(a&&b&&submit){
        try{submit.focus();}catch(_){}
        try{submit.dispatchEvent(new MouseEvent('mousedown',{bubbles:true,cancelable:true,view:window}));}catch(_){}
        try{submit.dispatchEvent(new MouseEvent('mouseup',{bubbles:true,cancelable:true,view:window}));}catch(_){}
        try{submit.click();}catch(_){}
      }
      return JSON.stringify({ok:a&&b,phase:(a&&b&&submit)?'login_submitted':'login_filled',loginField:l.name||l.id||l.type,passwordField:pw.name||pw.id||'password',submitEnabled:!!submit,url:location.href});
    })()
    """.trimIndent()
}


private fun nativeGasLoginScript(): String = """
(function(){
  const vis=e=>!!(e&&(e.offsetWidth||e.offsetHeight||e.getClientRects().length));
  const pw=[...document.querySelectorAll('input[type=password]')].find(vis);
  const form=pw && (pw.form||pw.closest('form'));
  if(!form) return JSON.stringify({ok:false,reason:'NO_FORM'});
  const submit=[...form.querySelectorAll('button,input[type=submit],input[type=button]')].find(vis);
  const fields=[...form.querySelectorAll('input')].filter(e=>e.name).map(e=>({
    name:e.name, value:e.value||'', type:e.type||'text'
  }));
  return JSON.stringify({
    ok:true,
    action:form.action||location.href,
    method:(form.method||'post').toUpperCase(),
    fields:fields,
    submit:submit?{name:submit.name||'',value:submit.value||''}:null,
    url:location.href
  });
})()
""".trimIndent()

private fun fallbackGasWebLogin(w: WebView) {
    w.evaluateJavascript("""
        (function(){
          const vis=e=>!!(e&&(e.offsetWidth||e.offsetHeight||e.getClientRects().length));
          const pw=[...document.querySelectorAll('input[type=password]')].find(vis);
          const form=pw && (pw.form||pw.closest('form'));
          if(!form)return 'NO_FORM';
          const buttons=[...form.querySelectorAll('button,input[type=submit],input[type=button]')].filter(vis);
          const txt=e=>((e.innerText||e.value||e.textContent||e.getAttribute('aria-label')||e.getAttribute('title')||'')+'');
          const submit=buttons.find(e=>/(войти в систему|войти|вход|login|sign in|авториз)/i.test(txt(e))) || buttons.find(e=>String(e.type||'').toLowerCase()==='submit');
          if(!submit)return 'NO_BUTTON';
          try{submit.removeAttribute('disabled');submit.removeAttribute('readonly');submit.focus();}catch(_){ }
          try{submit.click();return 'CLICK';}catch(_){return 'FAILED';}
        })()
    """.trimIndent()) { }
}

private fun startNativeGasLogin(w: WebView, job: Job, isManualLoginRequested: () -> Boolean) {
    w.evaluateJavascript(nativeGasLoginScript()) { raw ->
        val jsonText = try { JSONObject("{\"data\":$raw}").optString("data", raw ?: "") } catch (_: Exception) { raw ?: "" }
        val data = try { JSONObject(jsonText) } catch (_: Exception) {
            return@evaluateJavascript
        }
        if (isManualLoginRequested()) return@evaluateJavascript
        if (!data.optBoolean("ok", false)) {
            return@evaluateJavascript
        }
        val fields = data.optJSONArray("fields") ?: run {
            return@evaluateJavascript
        }
        val userAgent = w.settings.userAgentString
        val referer = data.optString("url", GAS)
        val initialCookies = android.webkit.CookieManager.getInstance().getCookie(data.optString("action", GAS)).orEmpty()
        Thread {
            var conn: HttpURLConnection? = null
            try {
                val actionRaw = data.optString("action", GAS)
                val action = if (actionRaw.endsWith("/irb/login.xhtml", true)) actionRaw.removeSuffix("/login.xhtml") + "/login" else actionRaw
                val params = LinkedHashMap<String, String>()
                for (i in 0 until fields.length()) {
                    val f = fields.optJSONObject(i) ?: continue
                    val name = f.optString("name")
                    if (name.isNotBlank()) params[name] = f.optString("value")
                }
                params["tab1:username"] = job.credentials.gasLogin
                params["tab1:password"] = job.credentials.gasPassword
                val submit = data.optJSONObject("submit")
                if (submit != null && submit.optString("name").isNotBlank()) {
                    params[submit.optString("name")] = submit.optString("value")
                }
                fun encode(values: Map<String, String>): String = values.entries.joinToString("&") {
                    URLEncoder.encode(it.key, "UTF-8") + "=" + URLEncoder.encode(it.value, "UTF-8")
                }

                val cookieManager = android.webkit.CookieManager.getInstance()
                var cookieHeader = initialCookies
                var currentUrl = action
                var finalUrl = action
                var success = false

                conn = (URL(currentUrl).openConnection() as HttpURLConnection).apply {
                    requestMethod = "POST"
                    doOutput = true
                    instanceFollowRedirects = false
                    connectTimeout = 5000
                    readTimeout = 7000
                    setRequestProperty("User-Agent", userAgent)
                    setRequestProperty("Referer", referer)
                    setRequestProperty("Content-Type", "application/x-www-form-urlencoded")
                    if (cookieHeader.isNotBlank()) setRequestProperty("Cookie", cookieHeader)
                }
                conn!!.outputStream.use { it.write(encode(params).toByteArray(Charsets.UTF_8)) }
                val code = conn!!.responseCode
                val setCookies = conn!!.headerFields?.entries?.filter { it.key.equals("Set-Cookie", true) }?.flatMap { it.value ?: emptyList() } ?: emptyList()
                if (setCookies.isNotEmpty()) {
                    val map = LinkedHashMap<String, String>()
                    cookieHeader.split(";").map { it.trim() }.filter { it.contains("=") }.forEach {
                        map[it.substringBefore("=").trim()] = it.substringAfter("=").trim()
                    }
                    setCookies.forEach { rawCookie ->
                        val first = rawCookie.substringBefore(";").trim()
                        if (first.contains("=")) map[first.substringBefore("=").trim()] = first.substringAfter("=").trim()
                    }
                    cookieHeader = map.entries.joinToString("; ") { "${it.key}=${it.value}" }
                }
                val location = conn!!.getHeaderField("Location")
                conn!!.disconnect()
                conn = null

                if (code in 300..399 && !location.isNullOrBlank()) {
                    currentUrl = URL(URL(action), location).toString()
                    finalUrl = currentUrl
                    conn = (URL(currentUrl).openConnection() as HttpURLConnection).apply {
                        requestMethod = "GET"
                        instanceFollowRedirects = false
                        connectTimeout = 5000
                        readTimeout = 7000
                        setRequestProperty("User-Agent", userAgent)
                        setRequestProperty("Referer", action)
                        if (cookieHeader.isNotBlank()) setRequestProperty("Cookie", cookieHeader)
                    }
                    val getCode = conn!!.responseCode
                    success = getCode in 200..399 && currentUrl.contains("/irb/view/", true)
                    conn!!.disconnect()
                    conn = null
                } else {
                    val stream = try { conn?.inputStream } catch (_: Exception) { conn?.errorStream }
                    val body = stream?.bufferedReader()?.use(BufferedReader::readText).orEmpty()
                    success = code in 200..399 && body.contains("abonentInfo", true)
                    finalUrl = action
                    conn?.disconnect()
                    conn = null
                }

                w.post {
                    if (isManualLoginRequested()) return@post
                    cookieHeader.split(";").map { it.trim() }.filter { it.contains("=") }.forEach {
                        val k = it.substringBefore("=").trim()
                        val v = it.substringAfter("=").trim()
                        if (k.isNotBlank()) cookieManager.setCookie(GAS.substringBefore("/irb/"), "$k=$v; Path=/")
                    }
                    cookieManager.flush()
                    if (success) {
                        w.loadUrl(finalUrl)
                    } else {
                        fallbackGasWebLogin(w)
                    }
                }
            } catch (_: Exception) {
                w.post {
                    if (!isManualLoginRequested()) fallbackGasWebLogin(w)
                }
            } finally { conn?.disconnect() }
        }.start()
    }
}

private fun autoGasLoginScript(job: Job): String {
    // Gas: fill credentials and identify the real login control.  The cabinet may
    // place the visible login button outside the password field's <form>, so search
    // the whole document and use several normal browser submission mechanisms.
    val gasLogin = JSONObject.quote(job.credentials.gasLogin)
    val gasPassword = JSONObject.quote(job.credentials.gasPassword)
    return """
    (function(){
      const login=$gasLogin, pass=$gasPassword;
      const visible=e=>!!(e&&(e.offsetWidth||e.offsetHeight||e.getClientRects().length));
      const desc=e=>(((e.getAttribute('aria-label')||'')+' '+(e.getAttribute('placeholder')||'')+' '+(e.getAttribute('name')||'')+' '+(e.id||'')+' '+(e.getAttribute('title')||'')+' '+((e.labels&&e.labels[0])?e.labels[0].innerText:''))+'').toLowerCase();
      const text=e=>((e.innerText||e.value||e.textContent||e.getAttribute('aria-label')||e.getAttribute('title')||'')+' '+desc(e));
      function setValue(e,v){
        if(!e)return false;
        try{e.removeAttribute('disabled');e.removeAttribute('readonly');}catch(_){ }
        try{
          const proto=e instanceof HTMLTextAreaElement?HTMLTextAreaElement.prototype:HTMLInputElement.prototype;
          const d=Object.getOwnPropertyDescriptor(proto,'value');
          if(d&&d.set)d.set.call(e,String(v)); else e.value=String(v);
        }catch(_){try{e.value=String(v);}catch(__){}}
        try{e.dispatchEvent(new Event('input',{bubbles:true}));}catch(_){ }
        try{e.dispatchEvent(new Event('change',{bubbles:true}));}catch(_){ }
        try{e.dispatchEvent(new Event('blur',{bubbles:true}));}catch(_){ }
        return String(e.value||'')===String(v);
      }
      const pw=[...document.querySelectorAll('input[type=password]')].find(visible);
      if(!pw) return JSON.stringify({ok:false,phase:'login_wait'});
      const form=pw.form||pw.closest('form');
      const pool=form?[...form.querySelectorAll('input')].filter(visible):[...document.querySelectorAll('input')].filter(visible);
      const re=/(j_username|username|user(name)?|login|account(number)?|personal|lic|ls|лицев|абонент)/i;
      let lf=pool.find(e=>e!==pw&&/j_username/i.test((e.name||'')+' '+(e.id||'')));
      if(!lf)lf=pool.find(e=>e!==pw&&re.test(desc(e))&&['text','number','tel'].includes(String(e.type||'text').toLowerCase()));
      if(!lf)lf=pool.find(e=>e!==pw&&['text','number','tel'].includes(String(e.type||'text').toLowerCase()));
      if(!lf) return JSON.stringify({ok:false,phase:'login_wait'});
      const loginOk=setValue(lf,login), passOk=setValue(pw,pass);

      // Do not require the submit control to belong to pw.form: some versions
      // of the cabinet render the visible button outside that form.
      const allButtons=[...document.querySelectorAll('button,input[type=submit],input[type=button],a,[role=button]')].filter(visible);
      const buttonWords=/(войти в систему|войти|вход|login|sign in|авториз)/i;
      let submit=allButtons.find(e=>buttonWords.test(text(e)));
      if(!submit) submit=allButtons.find(e=>e.form===form && String(e.type||'').toLowerCase()==='submit');
      if(!submit) return JSON.stringify({ok:loginOk&&passOk,phase:'login_filled'});
      try{submit.removeAttribute('disabled');submit.removeAttribute('readonly');submit.scrollIntoView({block:'center',inline:'center'});}catch(_){ }
      const r=submit.getBoundingClientRect();
      return JSON.stringify({ok:loginOk&&passOk,phase:'login_ready',x:r.left+r.width/2,y:r.top+r.height/2,w:r.width,h:r.height,tag:submit.tagName,type:submit.type||'',id:submit.id||'',name:submit.name||''});
    })()
    """.trimIndent()
}

private fun openGasReadingFormScript(): String {
    return """
    (function(){
      const norm=s=>(s||'').replace(/\\s+/g,' ').trim().toLowerCase();
      const text=e=>norm((e.innerText||e.value||e.textContent||e.getAttribute('aria-label')||e.getAttribute('title')||'')+'');
      const vis=e=>!!(e&&(e.offsetWidth||e.offsetHeight||e.getClientRects().length));
      const body=norm(document.body&&document.body.innerText||'');
      // The counters page itself contains the button text “Предоставление показаний счётчика”.
      // That text alone is NOT proof that the input dialog is open. Require a real visible
      // reading input/dialog marker instead.
      const visibleInputs=[...document.querySelectorAll('input,textarea')].filter(vis);
      const readingInput=visibleInputs.find(e=>/показани|значени|сч[её]тчик/i.test(text(e)) || /показани|значени|сч[её]тчик/i.test((e.name||'')+' '+(e.id||'')+' '+(e.placeholder||'')));
      const dialogText=[...document.querySelectorAll('[role="dialog"], .ui-dialog, .modal, .modal-dialog')].filter(vis).some(e=>/предоставление показаний|введите показания|показания сч[её]тчика/i.test(text(e)));
      const formOpen=!!readingInput || dialogText || /введите показания/i.test(body);
      if(formOpen) return JSON.stringify({ok:true,phase:'gas_reading_form'});

      function activate(el){
        if(!el) return false;
        let x=el;
        for(let i=0;i<7 && x;i++,x=x.parentElement){
          try{x.removeAttribute('disabled');x.removeAttribute('readonly');}catch(_){}
          try{x.scrollIntoView({block:'center',inline:'center'});}catch(_){}
          try{x.focus();}catch(_){}
          try{x.dispatchEvent(new MouseEvent('mousedown',{bubbles:true,cancelable:true,view:window}));}catch(_){}
          try{x.dispatchEvent(new MouseEvent('mouseup',{bubbles:true,cancelable:true,view:window}));}catch(_){}
          try{x.dispatchEvent(new MouseEvent('click',{bubbles:true,cancelable:true,view:window}));}catch(_){}
          try{if(typeof x.click==='function') x.click();}catch(_){}
          try{if(typeof x.onclick==='function') x.onclick.call(x); }catch(_){}
          if(x.matches && x.matches('a,button,input[type=button],input[type=submit],[role=button]')) return true;
        }
        return false;
      }

      const all=[...document.querySelectorAll('*')].filter(vis);
      const readingRe=/предоставление показаний|показания сч[её]тчика|передать показания/i;
      const counterRe=/^сч[её]тчики$|^сч[её]тчики\s*$/i;

      // First look for the actual control, not just its parent text.
      let reading=all.find(e=>readingRe.test(text(e)) && text(e).length<120 &&
        (e.matches('a,button,input[type=button],input[type=submit],[role=button]') || e.onclick || e.closest('a,button,input[type=button],input[type=submit],[role=button]')));
      if(reading){
        const target=reading.closest('a,button,input[type=button],input[type=submit],[role=button]') || reading;
        if(activate(target)) return JSON.stringify({ok:true,phase:'gas_readings'});
      }

      // Some JSF pages put the command text inside a table cell or span.
      let readingText=all.find(e=>readingRe.test(text(e)) && text(e).length<120);
      if(readingText && activate(readingText)) return JSON.stringify({ok:true,phase:'gas_readings'});

      // If still on the cabinet info page, open Counters. Prefer the actual tab/control.
      let counters=all.find(e=>counterRe.test(text(e)) &&
        (e.matches('a,button,input[type=button],input[type=submit],[role=button],td,li') || e.onclick || e.closest('a,button,input[type=button],input[type=submit],[role=button]')));
      if(!counters) counters=all.find(e=>/сч[её]тчики/.test(text(e)) && text(e).length<50);
      if(counters){
        const target=counters.closest('a,button,input[type=button],input[type=submit],[role=button]') || counters;
        if(activate(target)) return JSON.stringify({ok:true,phase:'gas_counters'});
      }

      return JSON.stringify({ok:false,phase:'gas_wait',bodyHasCounters:/сч[её]тчики/.test(body),bodyHasReading:readingRe.test(body)});
    })()
    """.trimIndent()
}


private fun fillGasReadingScript(reading: String): String {
    val value = JSONObject.quote(reading)
    return """
    (function(){
      const wanted=$value;
      const vis=e=>!!(e&&(e.offsetWidth||e.offsetHeight||e.getClientRects().length));
      const desc=e=>(((e.getAttribute('aria-label')||'')+' '+(e.getAttribute('placeholder')||'')+' '+(e.getAttribute('name')||'')+' '+(e.id||'')+' '+(e.getAttribute('title')||'')+' '+((e.labels&&e.labels[0])?e.labels[0].innerText:''))+'').toLowerCase();
      const set=(e,v)=>{
        if(!e) return false;
        try{e.removeAttribute('disabled');e.removeAttribute('readonly');e.focus();}catch(_){}
        try{
          const proto=e instanceof HTMLTextAreaElement?HTMLTextAreaElement.prototype:HTMLInputElement.prototype;
          const d=Object.getOwnPropertyDescriptor(proto,'value');
          if(d&&d.set)d.set.call(e,v); else e.value=v;
        }catch(_){try{e.value=v;}catch(__){return false;}}
        try{e.dispatchEvent(new InputEvent('input',{bubbles:true,inputType:'insertText',data:String(v)}));}catch(_){try{e.dispatchEvent(new Event('input',{bubbles:true}));}catch(__){}}
        try{e.dispatchEvent(new Event('change',{bubbles:true}));}catch(_){}
        try{e.dispatchEvent(new KeyboardEvent('keyup',{bubbles:true,key:'End'}));}catch(_){}
        return String(e.value||'')===String(v);
      };
      const dialogs=[...document.querySelectorAll('[role="dialog"], .ui-dialog, .modal, .modal-dialog')].filter(vis);
      const scopes=dialogs.length?dialogs:[document];
      let target=null;
      for(const scope of scopes){
        const inputs=[...scope.querySelectorAll('input,textarea')].filter(vis).filter(e=>e.type!=='hidden'&&e.type!=='password'&&e.type!=='button'&&e.type!=='submit');
        target=inputs.find(e=>/показани|значени|введите.*показ|сч[её]тчик/i.test(desc(e)));
        if(!target) target=inputs.find(e=>['text','number','tel'].includes(String(e.type||'text').toLowerCase()) && !/год|year|поиск|search/i.test(desc(e)));
        if(target) break;
      }
      if(!target) return JSON.stringify({ok:false,phase:'gas_reading_input_not_found'});
      const ok=set(target,wanted);
      try{target.scrollIntoView({block:'center',inline:'center'});}catch(_){}
      return JSON.stringify({ok:ok,phase:'gas_reading_filled',value:String(target.value||'')});
    })()
    """.trimIndent()
}

private fun autoSubmitScript(type: MeterType): String {
    return """
    (function(){
      const text=e=>((e.innerText||e.value||e.getAttribute('aria-label')||e.getAttribute('title')||'')+'').toLowerCase();
      const vis=e=>e&&(e.offsetWidth||e.offsetHeight||e.getClientRects().length);
      const bad=/(captcha|капч|код с картинки|код картинки|цифр с картинки|изображен|код подтвержден|проверочн|security|защит)/i;
      const buttons=[...document.querySelectorAll('button,input[type=submit],input[type=button],input[type=image],a,[role=button]')].filter(vis);
      const body=(document.body&&document.body.innerText||'').toLowerCase();
      if(typeName==='GAS'){}
      function clickBy(re){
        const b=buttons.find(e=>re.test(text(e)));
        if(b){try{b.removeAttribute('disabled');b.removeAttribute('readonly');b.focus();}catch(_){} try{b.click();return true;}catch(_){} }
        return false;
      }
      const typeName='%TYPE%';
      if(typeName==='GAS'){
        // After login the gas cabinet requires entering the Counters section first.
        if(!/(предоставление показаний|показания счетчика|показания сч[её]тчика|сч[её]тчики)/i.test(body)){
          if(clickBy(/^(сч[её]тчики|показания)$/i)) return JSON.stringify({ok:true,phase:'gas_counters'});
          if(clickBy(/сч[её]тчики|показани/i)) return JSON.stringify({ok:true,phase:'gas_counters'});
        }
        if(!/(предоставление показаний|показания счетчика|показания сч[её]тчика)/i.test(body)){
          if(clickBy(/предоставление показаний|показания счетчика|показания сч[её]тчика/i)) return JSON.stringify({ok:true,phase:'gas_readings'});
        }
      }
      const captcha=!![...document.querySelectorAll('input,textarea')].find(e=>vis(e)&&bad.test(((e.placeholder||'')+' '+(e.name||'')+' '+(e.id||'')+' '+(e.getAttribute('aria-label')||'')+' '+((e.parentElement&&e.parentElement.innerText)||''))));
      const re=/(передать|отправить|отправка|записать(?:\s+показания)?|записать|сохранить|подтвердить|подтверждаю|submit|send|save|confirm)/i;
      const candidates=buttons.filter(b=>re.test(text(b))&&!/(войти|вход|login|sign in|авториз|посмотреть)/i.test(text(b)));
      const btn=(typeName==='WATER' ? candidates.find(b=>/записать(?:\s+показания)?|передать|отправить/i.test(text(b))) : null)||candidates.find(b=>/передать|отправить|записать|submit|send/i.test(text(b)))||candidates[0];
      if(btn){ try{btn.removeAttribute('disabled');btn.removeAttribute('readonly');}catch(_){}; try{btn.click();}catch(_){} return JSON.stringify({ok:true,clicked:text(btn)}); }
      return JSON.stringify({ok:false,manual:false,captcha:captcha});
    })()
    """.trimIndent().replace("%TYPE%", type.name)
}

@SuppressLint("SetJavaScriptEnabled")

private fun waterReportExtractScript(): String = """
(function(){
  const clean=s=>String(s||'').replace(/\u00a0/g,' ').replace(/[\t ]+/g,' ').replace(/\r/g,'').trim();
  const body=clean((document.body&&document.body.innerText)||'');
  const head=clean(body.slice(0,4000));
  const money=/(-?\d+(?:[.,]\d+)?)\s*(?:руб\.?|р\.?)(?![\d])/i;
  function first(re){ const m=head.match(re); return m ? (m[1]||'').replace(',','.').trim() : ''; }
  // The water cabinet displays the financial statement at the very top,
  // e.g. "У Вас переплата 0.01 руб.". Read that statement directly.
  const over=first(/(?:у\s+вас\s+)?переплат[а-яё]*[^\n]{0,120}?(-?\d+(?:[.,]\d+)?)\s*(?:руб\.?|р\.?)/i);
  const debt=first(/(?:у\s+вас\s+)?(?:задолженн[а-яё]*|долг)[^\n]{0,120}?(-?\d+(?:[.,]\d+)?)\s*(?:руб\.?|р\.?)/i);
  const penalty=first(/(?:у\s+вас\s+)?(?:пен[яеи]|неустойк[а-яё]*)[^\n]{0,120}?(-?\d+(?:[.,]\d+)?)\s*(?:руб\.?|р\.?)/i);
  const hasFinance=/(переплат|задолженн|\bдолг\b|пен[яеи]|неустойк)/i.test(head);
  return JSON.stringify({found:hasFinance,overpayment:over||'отсутствует',debt:debt||'отсутствует',penalty:penalty||'отсутствует',url:location.href,source:head.slice(0,800)});
})()
""".trimIndent()

private fun gasReportExtractScript(): String = """
(function(){
  const clean=s=>String(s||'').replace(/\u00a0/g,' ').replace(/[\t\r\n]+/g,' ').replace(/ +/g,' ').trim();
  const norm=s=>clean(s).toLowerCase().replace(/ё/g,'е');
  const amount=s=>clean(s);
  const keyGas=norm('Газоснабжение (Переплата на начало месяца)');
  const keyTech=norm('Техобслуживание (Переплата на начало месяца)');

  // Севгаз: нужные значения находятся строго во вкладке «Инфо», в таблице #infoTable.
  // Не ищем показания счётчика, квитанцию или другие финансовые блоки.
  const table=document.querySelector('#infoTable');
  let supply='', maintenance='';
  let period='';
  if(table){
    const header=table.querySelector('.ui-datatable-header');
    if(header) period=clean(header.innerText||header.textContent||'');
    for(const row of table.querySelectorAll('tbody tr')){
      const cells=[...row.querySelectorAll('td')];
      if(cells.length<2) continue;
      const key=norm(cells[0].innerText||cells[0].textContent||'');
      let value=amount(cells[1].innerText||cells[1].textContent||'');
      if(!value){ const el=cells[1].querySelector('input, .ui-outputpanel, span, label'); if(el) value=amount(el.value||el.innerText||el.textContent||''); }
      // В разных квартирах ЛК иногда отдаёт подпись с лишними пробелами/служебными
      // символами или чуть меняет разметку строки. Сначала используем точное
      // совпадение, затем безопасный fallback только внутри #infoTable.
      if(key===keyGas || (key.includes('газоснабжение') && key.includes('переплат') && key.includes('начало месяца'))) supply=value;
      if(key===keyTech || (key.includes('техобслуживание') && key.includes('переплат') && key.includes('начало месяца'))) maintenance=value;
    }
  }

  const infoTab=[...document.querySelectorAll('#abonentTabView li[data-index="0"] a')][0] || null;
  const infoLi=infoTab ? infoTab.closest('li') : null;
  const infoSelected=!!(infoLi && (infoLi.classList.contains('ui-tabs-selected') || infoLi.classList.contains('ui-state-active') || infoLi.getAttribute('aria-selected')==='true'));
  const infoPanel=document.querySelector('#j_idt18');
  const infoPanelVisible=!!(infoPanel && infoPanel.getAttribute('aria-hidden')!=='true');
  const loginVisible=[...document.querySelectorAll('input[type=password]')].some(e=>!!(e.offsetWidth||e.offsetHeight||e.getClientRects().length));

  return JSON.stringify({
    found:!!(supply||maintenance),
    complete:!!(supply&&maintenance),
    gasSupply:supply||'не найдено',
    maintenance:maintenance||'не найдено',
    period:period,
    infoTabPresent:!!infoTab,
    infoSelected:infoSelected,
    infoPanelVisible:infoPanelVisible,
    loginVisible:loginVisible,
    url:location.href
  });
})()
""".trimIndent()
private fun waterReportOpenCalculationsScript(): String = """(function(){return JSON.stringify({ok:false,disabled:true});})()"""

private fun fillWaterReadingOnlyScript(job: Job): String {
    val reading = JSONObject.quote(job.reading)
    val serial = JSONObject.quote(job.serial.trim())
    val rowNo = when (job.meterId) { 3 -> "2"; 2 -> "1"; else -> if (job.title.contains("№2")) "2" else "1" }
    return """
    (function(){
      const reading=$reading, serial=$serial, rowNo="$rowNo";
      const visible=e=>!!(e&&(e.offsetWidth||e.offsetHeight||e.getClientRects().length));
      const clean=s=>String(s||'').replace(/\\s+/g,' ').trim();
      const norm=s=>String(s||'').replace(/\\D/g,'');
      const roots=[document,...[...document.querySelectorAll('iframe')].map(f=>{try{return f.contentDocument}catch(_){return null}}).filter(Boolean)];
      function rowText(r){return clean((r.innerText||r.textContent||''));}
      function cells(r){return [...r.children];}
      function setValue(e,v){
        try{e.removeAttribute('disabled');e.removeAttribute('readonly');e.focus();}catch(_){ }
        try{
          const proto=e instanceof HTMLTextAreaElement?HTMLTextAreaElement.prototype:HTMLInputElement.prototype;
          const d=Object.getOwnPropertyDescriptor(proto,'value');
          if(d&&d.set)d.set.call(e,String(v)); else e.value=String(v);
        }catch(_){try{e.value=String(v);}catch(__){}}
        try{e.dispatchEvent(new Event('input',{bubbles:true}));}catch(_){ }
        try{e.dispatchEvent(new Event('change',{bubbles:true}));}catch(_){ }
        try{e.dispatchEvent(new KeyboardEvent('keyup',{bubbles:true,key:'End'}));}catch(_){ }
        return String(e.value||'')===String(v);
      }
      function goodInput(x){
        if(!x||!visible(x))return false;
        const typ=String(x.type||'text').toLowerCase();
        if(!/text|number|tel/.test(typ))return false;
        if(x.hasAttribute('readonly')||x.hasAttribute('disabled'))return false;
        const d=(String(x.name||'')+' '+String(x.id||'')+' '+String(x.placeholder||'')).toLowerCase();
        return !/парол|login|логин|serial|серийн|предыдущ|previous|расход|тариф/.test(d);
      }
      function checkbox(row){
        const b=[...row.querySelectorAll('input[type=checkbox],[role=checkbox]')].find(x=>visible(x));
        if(!b)return false;
        try{if(b.tagName==='INPUT'){if(!b.checked)b.click();return !!b.checked;} if(b.getAttribute('aria-checked')!=='true')b.click();return true;}catch(_){return false;}
      }
      function findRow(root){
        const rs=[...root.querySelectorAll('tr,[role="row"]')];
        const ns=norm(serial);
        if(ns){
          for(const r of rs){
            const n=norm(rowText(r));
            if(n===ns || n.includes(ns)) return {row:r,matched:'serial'};
          }
          for(const el of [...root.querySelectorAll('*')]){
            const n=norm((el.innerText||el.textContent||'')+' '+(el.getAttribute?.('value')||'')+' '+(el.id||'')+' '+(el.getAttribute?.('name')||''));
            if(n===ns || n.includes(ns)){
              const r=el.closest?.('tr,[role="row"]');
              if(r)return {row:r,matched:'serial_element'};
            }
          }
        }
        const byNo=rs.find(r=>{
          const cs=cells(r); const first=clean(cs[0]?.innerText||cs[0]?.textContent||'');
          return first===rowNo || first.replace(/\\D/g,'')===rowNo;
        });
        if(byNo)return {row:byNo,matched:'row_number'};
        const dataRows=rs.filter(r=>cells(r).length>1 && !r.querySelector('th'));
        const idx=Number(rowNo)-1;
        if(dataRows[idx])return {row:dataRows[idx],matched:'row_index'};
        return null;
      }
      for(const root of roots){
        const rr=findRow(root);
        if(!rr)continue;
        const row=rr.row;
        let target=[...row.querySelectorAll('input,textarea,[contenteditable="true"]')].find(goodInput);
        if(!target){
          const inputs=[...row.querySelectorAll('input,textarea')].filter(x=>visible(x)&&!/checkbox|radio|button|submit|hidden/i.test(String(x.type||'')));
          target=inputs[0];
        }
        if(!target)continue;
        const ok=setValue(target,reading);
        const checked=checkbox(row);
        try{target.scrollIntoView({block:'center',inline:'center'});}catch(_){ }
        return JSON.stringify({ok:ok,phase:'water_reading_filled',row:rowNo,serial:serial,matchedBy:rr.matched,checked:checked,value:String(target.value||''),inputName:String(target.name||''),inputId:String(target.id||'')});
      }
      return JSON.stringify({ok:false,phase:'reading_field_not_found',row:rowNo,serial:serial});
    })()
    """.trimIndent()
}
@Composable
private fun ProviderScreen(url: String, job: Job, index: Int, total: Int, store: LocalStore, reportMode: Boolean = false, gasReportMode: Boolean = false, gasReportAllFetch: Boolean = false, electricityReportMode: Boolean = false, onReportData: ((String, String, String) -> Unit)? = null, onGasReportData: ((String, String, String, String) -> Unit)? = null, onElectricityReportData: ((String, String, String, String) -> Unit)? = null, onWebViewReady: (WebView) -> Unit, onStatus: (String) -> Unit, onNext: () -> Unit, onBack: () -> Unit) {
    var message by remember(url, job.meterId) { mutableStateOf("${job.address}\n${job.title}: ${job.reading}\nПередача $index из $total") }
    var reportProgress by remember(url, job.meterId) { mutableStateOf(0) }
    var webViewRef by remember { mutableStateOf<WebView?>(null) }
    var busy by remember { mutableStateOf(false) }
    var gasInitialPrepared by remember(url, job.meterId) { mutableStateOf(false) }
    var gasLoginFormPolls by remember(url, job.meterId) { mutableStateOf(0) }
    var confirmed by remember { mutableStateOf(false) }
    var reportStarted by remember(url, job.meterId) { mutableStateOf(false) }
    var reportCalcClicked by remember(url, job.meterId) { mutableStateOf(false) }
    val context = LocalContext.current
    var pendingHtml by remember { mutableStateOf<String?>(null) }
    val htmlLauncher = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("text/html")) { uri ->
        if (uri != null) {
            try {
                context.contentResolver.openOutputStream(uri)?.use { out ->
                    out.write((pendingHtml ?: "").toByteArray(Charsets.UTF_8))
                }
                message = "HTML страницы сохранён. Прикрепите файл сюда."
                onStatus("HTML сохранён")
            } catch (e: Exception) {
                message = "Не удалось сохранить HTML: ${e.message ?: "ошибка"}"
                onStatus("Ошибка сохранения")
            }
        }
        pendingHtml = null
    }

    fun saveCurrentPageHtml(w: WebView) {
        w.evaluateJavascript("""
            (function(){
              const c=document.documentElement.cloneNode(true);
              c.querySelectorAll('input[type=password]').forEach(e=>{
                try { e.value=''; e.removeAttribute('value'); } catch(_){}
              });
              c.querySelectorAll('input').forEach(e=>{
                const n=((e.name||'')+' '+(e.id||'')).toLowerCase();
                if (n.includes('password') || n.includes('passwd') || n.includes('pwd')) {
                  try { e.value=''; e.removeAttribute('value'); } catch(_){}
                }
              });
              return c.outerHTML;
            })()
        """) { raw ->
            val html = try { JSONObject("{\"data\":$raw}").optString("data", "") } catch (_: Exception) { "" }
            if (html.isBlank()) {
                message = "Не удалось получить HTML текущей страницы."
                onStatus("HTML не получен")
                return@evaluateJavascript
            }
            pendingHtml = html
            htmlLauncher.launch(when (job.type) {
                MeterType.ELECTRICITY -> "sev-energy-login-page.html"
                MeterType.WATER -> "sev-vodokanal-login-page.html"
                MeterType.GAS -> "sev-gaz-login-page.html"
            })
        }
    }

    fun checkConfirmation(w: WebView, attempt: Int = 0) {
        if (confirmed) return
        w.evaluateJavascript("""
            (function(){
              const t=(document.body&&document.body.innerText||'').toLowerCase();
              const ok=/(данн(ые|ых).*(принят|передан|сохран)|показани.*(принят|передан|сохран)|успешн.*(перед|сохран)|спасибо|операция выполнен|передача выполнен|данные отправлен|успешно)/i.test(t);
              const fail=/(ошибк|не удалось|не принят|не передан|неверн|введите капч|captcha)/i.test(t);
              return JSON.stringify({ok:ok,fail:fail});
            })()
        """.trimIndent()) { raw ->
            val r = raw ?: ""
            if (r.contains("\\\"ok\\\":true")) {
                confirmed = true
                busy = false
                message = "✓ ${job.title}: ${job.reading} — показание подтверждено"
                onStatus("Передано ✓")
                w.postDelayed({ onNext() }, 1200)
            } else if (attempt < 10 && !r.contains("\\\"fail\\\":true")) {
                w.postDelayed({ checkConfirmation(w, attempt + 1) }, 900)
            } else {
                busy = false
                message = "Команда отправлена. Подтверждение сайта не найдено — проверь страницу."
                onStatus("Проверить результат")
            }
        }
    }

    fun nativeGasTap(w: WebView, cssX: Float, cssY: Float) {
        // getBoundingClientRect() is in CSS viewport pixels. WebView dispatchTouchEvent()
        // expects view-local physical pixels, so convert using the current WebView scale.
        val scale = try { w.scale } catch (_: Exception) { 1f }
        val scrollX = try { w.scrollX } catch (_: Exception) { 0 }
        val scrollY = try { w.scrollY } catch (_: Exception) { 0 }
        // getBoundingClientRect() returns viewport CSS coordinates. For a WebView
        // touch event they must be converted to local physical pixels; do NOT add
        // WebView scroll offsets because the rect is already relative to the
        // currently visible viewport.
        val x = (cssX * scale).coerceIn(1f, (w.width - 1).coerceAtLeast(1).toFloat())
        val y = (cssY * scale).coerceIn(1f, (w.height - 1).coerceAtLeast(1).toFloat())
        val downTime = SystemClock.uptimeMillis()
        val down = MotionEvent.obtain(downTime, downTime, MotionEvent.ACTION_DOWN, x, y, 0)
        val move = MotionEvent.obtain(downTime, downTime + 30, MotionEvent.ACTION_MOVE, x, y, 0)
        val up = MotionEvent.obtain(downTime, downTime + 80, MotionEvent.ACTION_UP, x, y, 0)
        down.source = android.view.InputDevice.SOURCE_TOUCHSCREEN
        move.source = android.view.InputDevice.SOURCE_TOUCHSCREEN
        up.source = android.view.InputDevice.SOURCE_TOUCHSCREEN
        try {
            w.dispatchTouchEvent(down)
            w.postDelayed({
                w.dispatchTouchEvent(move)
                move.recycle()
                w.dispatchTouchEvent(up)
                up.recycle()
            }, 30)
        } finally {
            down.recycle()
        }
    }

    fun startGasAutoLogin(w: WebView, attempt: Int = 0) {
        if (confirmed || attempt >= 250) {
            if (!confirmed) {
                busy = false
                message = "Газ: диагностика формы не завершена. Проверьте страницу."
                onStatus("Диагностика не завершена")
            }
            return
        }
        w.evaluateJavascript(autoGasLoginScript(job)) { raw ->
            if (confirmed) return@evaluateJavascript
            val r = raw ?: ""
            if (r.contains("login_ready") || r.contains("login_filled")) {
                busy = false
                onStatus("Форма входа найдена")

                // Севгаз использует JSF/PrimeFaces. Важно отправить форму ровно один раз
                // штатным механизмом HTML, без параллельных click/Enter/native-tap:
                // повторная отправка может приводить к возврату той же формы входа.
                if (r.contains("login_ready")) {
                    message = "Газ: автоматически входим в ЛК…"
                    onStatus("Вход в ЛК…")
                    w.evaluateJavascript("""
                        (function(){
                          const vis=e=>!!(e&&(e.offsetWidth||e.offsetHeight||e.getClientRects().length));
                          const pw=[...document.querySelectorAll('input[type=password]')].find(vis);
                          const form=pw && (pw.form||pw.closest('form'));
                          if(!form) return 'NO_FORM';
                          const buttons=[...form.querySelectorAll('button,input[type=submit],input[type=button]')].filter(vis);
                          const text=e=>((e.innerText||e.value||e.textContent||e.getAttribute('aria-label')||e.getAttribute('title')||'')+'');
                          const submit=buttons.find(e=>/(войти в систему|войти|вход|login|sign in|авториз)/i.test(text(e)))
                            || buttons.find(e=>String(e.type||'').toLowerCase()==='submit');
                          if(!submit) return 'NO_BUTTON';
                          try { submit.removeAttribute('disabled'); submit.removeAttribute('readonly'); } catch(_) {}
                          try { submit.focus(); } catch(_) {}
                          try {
                            if(typeof form.requestSubmit==='function') {
                              form.requestSubmit(submit);
                              return 'REQUEST_SUBMIT';
                            }
                          } catch(_) {}
                          return 'REQUEST_SUBMIT_FAILED';
                        })()
                    """) { result ->
                        if (result?.contains("REQUEST_SUBMIT_FAILED") == true || result?.contains("NO_FORM") == true || result?.contains("NO_BUTTON") == true) {
                            busy = false
                            message = "Кв. ${job.apartmentId}: не удалось штатно отправить форму входа Севгаза."
                            onStatus("Форма не отправлена")
                        }
                    }
                }

                w.evaluateJavascript("""
                    (function(){
                      const vis=e=>!!(e&&(e.offsetWidth||e.offsetHeight||e.getClientRects().length));
                      const pw=[...document.querySelectorAll('input[type=password]')].find(vis);
                      const form=pw && (pw.form||pw.closest('form'));
                      if(!form) return JSON.stringify({ok:false,reason:'NO_FORM',url:location.href});
                      const txt=e=>((e.innerText||e.value||e.textContent||e.getAttribute('aria-label')||e.getAttribute('title')||'')+'').trim();
                      const submit=[...form.querySelectorAll('button,input[type=submit],input[type=button],a,[role=button]')].filter(vis)
                        .find(e=>/(войти в систему|войти|вход|login|sign in|авториз)/i.test(txt(e)))
                        || [...form.querySelectorAll('button,input[type=submit],input[type=button]')].find(vis);
                      const hidden=[...form.querySelectorAll('input[type=hidden]')].map(e=>({name:e.name||'',id:e.id||'',hasValue:!!e.value}));
                      const controls=[...form.querySelectorAll('input,button,select,textarea')].filter(vis).map(e=>({tag:e.tagName.toLowerCase(),type:e.type||'',name:e.name||'',id:e.id||'',valueLength:(e.value||'').length}));
                      return JSON.stringify({ok:true,url:location.href,action:form.action||'',method:(form.method||'get').toUpperCase(),formId:form.id||'',formName:form.name||'',submit:submit?{tag:submit.tagName.toLowerCase(),type:submit.type||'',name:submit.name||'',id:submit.id||'',value:submit.value||'',text:txt(submit)}:null,hidden:hidden,controls:controls});
                    })()
                """) { diagRaw ->
                    // Для всех квартир используем тот же штатный JSF submit, который
                    // уже был проверен на квартире 1. Повторного ручного нажатия не требуется.
                    message = "Газ: вход в ЛК газа выполняется автоматически…"
                    onStatus("Вход в ЛК…")
                }
                return@evaluateJavascript
            }
            w.postDelayed({ startGasAutoLogin(w, attempt + 1) }, 40)
        }
    }

    fun openGasInfoTab(w: WebView) {
        w.evaluateJavascript("""
            (function(){
              const tab=document.querySelector('#abonentTabView li[data-index="0"] a');
              if(!tab) return JSON.stringify({ok:false,reason:'NO_INFO_TAB',url:location.href});
              const li=tab.closest('li');
              const panel=document.querySelector('#j_idt18');
              const selected=!!(li && (li.classList.contains('ui-tabs-selected') || li.classList.contains('ui-state-active') || li.getAttribute('aria-selected')==='true'));
              const visible=!!(panel && panel.getAttribute('aria-hidden')!=='true');
              if(selected && visible) return JSON.stringify({ok:true,already:true});
              try{ tab.scrollIntoView({block:'center',inline:'center'}); }catch(_){ }
              try{ tab.focus(); }catch(_){ }
              try{ tab.click(); }catch(_){ }
              return JSON.stringify({ok:true,already:false});
            })()
        """.trimIndent()) { raw ->
            try {
                val decoded = JSONObject("{\"data\":$raw}").optString("data", raw ?: "")
                val o = JSONObject(decoded)
                if (o.optBoolean("ok")) onStatus(if (o.optBoolean("already")) "Вкладка «Инфо» уже открыта" else "Открываем «Инфо»")
                else onStatus("Вкладка «Инфо» не найдена")
            } catch (_: Exception) {
                onStatus("Поиск вкладки «Инфо»")
            }
        }
    }

    fun runGasReportRead(w: WebView, attempt: Int = 0) {
        if (!reportMode || !gasReportMode || confirmed) return
        // Прогресс обновляется по реальным этапам, но не влияет на сам сценарий входа.
        if (attempt == 0) { reportProgress = 5; message = "Газ: 5% — запускаем получение отчёта…" }
        // Важно: пользовательский ЛК показывает нужные суммы именно во вкладке/кнопке «Инфо».
        // Не переходим напрямую на abonentInfo.xhtml: в некоторых версиях ЛК это другой JSF-контекст.
        if (attempt == 0) {
            message = "Газ: открываем вкладку «Инфо»…"
            onStatus("Открываем вкладку «Инфо» ЛК газа")
            openGasInfoTab(w)
            w.postDelayed({ runGasReportRead(w, 1) }, 150)
            return
        }
        w.evaluateJavascript(gasReportExtractScript()) { raw ->
            val r = raw ?: ""
            val json = try { JSONObject("{\"data\":$r}").optString("data", r) } catch (_: Exception) { r }
            try {
                val o = JSONObject(json)
                val found = o.optBoolean("found", false)
                val loginVisible = o.optBoolean("loginVisible", false)
                val infoPage = o.optBoolean("infoSelected", false) || o.optBoolean("infoPanelVisible", false)
                val supply = o.optString("gasSupply", "не найдено")
                val maintenance = o.optString("maintenance", "не найдено")
                if (loginVisible) {
                    // Сессия ещё не установилась. Повторяем штатный JSF-вход,
                    // а после него снова открываем abonentInfo.xhtml.
                    if (attempt < 12) {
                        busy = true
                        message = "Газ: авторизация ЛК…"
                        startGasAutoLogin(w, 0)
                        w.postDelayed({ runGasReportRead(w, attempt + 1) }, 250)
                    } else {
                        busy = false
                        message = "Газ: не удалось войти в ЛК"
                        onStatus("Не удалось авторизоваться в ЛК газа")
                        onGasReportData?.invoke("не найдено", "не найдено", "", "")
                    }
                } else if (o.optBoolean("complete", false) && !loginVisible) {
                    reportProgress = 100
                    message = "Газ: 100% — отчёт получен ✓"
                    confirmed = true
                    busy = false
                    message = "✓ Газоснабжение и Техобслуживание получены из вкладки «Инфо»"
                    onStatus("Обе суммы газа получены")
                    onGasReportData?.invoke(supply, maintenance, "", "")
                } else if (!infoPage && attempt < 12) {
                    // Если суммы ещё не найдены, повторно ищем именно вкладку «Инфо».
                    openGasInfoTab(w)
                    w.postDelayed({ runGasReportRead(w, attempt + 1) }, 180)
                } else if (attempt >= 40 && !loginVisible) {
                    confirmed = true
                    busy = false
                    message = if (found) "В «Инфо» найдена только часть данных: проверьте страницу." else "Вкладка «Инфо» открыта, суммы не найдены."
                    onStatus(if (found) "Получена только часть данных" else "Суммы газа не найдены")
                    onGasReportData?.invoke(supply.ifBlank { "не найдено" }, maintenance.ifBlank { "не найдено" }, "", "")
                } else {
                    reportProgress = if (found) 80 else 60
                    message = if (found) "Газ: 80% — суммы найдены, завершаем отчёт…" else "Газ: 60% — получаем суммы…"
                    if (!infoPage) openGasInfoTab(w)
                    w.postDelayed({ runGasReportRead(w, attempt + 1) }, if (infoPage) 120 else 180)
                }
            } catch (_: Exception) {
                if (attempt < 30) w.postDelayed({ runGasReportRead(w, attempt + 1) }, 150)
                else { busy = false; onGasReportData?.invoke("не найдено", "не найдено", "", "") }
            }
        }
    }

    fun runElectricityReportRead(w: WebView, attempt:Int=0) {
        if (!reportMode || !electricityReportMode || confirmed) return
        w.evaluateJavascript("""(function(){
          const vis=e=>!!(e&&(e.offsetWidth||e.offsetHeight||e.getClientRects().length));
          const body=((document.body&&document.body.innerText)||'').replace(/\\u00a0/g,' ').trim();
          const low=body.toLowerCase();
          const pw=[...document.querySelectorAll('input[type=password]')].some(vis);
          const captcha=/капч|код с картинки|проверочн|captcha|числ.*картин/i.test(low);
          const login=/личный кабинет|лицевый счет|лицевой счет|войти/i.test(low)&&pw;
          function valueFor(words){
            const els=[...document.querySelectorAll('tr,li,div,p,td,span,dd')].filter(vis);
            for(const e of els){ const t=(e.innerText||e.textContent||'').replace(/\\s+/g,' ').trim(); if(!t||t.length>220) continue;
              if(words.some(w=>w.test(t))){ const m=t.match(/(-?\\d[\\d\\s]*[.,]\\d{1,2})\\s*(?:руб\\.?|₽)?/i); if(m) return m[1].trim(); }
            }
            return '';
          }
          const debt=valueFor([/задолж/i,/к оплате/i,/долг/i]);
          const accrued=valueFor([/начислен/i,/начислено/i]);
          const paid=valueFor([/оплачен/i,/оплачено/i,/платеж/i]);
          const reading=valueFor([/последн.*показ/i,/текущ.*показ/i,/показани.*счетчик/i]);
          const cabinet=!pw && !/введите.*код|код с картинки/i.test(low) && (/лицевой\\s*сч|начислен|оплачен|сч[её]т за электроэнергию|показан/i.test(low));
          return JSON.stringify({cabinet:!!cabinet,login:!!login,captcha:!!captcha,debt,accrued,paid,reading,url:location.href});
        })()""") { raw ->
            val r=raw ?: ""
            fun field(name:String)=Regex("\\\"$name\\\":\\\"([^\\\"]*)\\\"").find(r)?.groupValues?.getOrNull(1).orEmpty()
            val cabinet=Regex("\\\"cabinet\\\":true").containsMatchIn(r)
            val debt=field("debt"); val accrued=field("accrued"); val paid=field("paid"); val reading=field("reading")
            val captcha=Regex("\\\"captcha\\\":true").containsMatchIn(r)
            if(cabinet && (debt.isNotBlank()||accrued.isNotBlank()||paid.isNotBlank()||reading.isNotBlank())){
                confirmed=true; busy=false
                message="✓ Данные по свету получены"
                onStatus("Отчёт света получен")
                onElectricityReportData?.invoke(debt.ifBlank{"не найдено"},accrued.ifBlank{"не найдено"},paid.ifBlank{"не найдено"},reading.ifBlank{"не найдено"})
            } else if(attempt<120){
                busy=false
                message=if(captcha) "Свет: введите CAPTCHA и нажмите «Войти». После входа отчёт продолжится автоматически." else "Свет: ожидаем вход в ЛК…"
                onStatus(if(captcha) "Ожидается CAPTCHA" else "Ожидание входа")
                w.postDelayed({runElectricityReportRead(w,attempt+1)},1000)
            } else { busy=false; message="Свет: не удалось получить данные ЛК."; onStatus("Данные не получены") }
        }
    }

    fun runWaterReportRead(w: WebView, attempt: Int = 0) {
        if (!reportMode || confirmed) return
        w.evaluateJavascript(waterReportExtractScript()) { raw ->
            val r = raw ?: ""
            // evaluateJavascript returns a JSON-encoded string. Decode it first,
            // then read the exact values returned by the page parser.
            val json = try { JSONObject("{\"data\":$r}").optString("data", r) } catch (_: Exception) { r }
            val over = Regex("""\"overpayment\":\"([^\"]*)\"""").find(json)?.groupValues?.getOrNull(1).orEmpty()
            val debt = Regex("""\"debt\":\"([^\"]*)\"""").find(json)?.groupValues?.getOrNull(1).orEmpty()
            val penalty = Regex("""\"penalty\":\"([^\"]*)\"""").find(json)?.groupValues?.getOrNull(1).orEmpty()
            val found = Regex("""\"found\":true""").containsMatchIn(json)
            if (found) {
                confirmed = true
                busy = false
                message = "✓ Финансовые данные получены с текущей страницы ЛК"
                onReportData?.invoke(over.ifBlank { "отсутствует" }, debt.ifBlank { "отсутствует" }, penalty.ifBlank { "отсутствует" })
                return@evaluateJavascript
            }
            if (attempt < 15) w.postDelayed({ runWaterReportRead(w, attempt + 1) }, 900)
            else { busy = false; message = "На текущей странице ЛК финансовый блок не найден." }
        }
    }

    fun runFillAndSend() {
        val w = webViewRef ?: run { message = "Страница ещё загружается."; return }
        if (busy) return
        // Water: fill credentials and click the site's normal login button.
        // There is no CAPTCHA handling here; the site login is used as-is.
        // Gas remains in the manual-click test flow for now.
        if (job.type == MeterType.WATER) {
            busy = true
            message = "Кв. 1: открываем ЛК воды…"
            onStatus("Вход…")
            w.evaluateJavascript(autoFillScript(job)) { result ->
                val r = result ?: ""
                val phase = Regex("\"phase\":\"([^\"]+)\"").find(r)?.groupValues?.getOrNull(1) ?: ""
                if (phase == "login" || r.contains("\"ok\":true") || r.contains("login_filled")) {
                    message = "Кв. 1: вход выполняется…"
                    onStatus("Вход…")
                }
                fun tryFillWaterRow(attempt: Int) {
                    if (confirmed) return
                    w.evaluateJavascript(fillWaterReadingOnlyScript(job)) { fillResult ->
                        val fr = fillResult ?: ""
                        if (fr.contains("water_reading_filled") && fr.contains("\"ok\":true")) {
                            busy = false
                            message = "Кв. 1: ${job.title}, показание ${job.reading} записано. Галочка установлена."
                            onStatus("Показание заполнено")
                        } else if (attempt < 12) {
                            w.postDelayed({ tryFillWaterRow(attempt + 1) }, 1200)
                        } else {
                            busy = false
                            message = "Кв. 1: не найдена строка счётчика ${job.serial}."
                            onStatus("Проверьте заводской номер")
                        }
                    }
                }
                w.postDelayed({ tryFillWaterRow(1) }, 4500)
            }
            return
        }
        if (job.type == MeterType.GAS) {
            busy = true
            message = "Газ: автоматически входим в личный кабинет…"
            onStatus("Автоматический вход…")
            startGasAutoLogin(w)
            fun openGasFormAfterLogin(attempt: Int = 0) {
                if (confirmed) return
                if (attempt >= 30) {
                    busy = false
                    message = "Газ: кабинет открыт. Проверьте раздел «Счётчики»."
                    onStatus("Кабинет открыт")
                    return
                }
                w.evaluateJavascript(openGasReadingFormScript()) { rr ->
                    if (confirmed) return@evaluateJavascript
                    when {
                        rr?.contains("gas_reading_form") == true -> {
                            message = "Газ: форма показаний открыта. Заполняем значение…"
                            onStatus("Заполнение показания")
                            w.postDelayed({
                                if (confirmed) return@postDelayed
                                w.evaluateJavascript(fillGasReadingScript(job.reading)) { fr ->
                                    if (confirmed) return@evaluateJavascript
                                    busy = false
                                    if (fr?.contains("gas_reading_filled") == true && fr.contains("\"ok\":true")) {
                                        message = "Газ: показание ${job.reading} заполнено. Проверьте значение и нажмите OK вручную."
                                        onStatus("Показание заполнено")
                                    } else {
                                        message = "Газ: форма открыта, но поле показания не найдено. Проверьте его вручную."
                                        onStatus("Требуется проверка")
                                    }
                                }
                            }, if (job.apartmentId == 1) 80 else 150)
                        }
                        rr?.contains("gas_counters") == true -> {
                            message = "Газ: открываем раздел «Счётчики»…"
                            w.postDelayed({ openGasFormAfterLogin(attempt + 1) }, 300)
                        }
                        else -> w.postDelayed({ openGasFormAfterLogin(attempt + 1) }, if (job.apartmentId == 1) 60 else 120)
                    }
                }
            }

            fun waitForGasCabinet(attempt: Int) {
                if (confirmed) return
                if (attempt >= 80) {
                    busy = false
                    message = "Газ: автоматический вход не завершён. Проверьте страницу — кнопку «Войти» можно нажать вручную."
                    onStatus("Проверьте вход")
                    return
                }
                w.postDelayed({
                    if (confirmed) return@postDelayed
                    w.evaluateJavascript("""(function(){
                        const visible=e=>!!(e&&(e.offsetWidth||e.offsetHeight||e.getClientRects().length));
                        const body=((document.body&&document.body.innerText)||'').toLowerCase();
                        const pwVisible=[...document.querySelectorAll('input[type="password"]')].some(visible);
                        const loginWords=/регистрационные данные|войти в систему|забыли пароль/i.test(body);
                        const cabinetWords=/лицев\s*сч[ёе]т|абонент|сч[ёе]тчики|характеристики|история платежей/i.test(body);
                        if(cabinetWords && !pwVisible) return 'CABINET_PAGE';
                        if(pwVisible || loginWords) return 'LOGIN_PAGE';
                        return 'WAIT';
                    })()""") { state ->
                        when {
                            state.contains("CABINET_PAGE") -> {
                                try {
                                    val cookies = android.webkit.CookieManager.getInstance().getCookie(GAS) ?: ""
                                    if (cookies.isNotBlank()) store.putGasCookies(job.apartmentId, cookies)
                                } catch (_: Exception) {}
                                message = "Газ: вход выполнен. Открываем «Счётчики»…"
                                onStatus("Открываем счётчики")
                                openGasFormAfterLogin()
                            }
                            else -> waitForGasCabinet(attempt + 1)
                        }
                    }
                }, if (job.apartmentId == 1) 30 else 100)
            }
            waitForGasCabinet(0)
            return
        }
        busy = true
        onStatus("Заполняется…")
        message = "1/3 Заполняем данные…"
        w.evaluateJavascript(autoFillScript(job)) { result ->
            val r = result ?: ""
            val ok = r.contains("\\\"ok\\\":true")
            val phase = Regex("\\\"phase\\\":\\\"([^\\\"]+)\\\"").find(r)?.groupValues?.getOrNull(1) ?: "meter"
            val filled = Regex("\\\"filledCount\\\":(\\d+)").find(r)?.groupValues?.getOrNull(1) ?: "0"
            val loginUsed = Regex("\"loginUsed\":\"([^\"]*)\"").find(r)?.groupValues?.getOrNull(1) ?: ""
            if (phase == "navigate" || phase == "menu" || phase == "gas_lk" || phase == "gas_counters" || phase == "gas_readings" || phase == "login_wait") {
                busy = false
                message = when (phase) {
                    "menu" -> "Открываем меню Севэнергосбыта…"
                    "gas_counters" -> "Открываем раздел «Счётчики»…"
                    "gas_readings" -> "Открываем форму показаний газа…"
                    else -> "Открываем форму передачи показаний…"
                }
                onStatus("Открываем форму…")
                w.postDelayed({ if (!confirmed && !busy) runFillAndSend() }, 1200)
                return@evaluateJavascript
            }
            if (!ok) {
                busy = false
                message = "Не удалось автоматически заполнить нужные поля."
                onStatus("Требуется ввод")
                return@evaluateJavascript
            }
            if (phase == "login") {
                busy = false
                message = "2/3 Вход: $loginUsed…"
                onStatus("Вход…")
                w.postDelayed({ if (!confirmed && !busy) runFillAndSend() }, 3800)
                return@evaluateJavascript
            }
            message = "2/3 Показание ${job.reading} заполнено."
            onStatus("Данные заполнены")
            message = "3/3 Передаём показание…"
            onStatus("Передаётся…")
            w.postDelayed({
                    w.evaluateJavascript(autoSubmitScript(job.type)) { sr ->
                        val x = sr ?: ""
                        if (x.contains("\\\"ok\\\":true")) {
                            message = "3/3 Команда отправлена. Ждём подтверждение сайта…"
                            checkConfirmation(w)
                        } else {
                            busy = false
                            message = "Не удалось найти кнопку передачи. Откройте форму и попробуйте ещё раз."
                            onStatus("Требуется ввод")
                        }
                    }
                }, 900)
        }
    }

    fun sendNow() {
        val w = webViewRef ?: return
        if (busy) return
        busy = true
        message = "3/3 Передаём показание ${job.reading}…"
        onStatus("Передаётся…")
        w.evaluateJavascript(autoSubmitScript(job.type)) { r ->
            val x = r ?: ""
            if (x.contains("\\\"ok\\\":true")) {
                message = "Команда отправлена. Ждём подтверждение сайта…"
                checkConfirmation(w)
            } else {
                busy = false
                message = "Кнопку передачи не нашли."
                onStatus("Требуется ввод")
            }
        }
    }

    Column(Modifier.fillMaxSize()) {
        if (!reportMode) {
            Row(Modifier.fillMaxWidth().padding(8.dp), horizontalArrangement = Arrangement.SpaceBetween) {
                Text("Передача $index/$total", style = MaterialTheme.typography.titleMedium)
                TextButton(onClick = onBack, enabled = !busy) { Text("Назад") }
            }
            Text(message, Modifier.padding(horizontal = 12.dp))
            Row(Modifier.padding(8.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Button(onClick = { runFillAndSend() }, enabled = !busy && !confirmed) { Text("Передать") }
                Button(onClick = onBack, enabled = !busy) { Text("Назад") }
            }
            if ((job.type == MeterType.GAS && job.apartmentId == 1) || job.type == MeterType.ELECTRICITY || job.type == MeterType.WATER) {
                OutlinedButton(onClick = { webViewRef?.let { saveCurrentPageHtml(it) } }, enabled = !busy) {
                    Text(when (job.type) {
                        MeterType.ELECTRICITY -> "Сохранить HTML страницы света"
                        MeterType.WATER -> "Сохранить HTML страницы воды"
                        MeterType.GAS -> "Сохранить HTML страницы газа"
                    })
                }
            }
        }
        if (gasReportMode && job.type == MeterType.GAS) {
            Column(Modifier.fillMaxWidth().padding(top = 8.dp, bottom = 8.dp)) {
                Text("Получение отчёта: $reportProgress%", Modifier.padding(horizontal = 12.dp), style = MaterialTheme.typography.titleMedium)
                LinearProgressIndicator(
                    progress = { (reportProgress.coerceIn(0, 100)) / 100f },
                    modifier = Modifier.fillMaxWidth().padding(horizontal = 12.dp)
                )
                Text(message, Modifier.padding(horizontal = 12.dp, vertical = 6.dp), maxLines = 2)
            }
        }
        AndroidView(factory = { context ->
            WebView(context).apply {
                webViewRef = this
                onWebViewReady(this)
                settings.javaScriptEnabled = true
                settings.domStorageEnabled = true
                settings.databaseEnabled = true
                settings.cacheMode = android.webkit.WebSettings.LOAD_DEFAULT
                // During the SevGaz login page, images are not needed for authentication.
                // Avoid waiting for image resources; restore them once the cabinet is reached.
                settings.loadsImagesAutomatically = (job.type != MeterType.GAS)
                settings.javaScriptCanOpenWindowsAutomatically = true
                settings.setSupportMultipleWindows(false)
                settings.mixedContentMode = android.webkit.WebSettings.MIXED_CONTENT_COMPATIBILITY_MODE
                android.webkit.CookieManager.getInstance().setAcceptCookie(true)
                android.webkit.CookieManager.getInstance().setAcceptThirdPartyCookies(this, true)
                // Each job starts a fresh cabinet session. For GAS we deliberately
                // keep the WebView cache for speed, but never keep cookies/session
                // from the previous apartment. Form data is also cleared so WebView
                // autofill cannot reinsert an old apartment's credentials.
                if (job.type != MeterType.GAS) {
                    android.webkit.CookieManager.getInstance().removeAllCookies(null)
                    android.webkit.CookieManager.getInstance().flush()
                    clearHistory()
                    clearCache(true)
                    clearFormData()
                    clearSslPreferences()
                } else {
                    clearFormData()
                }
                settings.useWideViewPort = true
                settings.loadWithOverviewMode = true
                // Разрешаем увеличение/уменьшение страницы жестом двумя пальцами.
                settings.setSupportZoom(true)
                settings.builtInZoomControls = true
                settings.displayZoomControls = false
                settings.textZoom = 100
                // Keep the standard Android WebView user-agent. The Sevgaz cabinet can reject modified WebView user-agents.
                webChromeClient = object : WebChromeClient() {
                    override fun onReceivedTitle(view: WebView, title: String) {
                        super.onReceivedTitle(view, title)
                        if (title.isNotBlank()) message = "Страница: $title"
                    }
                }
                webViewClient = object : WebViewClient() {
                    override fun shouldOverrideUrlLoading(view: WebView, request: android.webkit.WebResourceRequest): Boolean {
                        // Let WebView handle normal form POST/redirect navigation itself.
                        // Intercepting and re-loading the URL can turn a POST login into a GET.
                        return false
                    }
                    override fun shouldOverrideUrlLoading(view: WebView, url: String): Boolean {
                        return false
                    }
                    override fun onPageCommitVisible(view: WebView, url: String) {
                        super.onPageCommitVisible(view, url)
                        onWebViewReady(view)
                        // Start the gas login as soon as the first page content is visible,
                        // instead of waiting for every page resource to finish loading.
                        // This can remove several seconds of WebView resource-loading delay
                        // while keeping the same proven JSF login submission.
                        if (!confirmed && !reportMode && job.type == MeterType.GAS && !gasInitialPrepared &&
                            !url.contains("/irb/view/abonentInfo.xhtml", ignoreCase = true)) {
                            gasInitialPrepared = true
                            message = "Газ: готовим поля входа…"
                            onStatus("Подготовка входа")
                            webViewRef = view
                            startGasAutoLogin(view)
                        }
                    }
                    override fun onPageStarted(view: WebView, url: String, favicon: android.graphics.Bitmap?) {
                        onWebViewReady(view)
                        message = "Загрузка: ${url.take(80)}…"
                    }
                    override fun onReceivedError(view: WebView, request: android.webkit.WebResourceRequest, error: android.webkit.WebResourceError) {
                        if (request.isForMainFrame) message = "Ошибка загрузки: ${error.description}"
                    }
                    override fun onPageFinished(view: WebView, loadedUrl: String) {
                        onWebViewReady(view)
                        if (!confirmed) {
                            if (reportMode) {
                                if (electricityReportMode && job.type == MeterType.ELECTRICITY) {
                                    if (!reportStarted) {
                                        reportStarted = true
                                        busy = true
                                        message = "Свет: заполните CAPTCHA и войдите в ЛК…"
                                        view.evaluateJavascript(autoFillScript(job)) { _ -> view.postDelayed({ runElectricityReportRead(view) }, 1200) }
                                    } else {
                                        view.postDelayed({ runElectricityReportRead(view) }, 500)
                                    }
                                } else if (gasReportMode && job.type == MeterType.GAS) {
                                    val loginPage = loadedUrl.contains("/irb/login", true) || loadedUrl.contains("login.xhtml", true) || (loadedUrl.contains("/irb/", true) && view.url?.contains("login", true) == true)
                                    if (loginPage && !reportStarted) {
                                        reportStarted = true
                                        message = "ЛК газа: выполняем вход…"
                                        busy = true
                                        // Для одного отчёта и для режима «все квартиры» используем
                                        // один и тот же проверенный WebView/JSF-вход. Это важно для
                                        // последовательной обработки нескольких квартир: native-вход
                                        // раньше создавал отдельную HTTP-сессию и после редиректа мог
                                        // терять cookies WebView, из-за чего общий отчёт останавливался.
                                        startGasAutoLogin(view)
                                    } else if (!reportStarted) {
                                        reportStarted = true
                                        message = "ЛК газа загружен. Читаем вкладку «Инфо»…"
                                        busy = true
                                        view.postDelayed({ runGasReportRead(view) }, 150)
                                    } else {
                                        view.postDelayed({ runGasReportRead(view) }, 150)
                                    }
                                } else {
                                    message = "ЛК воды загружен. Читаем данные отчёта…"
                                    busy = true
                                    if (!reportStarted) {
                                        reportStarted = true
                                        view.evaluateJavascript(autoFillScript(job)) { _ ->
                                            view.postDelayed({ runWaterReportRead(view) }, 3200)
                                        }
                                    } else {
                                        view.postDelayed({ runWaterReportRead(view) }, 700)
                                    }
                                }
                            } else if (job.type == MeterType.GAS) {
                                // Газ: используем тот же проверенный пошаговый сценарий, который
                                // применялся для квартиры 2: дождаться JSF-формы, заполнить
                                // логин/пароль, нажать штатную кнопку входа, дождаться кабинета,
                                // открыть «Счётчики» и форму показаний.
                                if (loadedUrl.contains("/irb/view/abonentInfo.xhtml", ignoreCase = true)) {
                                    // The server can return abonentInfo.xhtml while still showing
                                    // the login form (for example when the first submit did not
                                    // establish the session). Do not report success from URL alone.
                                    view.evaluateJavascript("""(function(){
                                         const visible=e=>!!(e&&(e.offsetWidth||e.offsetHeight||e.getClientRects().length));
                                         const body=((document.body&&document.body.innerText)||'').toLowerCase();
                                         const pwVisible=[...document.querySelectorAll('input[type="password"]')].some(visible);
                                         const loginWords=/регистрационные данные|войти в систему|забыли пароль/i.test(body);
                                         const cabinetWords=/лицевой\s*сч[её]т|абонент|сч[ёе]тчики|характеристики|история платежей/i.test(body);
                                         const cabinet=cabinetWords && !pwVisible;
                                         return cabinet ? 'CABINET_PAGE' : ((pwVisible||loginWords) ? 'LOGIN_PAGE' : 'UNKNOWN_PAGE');
                                    })()""") { stateResult ->
                                        val state = stateResult ?: ""
                                        when {
                                            state.contains("CABINET_PAGE") -> {
                                                view.settings.loadsImagesAutomatically = true
                                                busy = true
                                                message = "Газ: вход выполнен. Открываем «Счётчики»…"
                                                onStatus("Открываем счётчики")
                                                fun openGasForm(attempt: Int = 0) {
                                                    if (confirmed) return
                                                    if (attempt >= 30) {
                                                        busy = false
                                                        message = "Газ: кабинет открыт. Откройте «Счётчики» вручную."
                                                        onStatus("Открыта страница")
                                                        return
                                                    }
                                                    view.evaluateJavascript(openGasReadingFormScript()) { rr ->
                                                        if (confirmed) return@evaluateJavascript
                                                        when {
                                                            rr?.contains("gas_reading_form") == true -> {
                                                                busy = true
                                                                message = "Газ: форма показаний открыта. Заполняем значение…"
                                                                onStatus("Заполнение показания")
                                                                view.postDelayed({
                                                                    if (confirmed) return@postDelayed
                                                                    view.evaluateJavascript(fillGasReadingScript(job.reading)) { fr ->
                                                                        if (confirmed) return@evaluateJavascript
                                                                        if (fr?.contains("gas_reading_filled") == true && fr.contains("\"ok\":true")) {
                                                                            busy = false
                                                                            message = "Газ: показание ${job.reading} заполнено. Проверьте значение и нажмите OK вручную."
                                                                            onStatus("Показание заполнено")
                                                                        } else {
                                                                            busy = false
                                                                            message = "Газ: форма открыта, но поле показания не найдено. Проверьте его вручную."
                                                                            onStatus("Требуется проверка")
                                                                        }
                                                                    }
                                                                }, 150)
                                                            }
                                                            rr?.contains("gas_counters") == true -> {
                                                                message = "Газ: открываем раздел «Счётчики»…"
                                                                view.postDelayed({ openGasForm(attempt + 1) }, 100)
                                                            }
                                                            else -> view.postDelayed({ openGasForm(attempt + 1) }, 80)
                                                        }
                                                    }
                                                }
                                                view.postDelayed({ openGasForm() }, 60)
                                            }
                                            state.contains("LOGIN_PAGE") -> {
                                                // Если JSF вернул нас на форму входа, снова запускаем тот же
                                                // polling-алгоритм. Важно не оставлять заполненную форму без клика.
                                                message = "Газ: автоматически выполняем вход…"
                                                onStatus("Автоматический вход…")
                                                busy = false
                                                startGasAutoLogin(view)
                                                fun waitForGasLoginResult(attempt: Int) {
                                                    if (confirmed) return
                                                    if (attempt >= 50) {
                                                        busy = false
                                                        message = "Газ: кабинет не обнаружен. Если кабинет уже открыт, нажми «Передать» ещё раз."
                                                        onStatus("Вход не подтверждён")
                                                        return
                                                    }
                                                    view.postDelayed({
                                                        if (confirmed) return@postDelayed
                                                        view.evaluateJavascript("""(function(){
                                                             const visible=e=>!!(e&&(e.offsetWidth||e.offsetHeight||e.getClientRects().length));
                                                             const body=((document.body&&document.body.innerText)||'').toLowerCase();
                                                             const pwVisible=[...document.querySelectorAll('input[type="password"]')].some(visible);
                                                             const loginWords=/регистрационные данные|войти в систему|забыли пароль/i.test(body);
                                                             const cabinetWords=/лицевой\s*сч[ёе]т|абонент|сч[ёе]тчики|характеристики|история платежей/i.test(body);
                                                             const cabinet=cabinetWords && !pwVisible;
                                                             if (cabinet) return 'CABINET_PAGE';
                                                             if (pwVisible || loginWords) return 'LOGIN_PAGE';
                                                             return 'UNKNOWN_PAGE';
                                                        })()""") { rr ->
                                                            if (!confirmed) {
                                                            when {
                                                                rr.contains("CABINET_PAGE") -> {
                                                                    view.settings.loadsImagesAutomatically = true
                                                                    busy = false
                                                                    try {
                                                                        val cookies = android.webkit.CookieManager.getInstance().getCookie(GAS) ?: ""
                                                                        if (cookies.isNotBlank()) store.putGasCookies(job.apartmentId, cookies)
                                                                    } catch (_: Exception) {}
                                                                    message = "Газ: вход выполнен. Открыт личный кабинет."
                                                                    onStatus("Вход выполнен")
                                                                }
                                                                attempt >= 30 -> {
                                                                    busy = false
                                                                    message = "Газ: не дождались ответа сервера. Если кабинет уже открыт, можно продолжить."
                                                                    onStatus("Кабинет проверяется")
                                                                }
                                                                else -> waitForGasLoginResult(attempt + 1)
                                                            }
                                                            }
                                                        }
                                                    }, 50)
                                                }
                                                waitForGasLoginResult(0)
                                            }
                                            else -> {
                                                busy = false
                                                message = "Газ: проверяем результат входа…"
                                                onStatus("Проверка входа")
                                            }
                                        }
                                    }
                                } else if (!gasInitialPrepared) {
                                    gasInitialPrepared = true
                                    message = "Газ: готовим поля входа…"
                                    onStatus("Подготовка входа")
                                    webViewRef = view
                                    // The script itself polls for the JSF controls every 100 ms.
                                    // Start immediately after page load.
                                    startGasAutoLogin(view)
                                }
                            } else {
                                message = "Страница загружена. Подготовка передачи…"
                                view.postDelayed({ webViewRef = view; runFillAndSend() }, 1800)
                                view.postDelayed({ if (!confirmed) { busy = false; webViewRef = view; runFillAndSend() } }, 3000)
                                view.postDelayed({ if (!confirmed) { busy = false; webViewRef = view; runFillAndSend() } }, 6000)
                            }
                        }
                    }
                }
                if (job.type == MeterType.GAS) {
                    // Gas gets an isolated cookie jar per apartment. We still keep the
                    // WebView cache, but restore only this apartment's saved session.
                    // That makes repeat opens fast without leaking apartment A's session
                    // into apartment B.
                    val savedCookies = store.gasCookies(job.apartmentId)
                    val cm = android.webkit.CookieManager.getInstance()
                    val parts = savedCookies.split(';').map { it.trim() }.filter { it.contains('=') }
                    // IMPORTANT: WebView has one shared cookie jar for all apartment jobs.
                    // Always clear the previous SevGaz session before restoring the cookies
                    // belonging to this apartment. Otherwise a previous apartment (for example
                    // Kv.4) can remain authenticated and the server will open that cabinet.
                    cm.removeAllCookies {
                        val restore = {
                            if (parts.isNotEmpty()) {
                                var left = parts.size
                                parts.forEach { cookie ->
                                    cm.setCookie(GAS, cookie) {
                                        left--
                                        if (left == 0) {
                                            cm.flush()
                                            post { loadUrl(url) }
                                        }
                                    }
                                }
                            } else {
                                cm.flush()
                                post { loadUrl(url) }
                            }
                        }
                        restore()
                    }
                } else {
                    loadUrl(url)
                }
            }
            }, modifier = if (reportMode) Modifier.size(1.dp) else Modifier.fillMaxSize())
    }
}

