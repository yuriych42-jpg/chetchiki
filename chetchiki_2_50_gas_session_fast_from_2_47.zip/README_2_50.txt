2.50 — fast per-apartment SevGaz session based on 2.49 (which is based on 2.47)

- Keeps a separate SevGaz cookie session for each apartment.
- Saves the last authenticated cabinet URL for each apartment.
- On repeat open, restores that apartment's cookies and opens the saved cabinet URL directly.
- Falls back to the normal login URL if no saved session exists.
- Saves cookies/session URL whenever an authenticated cabinet page is detected, including gas report mode.
- Keeps the 2.49 progress UI and the 2.47/2.49 report logic.
