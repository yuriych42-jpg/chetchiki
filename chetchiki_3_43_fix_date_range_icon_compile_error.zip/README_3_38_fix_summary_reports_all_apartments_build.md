# Version 3.38 — fix build and summary reports for all apartments

- Restored the complete `MainActivity.kt` source from version 3.36; the 3.37 archive accidentally omitted substantial code, causing unresolved references during Kotlin compilation.
- Added a summary-report button for every configured apartment, using the apartment name and address from settings.
- Selecting a summary opens data for that apartment ID only.
- Kept the existing summary report content and other app features from version 3.36.
- `versionName = 3.38`, `versionCode = 338`.
