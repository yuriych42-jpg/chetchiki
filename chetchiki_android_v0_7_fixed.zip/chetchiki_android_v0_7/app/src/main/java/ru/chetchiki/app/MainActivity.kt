package ru.chetchiki.app

import android.annotation.SuppressLint
import android.os.Bundle
import android.webkit.WebView
import android.webkit.WebViewClient
import android.webkit.WebChromeClient
import org.json.JSONObject
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView

enum class MeterType { ELECTRICITY, WATER, GAS }

data class Meter(
    val id: Int,
    val type: MeterType,
    val title: String,
    val serial: String = "",
    val reading: String = "",
    val status: String = "Не передано"
)

data class Apartment(val id: Int, val address: String, val meters: List<Meter>)

data class Job(
    val apartmentId: Int,
    val address: String,
    val meterId: Int,
    val type: MeterType,
    val title: String,
    val reading: String
)

private const val ENERGY = "https://sevenergosbyt.ru/flk/index.php"
private const val WATER = "https://sevvodokanal.org.ru/app/webroot/account.php"
private const val GAS = "https://lk.gup-sevgaz.ru:8443/irb/login.xhtml"

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { MeterApp() }
    }
}

@Composable
fun MeterApp() {
    var apartments by remember {
        mutableStateOf(
            listOf(
                Apartment(1, "Адрес квартиры 1", listOf(
                    Meter(1, MeterType.ELECTRICITY, "Электричество"),
                    Meter(2, MeterType.WATER, "Вода №1"),
                    Meter(3, MeterType.WATER, "Вода №2"),
                    Meter(4, MeterType.GAS, "Газ")
                )),
                Apartment(2, "Адрес квартиры 2", listOf(
                    Meter(5, MeterType.ELECTRICITY, "Электричество"),
                    Meter(6, MeterType.WATER, "Вода"),
                    Meter(7, MeterType.GAS, "Газ")
                )),
                Apartment(3, "Адрес квартиры 3", listOf(
                    Meter(8, MeterType.ELECTRICITY, "Электричество"),
                    Meter(9, MeterType.WATER, "Вода"),
                    Meter(10, MeterType.GAS, "Газ")
                )),
                Apartment(4, "Адрес квартиры 4", listOf(
                    Meter(11, MeterType.ELECTRICITY, "Электричество"),
                    Meter(12, MeterType.WATER, "Вода №1"),
                    Meter(13, MeterType.WATER, "Вода №2")
                ))
            )
        )
    }

    var jobs by remember { mutableStateOf(listOf<Job>()) }
    var activeJobIndex by remember { mutableIntStateOf(0) }
    var webUrl by remember { mutableStateOf<String?>(null) }
    var pageText by remember { mutableStateOf("") }
    var webViewRef by remember { mutableStateOf<WebView?>(null) }

    fun updateStatus(job: Job, status: String) {
        apartments = apartments.map { a ->
            if (a.id != job.apartmentId) a else a.copy(
                meters = a.meters.map { m ->
                    if (m.id == job.meterId) m.copy(status = status) else m
                }
            )
        }
    }

    fun startJobs(newJobs: List<Job>) {
        if (newJobs.isEmpty()) return
        jobs = newJobs
        activeJobIndex = 0
        webUrl = providerUrl(newJobs[0].type)
        updateStatus(newJobs[0], "Открыт кабинет")
    }

    fun nextJob() {
        val next = activeJobIndex + 1
        if (next >= jobs.size) {
            pageText = "Готово: обработана очередь из ${jobs.size} показаний."
            webUrl = null
            return
        }
        activeJobIndex = next
        val job = jobs[next]
        updateStatus(job, "Открыт кабинет")
        webUrl = providerUrl(job.type)
    }

    if (webUrl != null && jobs.isNotEmpty()) {
        val job = jobs[activeJobIndex]
        ProviderScreen(
            url = webUrl!!,
            job = job,
            index = activeJobIndex + 1,
            total = jobs.size,
            onWebViewReady = { webViewRef = it },
            onStatus = { status -> updateStatus(job, status) },
            onNext = { nextJob() },
            onBack = { webUrl = null }
        )
        return
    }

    Scaffold(
        topBar = { TopAppBar(title = { Text("Счётчики") }) },
        bottomBar = {
            Button(
                onClick = {
                    val all = apartments.flatMap { a ->
                        a.meters.filter { it.reading.isNotBlank() }.map { m ->
                            Job(a.id, a.address, m.id, m.type, m.title, m.reading)
                        }
                    }
                    startJobs(all)
                },
                modifier = Modifier.fillMaxWidth().padding(12.dp)
            ) { Text("Передать всё — все квартиры") }
        }
    ) { padding ->
        LazyColumn(
            Modifier.padding(padding).padding(12.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            items(apartments, key = { it.id }) { apartment ->
                Card(Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(12.dp)) {
                        Text(apartment.address, style = MaterialTheme.typography.titleMedium)
                        Spacer(Modifier.height(8.dp))
                        apartment.meters.forEach { meter ->
                            OutlinedTextField(
                                value = meter.reading,
                                onValueChange = { v ->
                                    apartments = apartments.map { a ->
                                        if (a.id != apartment.id) a else a.copy(
                                            meters = a.meters.map { m ->
                                                if (m.id == meter.id) m.copy(reading = v, status = "Не передано") else m
                                            }
                                        )
                                    }
                                },
                                label = { Text("${meter.title} — показание") },
                                singleLine = true,
                                modifier = Modifier.fillMaxWidth()
                            )
                            Row(
                                Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text(meter.status)
                                TextButton({
                                    startJobs(listOf(Job(
                                        apartment.id, apartment.address, meter.id,
                                        meter.type, meter.title, meter.reading
                                    )))
                                }) { Text("Передать") }
                            }
                        }
                        Button(
                            onClick = {
                                startJobs(apartment.meters.filter { it.reading.isNotBlank() }.map { m ->
                                    Job(apartment.id, apartment.address, m.id, m.type, m.title, m.reading)
                                })
                            },
                            Modifier.fillMaxWidth()
                        ) { Text("Передать показания этой квартиры") }
                    }
                }
            }
        }
    }
}

private fun providerUrl(type: MeterType) = when (type) {
    MeterType.ELECTRICITY -> ENERGY
    MeterType.WATER -> WATER
    MeterType.GAS -> GAS
}

/*
 * The script deliberately does not bypass CAPTCHA or authentication.
 * It searches visible form fields using labels/names/placeholders and fills
 * a likely meter-reading input. Submission is left to the site's own button
 * and the user when confirmation/CAPTCHA is required.
 */
private fun autoFillScript(job: Job): String {
    val reading = JSONObject.quote(job.reading)
    val serial = JSONObject.quote(job.serial)
    val kind = JSONObject.quote(job.type.name.lowercase())
    return """
    (function(){
      const reading=$reading, serial=$serial, kind=$kind;
      const els=[...document.querySelectorAll('input,textarea')];
      function text(e){
        return ((e.getAttribute('aria-label')||'')+' '+
          (e.getAttribute('placeholder')||'')+' '+
          (e.getAttribute('name')||'')+' '+
          (e.id||'')).toLowerCase();
      }
      const candidates=els.filter(e=>!e.disabled && e.type!=='hidden' && e.type!=='password');
      const meterWords=['показ','показан','reading','значен','meter','счётчик','счетчик'];
      let target=candidates.find(e=>{
        const t=text(e);
        return meterWords.some(w=>t.includes(w)) && (e.type==='text'||e.type==='number');
      });
      if(!target) target=candidates.find(e=>e.type==='number'||e.inputMode==='decimal');
      if(target){
        target.focus();
        const setter=Object.getOwnPropertyDescriptor(HTMLInputElement.prototype,'value')?.set;
        if(setter) setter.call(target,reading); else target.value=reading;
        target.dispatchEvent(new Event('input',{bubbles:true}));
        target.dispatchEvent(new Event('change',{bubbles:true}));
        return JSON.stringify({ok:true,field:target.name||target.id||target.placeholder||''});
      }
      return JSON.stringify({ok:false});
    })()
    """.trimIndent()
}

@SuppressLint("SetJavaScriptEnabled")
@Composable
fun ProviderScreen(
    url: String,
    job: Job,
    index: Int,
    total: Int,
    onWebViewReady: (WebView) -> Unit,
    onStatus: (String) -> Unit,
    onNext: () -> Unit,
    onBack: () -> Unit
) {
    var message by remember(url, job.meterId) {
        mutableStateOf("${job.address}\n${job.title}: ${job.reading}\nШаг $index из $total")
    }

    Column(Modifier.fillMaxSize()) {
        Row(
            Modifier.fillMaxWidth().padding(8.dp),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Text("Передача", style = MaterialTheme.typography.titleMedium)
            TextButton(onClick = onBack) { Text("Назад") }
        }
        Text(message, Modifier.padding(horizontal = 12.dp))
        Row(Modifier.padding(8.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Button({
                onStatus("Заполняется")
                message = "Ищем поле показания..."
            }) { Text("Заполнить") }
            Button({
                onStatus("Передано")
                message = "Отмечено как переданное. Проверь результат на сайте."
            }) { Text("Готово") }
            Button({ onNext() }) { Text(if (index < total) "Следующее" else "Завершить") }
        }

        AndroidView(
            factory = { context ->
                WebView(context).apply {
                    settings.javaScriptEnabled = true
                    settings.domStorageEnabled = true
                    settings.loadsImagesAutomatically = true
                    webViewClient = object : WebViewClient() {
                        override fun onPageFinished(view: WebView, loadedUrl: String) {
                            onWebViewReady(view)
                            view.evaluateJavascript(autoFillScript(job)) { result ->
                                if (result?.contains("\"ok\":true") == true) {
                                    onStatus("Поле заполнено")
                                    message = "Показание подставлено. Проверь его и нажми кнопку отправки на сайте. CAPTCHA — вручную."
                                } else {
                                    message = "Поле автоматически не найдено. Введи показание на сайте вручную."
                                    onStatus("Требуется ввод")
                                }
                            }
                        }
                    }
                    loadUrl(url)
                }
            },
            modifier = Modifier.fillMaxSize()
        )
    }
}
