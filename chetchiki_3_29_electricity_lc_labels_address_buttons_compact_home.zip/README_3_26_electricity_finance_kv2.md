# Version 3.26 — electricity finance for apartment 2

- Enabled the “Данные в отчёт” button for electricity submissions in every apartment, including Кв. 2.
- Saves overpayment, debt, and penalty under the active apartment's own report keys.
- Shows electricity report entries for all apartments that have an electricity meter.
- Finance values are read from the currently displayed personal-account page when the button is pressed; no amount is hardcoded.

Version: 3.26 (versionCode 326).
