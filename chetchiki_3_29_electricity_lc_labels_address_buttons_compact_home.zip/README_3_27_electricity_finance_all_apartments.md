# Version 3.27 — electricity finance for all apartments

- The “Данные в отчёт” button reads the financial values visible on the current personal-account page at the moment it is pressed.
- Finance data is stored under the active electricity job's apartment ID, not a hardcoded apartment number. This supports apartments 1–4 and additional apartments added later.
- Overpayment, debt, penalty, and capture timestamp are saved separately for each apartment.

Version: 3.27 (versionCode 327).

Build status: Android/Gradle build has not been run in this environment; verify with GitHub Actions after uploading the ZIP.
