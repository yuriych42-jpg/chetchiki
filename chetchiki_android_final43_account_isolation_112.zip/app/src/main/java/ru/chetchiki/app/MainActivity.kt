@file:OptIn(ExperimentalMaterial3Api::class)
package ru.chetchiki.app

import android.annotation.SuppressLint
import android.content.Context
import android.os.Bundle
import android.os.SystemClock
import android.view.MotionEvent
import android.webkit.WebView
import android.webkit.WebViewClient
import android.webkit.WebChromeClient
import org.json.JSONObject
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.rememberScrollState
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.viewinterop.AndroidView

enum class MeterType { ELECTRICITY, WATER, GAS }

data class Meter(
    val id: Int,
    val type: MeterType,
    val title: String,
    val serial: String = "",
    val reading: String = "",
    val status: String = "Не передано"
)

data class Apartment(val id: Int, val address: String, val meters: List<Meter>)

data class Credentials(
    val energySurname: String = "",
    val energyAccount: String = "",
    val energySerial: String = "",
    val waterLogin: String = "",
    val waterPassword: String = "",
    val gasLogin: String = "",
    val gasPassword: String = ""
)

data class Job(
    val apartmentId: Int,
    val address: String,
    val meterId: Int,
    val type: MeterType,
    val title: String,
    val reading: String,
    val serial: String = "",
    val credentials: Credentials = Credentials(),
    val providerUrl: String = ""
)

private const val ENERGY = "https://sevenergosbyt.ru/flk/index.php"
private const val WATER = "https://sevvodokanal.org.ru/app/webroot/account.php"
private const val GAS = "https://lk.gup-sevgaz.ru:8080/irb/login.xhtml"

private fun defaultApartments() = listOf(
    Apartment(1, "Адрес квартиры 1", listOf(
        Meter(1, MeterType.ELECTRICITY, "Электричество"), Meter(2, MeterType.WATER, "Вода №1"), Meter(3, MeterType.WATER, "Вода №2"), Meter(4, MeterType.GAS, "Газ")
    )),
    Apartment(2, "Адрес квартиры 2", listOf(
        Meter(5, MeterType.ELECTRICITY, "Электричество"), Meter(6, MeterType.WATER, "Вода"), Meter(7, MeterType.GAS, "Газ")
    )),
    Apartment(3, "Адрес квартиры 3", listOf(
        Meter(8, MeterType.ELECTRICITY, "Электричество"), Meter(9, MeterType.WATER, "Вода"), Meter(10, MeterType.GAS, "Газ")
    )),
    Apartment(4, "Адрес квартиры 4", listOf(
        Meter(11, MeterType.ELECTRICITY, "Электричество"), Meter(12, MeterType.WATER, "Вода №1"), Meter(13, MeterType.WATER, "Вода №2"), Meter(14, MeterType.GAS, "Газ")
    ))
)

private fun newApartment(id: Int) = Apartment(id, "Адрес квартиры $id", listOf(
    Meter(id * 100 + 1, MeterType.ELECTRICITY, "Электричество"),
    Meter(id * 100 + 2, MeterType.WATER, "Вода"),
    Meter(id * 100 + 3, MeterType.GAS, "Газ")
))

// ГАЗ КВАРТИР 1–4: автоматический вход и подготовка показания — ВЕРСИЯ 0.92
class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { MeterApp(applicationContext) }
    }
}

private class LocalStore(context: Context) {
    private val p = context.getSharedPreferences("meter_store", Context.MODE_PRIVATE)
    fun get(k: String, d: String = "") = p.getString(k, d) ?: d
    fun put(k: String, v: String) { p.edit().putString(k, v).commit() }
    fun gasCookies(id: Int): String = get("gas_cookies_$id")
    fun putGasCookies(id: Int, v: String) { p.edit().putString("gas_cookies_$id", v).apply() }
    fun commitAddress(k: String, v: String) { p.edit().putString(k, v).commit() }
    fun apartmentIds(): List<Int> {
        val saved = get("apartment_ids")
        if (saved.isBlank()) {
            val ids = defaultApartments().map { it.id }
            p.edit().putString("apartment_ids", ids.joinToString(",")).commit()
            return ids
        }
        return saved.split(",").mapNotNull { it.trim().toIntOrNull() }.distinct().sorted()
    }
    fun saveApartmentIds(ids: List<Int>) { p.edit().putString("apartment_ids", ids.distinct().sorted().joinToString(",")).commit() }
    fun providerUrl(id: Int, type: MeterType): String = get("provider_url_${type.name}_$id", when (type) { MeterType.ELECTRICITY -> ENERGY; MeterType.WATER -> WATER; MeterType.GAS -> GAS })
    fun saveProviderUrl(id: Int, type: MeterType, value: String) { put("provider_url_${type.name}_$id", value) }
    fun waterLogin(id: Int): String {
        // Only provide the known default for apartment 1 when no value exists.
        // Never overwrite a value that the user has entered and saved.
        val key = "water_login_$id"
        val saved = get(key)
        if (id == 1 && saved.isBlank()) {
            commitAddress(key, "30118")
            return "30118"
        }
        return saved
    }
    fun credentials(id: Int) = Credentials(
        get("energy_surname_$id"), get("energy_account_$id"), get("energy_serial_$id"),
        waterLogin(id), get("water_password_$id"), get("gas_login_$id"), get("gas_password_$id")
    )
}

@Composable
fun MeterApp(context: Context) {
    val store = remember { LocalStore(context) }
    var apartments by remember {
        mutableStateOf(store.apartmentIds().map { id ->
            val base = defaultApartments().firstOrNull { it.id == id } ?: newApartment(id)
            base.copy(address = store.get("address_${id}", base.address), meters = base.meters.map { m -> m.copy(serial = store.get("serial_${m.id}"), reading = store.get("reading_${m.id}"), status = store.get("status_${m.id}", "Не передано")) })
        })
    }
    var credentialsVersion by remember { mutableIntStateOf(0) }
    var jobs by remember { mutableStateOf(listOf<Job>()) }
    var activeJobIndex by remember { mutableIntStateOf(0) }
    var webUrl by remember { mutableStateOf<String?>(null) }
    var webViewRef by remember { mutableStateOf<WebView?>(null) }
    var settings by remember { mutableStateOf(false) }

    fun updateMeter(apartmentId: Int, meterId: Int, reading: String? = null, serial: String? = null, status: String? = null) {
        apartments = apartments.map { a -> if (a.id != apartmentId) a else a.copy(meters = a.meters.map { m -> if (m.id != meterId) m else m.copy(reading = reading ?: m.reading, serial = serial ?: m.serial, status = status ?: m.status) }) }
        if (reading != null) store.put("reading_$meterId", reading)
        if (serial != null) store.put("serial_$meterId", serial)
        if (status != null) store.put("status_$meterId", status)
    }
    fun updateStatus(job: Job, status: String) = updateMeter(job.apartmentId, job.meterId, status = status)
    fun makeJob(a: Apartment, m: Meter): Job {
        // Критично: учётные данные всегда принадлежат выбранной квартире.
        // Раньше здесь для света и газа был ошибочный hard-code credentials(1),
        // из-за чего после переключения квартиры оставался ЛК предыдущей квартиры.
        // Алгоритм передачи света/газа общий, но credentials — выбранной квартиры.
        val credentials = store.credentials(a.id)
        return Job(a.id, a.address, m.id, m.type, m.title, m.reading, m.serial, credentials, store.providerUrl(a.id, m.type))
    }

    // Единый алгоритм передачи для каждой квартиры:
    // 1) электричество -> 2) вода -> 3) газ.
    // Порядок не зависит от того, как счётчики записаны в конфигурации квартиры.
    fun orderedJobs(a: Apartment, meters: List<Meter> = a.meters): List<Job> {
        val order = listOf(MeterType.ELECTRICITY, MeterType.WATER, MeterType.GAS)
        return order.flatMap { type ->
            meters.filter { it.type == type && it.reading.isNotBlank() }.map { makeJob(a, it) }
        }
    }

    fun startJobs(newJobs: List<Job>) {
        if (newJobs.isNotEmpty()) {
            jobs = newJobs
            activeJobIndex = 0
            webUrl = newJobs[0].providerUrl
        }
    }
    fun nextJob() { val next = activeJobIndex + 1; if (next >= jobs.size) { webUrl = null } else { activeJobIndex = next; webUrl = jobs[next].providerUrl } }

    if (settings) {
        SettingsScreen(
            apartments = apartments,
            store = store,
            onUpdateAddress = { id, value -> apartments = apartments.map { if (it.id == id) it.copy(address = value) else it }; store.commitAddress("address_$id", value) },
            onUpdateSerial = { id, value -> apartments = apartments.map { a -> a.copy(meters = a.meters.map { m -> if (m.id == id) m.copy(serial = value) else m }) }; store.put("serial_$id", value) },
            onAddApartment = {
                val newId = ((apartments.maxOfOrNull { it.id } ?: 0) + 1)
                val added = newApartment(newId)
                apartments = apartments + added
                store.saveApartmentIds(apartments.map { it.id })
            },
            onDeleteApartment = { id ->
                if (apartments.size > 1) {
                    apartments = apartments.filterNot { it.id == id }
                    store.saveApartmentIds(apartments.map { it.id })
                }
            },
            onSaved = { credentialsVersion++ },
            onBack = { settings = false }
        )
        return
    }

    if (webUrl != null && jobs.isNotEmpty()) {
        val job = jobs[activeJobIndex]
        ProviderScreen(url = webUrl!!, job = job, index = activeJobIndex + 1, total = jobs.size, store = store, onWebViewReady = { webViewRef = it }, onStatus = { updateStatus(job, it) }, onNext = { nextJob() }, onBack = { webUrl = null })
        return
    }

    Scaffold(topBar = { TopAppBar(title = { Text("Счётчики") }, actions = { TextButton({ settings = true }) { Text("Настройки") } }) }, bottomBar = {
        Button(onClick = { startJobs(apartments.flatMap { a -> orderedJobs(a) }) }, modifier = Modifier.fillMaxWidth().padding(12.dp)) { Text("Передать всё — все квартиры") }
    }) { padding ->
        Column(Modifier.fillMaxSize()) {
            Surface(Modifier.fillMaxWidth(), tonalElevation = 4.dp) {
                Text("КОНТРОЛЬНАЯ ВЕРСИЯ 1.03", modifier = Modifier.padding(16.dp), style = MaterialTheme.typography.headlineSmall)
            }
            LazyColumn(Modifier.weight(1f).padding(padding).padding(12.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            items(apartments, key = { it.id }) { apartment ->
                Card(Modifier.fillMaxWidth()) { Column(Modifier.padding(12.dp)) {
                    Text(apartment.address, style = MaterialTheme.typography.titleMedium)
                    Spacer(Modifier.height(8.dp))
                    apartment.meters.forEach { meter ->
                        OutlinedTextField(value = meter.reading, onValueChange = { v -> updateMeter(apartment.id, meter.id, reading = v, status = "Не передано") }, label = { Text("${meter.title} — показание") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text(meter.status)
                            TextButton({ startJobs(listOf(makeJob(apartment, meter))) }) { Text("Передать") }
                        }
                    }
                    Button(onClick = { startJobs(orderedJobs(apartment)) }, Modifier.fillMaxWidth()) { Text("Передать показания этой квартиры") }
                } }
            }
        }
        }
    }
    @Suppress("UNUSED_VARIABLE") val _keep = credentialsVersion
}

@Composable
private fun SettingsScreen(
    apartments: List<Apartment>,
    store: LocalStore,
    onUpdateAddress: (Int, String) -> Unit,
    onUpdateSerial: (Int, String) -> Unit,
    onAddApartment: () -> Unit,
    onDeleteApartment: (Int) -> Unit,
    onSaved: () -> Unit,
    onBack: () -> Unit
) {
    var selectedId by remember { mutableIntStateOf(apartments.firstOrNull()?.id ?: 1) }
    var address by remember { mutableStateOf("") }
    var energySurname by remember { mutableStateOf("") }
    var energyAccount by remember { mutableStateOf("") }
    var energySerial by remember { mutableStateOf("") }
    var waterLogin by remember { mutableStateOf("") }
    var waterPassword by remember { mutableStateOf("") }
    var gasLogin by remember { mutableStateOf("") }
    var gasPassword by remember { mutableStateOf("") }
    var energyUrl by remember { mutableStateOf("") }
    var waterUrl by remember { mutableStateOf("") }
    var gasUrl by remember { mutableStateOf("") }
    var showWaterPassword by remember { mutableStateOf(false) }
    var showGasPassword by remember { mutableStateOf(false) }

    fun loadApartment(id: Int) {
        val a = apartments.firstOrNull { it.id == id } ?: return
        selectedId = id
        address = store.get("address_$id", a.address)
        energySurname = store.get("energy_surname_$id")
        energyAccount = store.get("energy_account_$id")
        energySerial = store.get("energy_serial_$id")
        waterLogin = store.waterLogin(id)
        waterPassword = store.get("water_password_$id")
        gasLogin = store.get("gas_login_$id")
        gasPassword = store.get("gas_password_$id")
        energyUrl = store.providerUrl(id, MeterType.ELECTRICITY)
        waterUrl = store.providerUrl(id, MeterType.WATER)
        gasUrl = store.providerUrl(id, MeterType.GAS)
        showWaterPassword = false
        showGasPassword = false
    }

    LaunchedEffect(Unit) {
        loadApartment(selectedId)
    }

    fun saveApartment(id: Int) {
        // IMPORTANT: all reads/writes use the explicit id passed to this function.
        // Never use another apartment's UI state or a global account value.
        val a = apartments.firstOrNull { it.id == id } ?: return
        store.commitAddress("address_$id", address)
        store.put("energy_surname_$id", energySurname)
        store.put("energy_account_$id", energyAccount)
        store.put("energy_serial_$id", energySerial)
        store.put("water_login_$id", waterLogin)
        store.put("water_password_$id", waterPassword)
        store.put("gas_login_$id", gasLogin)
        store.put("gas_password_$id", gasPassword)
        store.saveProviderUrl(id, MeterType.ELECTRICITY, energyUrl.trim().ifBlank { ENERGY })
        store.saveProviderUrl(id, MeterType.WATER, waterUrl.trim().ifBlank { WATER })
        store.saveProviderUrl(id, MeterType.GAS, gasUrl.trim().ifBlank { GAS })
        onUpdateAddress(id, address)
        if (energySerial.isNotBlank()) {
            a.meters.filter { it.type == MeterType.ELECTRICITY }.forEach { onUpdateSerial(it.id, energySerial) }
        }
        onSaved()
    }

    fun switchApartment(id: Int) {
        if (id == selectedId) return
        // Save the values currently visible for the apartment being edited.
        saveApartment(selectedId)
        // Then load ONLY the newly selected apartment from persistent storage.
        loadApartment(id)
    }

    Scaffold(topBar = {
        TopAppBar(title = { Text("Настройки") }, navigationIcon = {
            TextButton(onClick = { saveApartment(selectedId); onBack() }) { Text("Назад") }
        })
    }) { padding ->
        LazyColumn(Modifier.padding(padding).padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            item {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text("Квартиры", style = MaterialTheme.typography.titleMedium)
                    Button(onClick = { saveApartment(selectedId); onAddApartment() }) { Text("+ Добавить") }
                }
            }
            item {
                Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    apartments.forEach { apartment ->
                        Button(
                            onClick = { switchApartment(apartment.id) },
                            enabled = selectedId != apartment.id,
                            contentPadding = PaddingValues(horizontal = 10.dp, vertical = 8.dp)
                        ) {
                            Column {
                                Text("Кв. ${apartment.id}")
                                Text(
                                    store.get("address_${apartment.id}", apartment.address).ifBlank { "Без адреса" },
                                    maxLines = 2,
                                    overflow = TextOverflow.Ellipsis,
                                    style = MaterialTheme.typography.labelSmall
                                )
                            }
                        }
                    }
                }
            }
            item {
                OutlinedTextField(
                    address,
                    { value -> address = value; onUpdateAddress(selectedId, value); store.commitAddress("address_$selectedId", value) },
                    label = { Text("Адрес") }, modifier = Modifier.fillMaxWidth()
                )
            }
            item {
                if (apartments.size > 1) {
                    OutlinedButton(onClick = {
                        val deletedId = selectedId
                        saveApartment(deletedId)
                        onDeleteApartment(deletedId)
                        val next = apartments.firstOrNull { it.id != deletedId }?.id
                        if (next != null) loadApartment(next)
                    }, modifier = Modifier.fillMaxWidth()) { Text("Удалить квартиру $selectedId") }
                }
            }
            key(selectedId) {
                item { Text("Севэнергосбыт", style = MaterialTheme.typography.titleMedium) }
                item { OutlinedTextField(energySurname, { energySurname = it }, label = { Text("Фамилия") }, modifier = Modifier.fillMaxWidth()) }
                item { OutlinedTextField(energyAccount, { energyAccount = it }, label = { Text("Лицевой счёт") }, modifier = Modifier.fillMaxWidth()) }
                item { OutlinedTextField(energySerial, { energySerial = it }, label = { Text("Номер счётчика") }, modifier = Modifier.fillMaxWidth()) }
                item { OutlinedTextField(energyUrl, { energyUrl = it }, label = { Text("Адрес личного кабинета") }, modifier = Modifier.fillMaxWidth()) }
                item { Text("Водоканал", style = MaterialTheme.typography.titleMedium) }
                item { OutlinedTextField(waterLogin, { waterLogin = it }, label = { Text("Лицевой счёт / логин") }, modifier = Modifier.fillMaxWidth()) }
                item { OutlinedTextField(waterPassword, { waterPassword = it }, label = { Text("Пароль") }, visualTransformation = if (showWaterPassword) androidx.compose.ui.text.input.VisualTransformation.None else PasswordVisualTransformation(), trailingIcon = { TextButton(onClick = { showWaterPassword = !showWaterPassword }) { Text(if (showWaterPassword) "Скрыть" else "Показать") } }, modifier = Modifier.fillMaxWidth()) }
                item { OutlinedTextField(waterUrl, { waterUrl = it }, label = { Text("Адрес личного кабинета") }, modifier = Modifier.fillMaxWidth()) }
                item { Text("Севгаз", style = MaterialTheme.typography.titleMedium) }
                item { OutlinedTextField(gasLogin, { gasLogin = it }, label = { Text("Логин") }, modifier = Modifier.fillMaxWidth()) }
                item { OutlinedTextField(gasPassword, { gasPassword = it }, label = { Text("Пароль") }, visualTransformation = if (showGasPassword) androidx.compose.ui.text.input.VisualTransformation.None else PasswordVisualTransformation(), trailingIcon = { TextButton(onClick = { showGasPassword = !showGasPassword }) { Text(if (showGasPassword) "Скрыть" else "Показать") } }, modifier = Modifier.fillMaxWidth()) }
                item { OutlinedTextField(gasUrl, { gasUrl = it }, label = { Text("Адрес личного кабинета") }, modifier = Modifier.fillMaxWidth()) }
            }
            item { Text("Пароли сохраняются только на этом телефоне.") }
            item { Button(onClick = { saveApartment(selectedId); onBack() }, modifier = Modifier.fillMaxWidth()) { Text("Сохранить") } }
        }
    }
}

@Composable
private fun ProviderScreen(url: String, job: Job, index: Int, total: Int, store: LocalStore, onWebViewReady: (WebView) -> Unit, onStatus: (String) -> Unit, onNext: () -> Unit, onBack: () -> Unit) {
    var message by remember(url, job.meterId) { mutableStateOf("${job.address}\n${job.title}: ${job.reading}\nПередача $index из $total") }
    var webViewRef by remember { mutableStateOf<WebView?>(null) }
    var busy by remember { mutableStateOf(false) }
    var gasInitialPrepared by remember(url, job.meterId) { mutableStateOf(false) }
    var gasLoginFormPolls by remember(url, job.meterId) { mutableStateOf(0) }
    var confirmed by remember { mutableStateOf(false) }

    fun checkConfirmation(w: WebView, attempt: Int = 0) {
        if (confirmed) return
        w.evaluateJavascript("""
            (function(){
              const t=(document.body&&document.body.innerText||'').toLowerCase();
              const ok=/(данн(ые|ых).*(принят|передан|сохран)|показани.*(принят|передан|сохран)|успешн.*(перед|сохран)|спасибо|операция выполнен|передача выполнен|данные отправлен|успешно)/i.test(t);
              const fail=/(ошибк|не удалось|не принят|не передан|неверн|введите капч|captcha)/i.test(t);
              return JSON.stringify({ok:ok,fail:fail});
            })()
        """.trimIndent()) { raw ->
            val r = raw ?: ""
            if (r.contains("\\\"ok\\\":true")) {
                confirmed = true
                busy = false
                message = "✓ ${job.title}: ${job.reading} — показание подтверждено"
                onStatus("Передано ✓")
                w.postDelayed({ onNext() }, 1200)
            } else if (attempt < 10 && !r.contains("\\\"fail\\\":true")) {
                w.postDelayed({ checkConfirmation(w, attempt + 1) }, 900)
            } else {
                busy = false
                message = "Команда отправлена. Подтверждение сайта не найдено — проверь страницу."
                onStatus("Проверить результат")
            }
        }
    }

    fun nativeGasTap(w: WebView, cssX: Float, cssY: Float) {
        // getBoundingClientRect() is in CSS viewport pixels. WebView dispatchTouchEvent()
        // expects view-local physical pixels, so convert using the current WebView scale.
        val scale = try { w.scale } catch (_: Exception) { 1f }
        val scrollX = try { w.scrollX } catch (_: Exception) { 0 }
        val scrollY = try { w.scrollY } catch (_: Exception) { 0 }
        val x = ((cssX + scrollX) * scale).coerceIn(1f, (w.width - 1).coerceAtLeast(1).toFloat())
        val y = ((cssY + scrollY) * scale).coerceIn(1f, (w.height - 1).coerceAtLeast(1).toFloat())
        val downTime = SystemClock.uptimeMillis()
        val down = MotionEvent.obtain(downTime, downTime, MotionEvent.ACTION_DOWN, x, y, 0)
        val move = MotionEvent.obtain(downTime, downTime + 30, MotionEvent.ACTION_MOVE, x, y, 0)
        val up = MotionEvent.obtain(downTime, downTime + 80, MotionEvent.ACTION_UP, x, y, 0)
        try {
            w.dispatchTouchEvent(down)
            w.postDelayed({
                w.dispatchTouchEvent(move)
                move.recycle()
                w.dispatchTouchEvent(up)
                up.recycle()
            }, 30)
        } finally {
            down.recycle()
        }
    }

    fun startGasAutoLogin(w: WebView, attempt: Int = 0) {
        if (confirmed || attempt >= 120) {
            if (!confirmed) {
                busy = false
                message = "Газ: диагностика формы не завершена. Проверьте страницу."
                onStatus("Диагностика не завершена")
            }
            return
        }
        w.evaluateJavascript(autoGasLoginScript(job)) { raw ->
            if (confirmed) return@evaluateJavascript
            val r = raw ?: ""
            if (r.contains("login_ready") || r.contains("login_filled")) {
                busy = false
                onStatus("Форма входа найдена")
                w.evaluateJavascript("""
                    (function(){
                      const vis=e=>!!(e&&(e.offsetWidth||e.offsetHeight||e.getClientRects().length));
                      const pw=[...document.querySelectorAll('input[type=password]')].find(vis);
                      const form=pw && (pw.form||pw.closest('form'));
                      if(!form) return JSON.stringify({ok:false,reason:'NO_FORM',url:location.href});
                      const txt=e=>((e.innerText||e.value||e.textContent||e.getAttribute('aria-label')||e.getAttribute('title')||'')+'').trim();
                      const submit=[...form.querySelectorAll('button,input[type=submit],input[type=button],a,[role=button]')].filter(vis)
                        .find(e=>/(войти в систему|войти|вход|login|sign in|авториз)/i.test(txt(e)))
                        || [...form.querySelectorAll('button,input[type=submit],input[type=button]')].find(vis);
                      const hidden=[...form.querySelectorAll('input[type=hidden]')].map(e=>({name:e.name||'',id:e.id||'',hasValue:!!e.value}));
                      const controls=[...form.querySelectorAll('input,button,select,textarea')].filter(vis).map(e=>({tag:e.tagName.toLowerCase(),type:e.type||'',name:e.name||'',id:e.id||'',valueLength:(e.value||'').length}));
                      return JSON.stringify({ok:true,url:location.href,action:form.action||'',method:(form.method||'get').toUpperCase(),formId:form.id||'',formName:form.name||'',submit:submit?{tag:submit.tagName.toLowerCase(),type:submit.type||'',name:submit.name||'',id:submit.id||'',value:submit.value||'',text:txt(submit)}:null,hidden:hidden,controls:controls});
                    })()
                """) { diagRaw ->
                    // Diagnostic details are intentionally hidden in the normal UI.
                    // Keep the form available for a manual click.
                    message = "Газ: данные входа заполнены. Нажмите «Войти в систему»."
                    onStatus("Готово к входу")
                }
                return@evaluateJavascript
            }
            w.postDelayed({ startGasAutoLogin(w, attempt + 1) }, 120)
        }
    }

    fun runFillAndSend() {
        val w = webViewRef ?: run { message = "Страница ещё загружается."; return }
        if (busy) return
        // Water: fill credentials and click the site's normal login button.
        // There is no CAPTCHA handling here; the site login is used as-is.
        // Gas remains in the manual-click test flow for now.
        if (job.type == MeterType.WATER) {
            busy = true
            message = "Вода: заполняем логин и пароль и выполняем вход…"
            onStatus("Вход…")
            w.evaluateJavascript(autoFillScript(job)) { result ->
                val r = result ?: ""
                val ok = r.contains("\"ok\":true") || r.contains("login_filled")
                val phase = Regex("\"phase\":\"([^\"]+)\"").find(r)?.groupValues?.getOrNull(1) ?: ""
                if (ok || phase == "login") {
                    message = "Вода: данные заполнены, выполняем вход…"
                    onStatus("Вход…")
                    w.postDelayed({
                    // After login, distinguish a real password error from a still-loading page.
                    w.evaluateJavascript("""(function(){
                        const t=((document.body&&document.body.innerText)||'').toLowerCase();
                        if(/неверн\s*(?:ый|ая|ое)?\s*парол|неправильн\s*(?:ый|ая|ое)?\s*парол|ошибк\w*.*парол/i.test(t)) return 'WATER_BAD_PASSWORD';
                        if(/личный кабинет|войти в систему|регистрационные данные|введите.*парол|логин|пароль/i.test(t) && document.querySelector('input[type=password]')) return 'WATER_LOGIN_STILL_VISIBLE';
                        return 'WATER_LOGIN_PASSED';
                    })()""") { stateResult ->
                        busy = false
                        val state = stateResult ?: ""
                        when {
                            state.contains("WATER_BAD_PASSWORD") -> {
                                message = "Вода: сайт сообщил «Неверный пароль». Проверь пароль Водоканала в настройках."
                                onStatus("Неверный пароль")
                            }
                            state.contains("WATER_LOGIN_STILL_VISIBLE") -> {
                                message = "Вода: вход не выполнен. Проверь логин и пароль."
                                onStatus("Вход не выполнен")
                            }
                            else -> {
                                if (!confirmed) runFillAndSend()
                            }
                        }
                    }
                }, 4200)
                } else {
                    busy = false
                    message = "Вода: не удалось найти поле логина или пароля."
                    onStatus("Требуется ввод")
                }
            }
            return
        }
        if (job.type == MeterType.GAS) {
            busy = true
            message = "Газ: автоматически входим в личный кабинет…"
            onStatus("Автоматический вход…")
            startGasAutoLogin(w)
            fun openGasFormAfterLogin(attempt: Int = 0) {
                if (confirmed) return
                if (attempt >= 30) {
                    busy = false
                    message = "Газ: кабинет открыт. Проверьте раздел «Счётчики»."
                    onStatus("Кабинет открыт")
                    return
                }
                w.evaluateJavascript(openGasReadingFormScript()) { rr ->
                    if (confirmed) return@evaluateJavascript
                    when {
                        rr?.contains("gas_reading_form") == true -> {
                            message = "Газ: форма показаний открыта. Заполняем значение…"
                            onStatus("Заполнение показания")
                            w.postDelayed({
                                if (confirmed) return@postDelayed
                                w.evaluateJavascript(fillGasReadingScript(job.reading)) { fr ->
                                    if (confirmed) return@evaluateJavascript
                                    busy = false
                                    if (fr?.contains("gas_reading_filled") == true && fr.contains("\"ok\":true")) {
                                        message = "Газ: показание ${job.reading} заполнено. Проверьте значение и нажмите OK вручную."
                                        onStatus("Показание заполнено")
                                    } else {
                                        message = "Газ: форма открыта, но поле показания не найдено. Проверьте его вручную."
                                        onStatus("Требуется проверка")
                                    }
                                }
                            }, 150)
                        }
                        rr?.contains("gas_counters") == true -> {
                            message = "Газ: открываем раздел «Счётчики»…"
                            w.postDelayed({ openGasFormAfterLogin(attempt + 1) }, 300)
                        }
                        else -> w.postDelayed({ openGasFormAfterLogin(attempt + 1) }, 200)
                    }
                }
            }

            fun waitForGasCabinet(attempt: Int) {
                if (confirmed) return
                if (attempt >= 40) {
                    busy = false
                    message = "Газ: автоматический вход не завершён. Проверьте страницу — кнопку «Войти» можно нажать вручную."
                    onStatus("Проверьте вход")
                    return
                }
                w.postDelayed({
                    if (confirmed) return@postDelayed
                    w.evaluateJavascript("""(function(){
                        const visible=e=>!!(e&&(e.offsetWidth||e.offsetHeight||e.getClientRects().length));
                        const body=((document.body&&document.body.innerText)||'').toLowerCase();
                        const pwVisible=[...document.querySelectorAll('input[type="password"]')].some(visible);
                        const loginWords=/регистрационные данные|войти в систему|забыли пароль/i.test(body);
                        const cabinetWords=/лицев\s*сч[ёе]т|абонент|сч[ёе]тчики|характеристики|история платежей/i.test(body);
                        if(cabinetWords && !pwVisible) return 'CABINET_PAGE';
                        if(pwVisible || loginWords) return 'LOGIN_PAGE';
                        return 'WAIT';
                    })()""") { state ->
                        when {
                            state.contains("CABINET_PAGE") -> {
                                try {
                                    val cookies = android.webkit.CookieManager.getInstance().getCookie(GAS) ?: ""
                                    if (cookies.isNotBlank()) store.putGasCookies(job.apartmentId, cookies)
                                } catch (_: Exception) {}
                                message = "Газ: вход выполнен. Открываем «Счётчики»…"
                                onStatus("Открываем счётчики")
                                openGasFormAfterLogin()
                            }
                            else -> waitForGasCabinet(attempt + 1)
                        }
                    }
                }, 250)
            }
            waitForGasCabinet(0)
            return
        }
        busy = true
        onStatus("Заполняется…")
        message = "1/3 Заполняем данные…"
        w.evaluateJavascript(autoFillScript(job)) { result ->
            val r = result ?: ""
            val ok = r.contains("\\\"ok\\\":true")
            val phase = Regex("\\\"phase\\\":\\\"([^\\\"]+)\\\"").find(r)?.groupValues?.getOrNull(1) ?: "meter"
            val filled = Regex("\\\"filledCount\\\":(\\d+)").find(r)?.groupValues?.getOrNull(1) ?: "0"
            val loginUsed = Regex("\"loginUsed\":\"([^\"]*)\"").find(r)?.groupValues?.getOrNull(1) ?: ""
            if (phase == "navigate" || phase == "menu" || phase == "gas_lk" || phase == "gas_counters" || phase == "gas_readings" || phase == "login_wait") {
                busy = false
                message = when (phase) {
                    "menu" -> "Открываем меню Севэнергосбыта…"
                    "gas_counters" -> "Открываем раздел «Счётчики»…"
                    "gas_readings" -> "Открываем форму показаний газа…"
                    else -> "Открываем форму передачи показаний…"
                }
                onStatus("Открываем форму…")
                w.postDelayed({ if (!confirmed && !busy) runFillAndSend() }, 1200)
                return@evaluateJavascript
            }
            if (!ok) {
                busy = false
                message = "Не удалось автоматически заполнить нужные поля."
                onStatus("Требуется ввод")
                return@evaluateJavascript
            }
            if (phase == "login") {
                busy = false
                message = "2/3 Вход: $loginUsed…"
                onStatus("Вход…")
                w.postDelayed({ if (!confirmed && !busy) runFillAndSend() }, 3800)
                return@evaluateJavascript
            }
            message = "2/3 Показание ${job.reading} заполнено."
            onStatus("Данные заполнены")
            message = "3/3 Передаём показание…"
            onStatus("Передаётся…")
            w.postDelayed({
                    w.evaluateJavascript(autoSubmitScript(job.type)) { sr ->
                        val x = sr ?: ""
                        if (x.contains("\\\"ok\\\":true")) {
                            message = "3/3 Команда отправлена. Ждём подтверждение сайта…"
                            checkConfirmation(w)
                        } else {
                            busy = false
                            message = "Не удалось найти кнопку передачи. Откройте форму и попробуйте ещё раз."
                            onStatus("Требуется ввод")
                        }
                    }
                }, 900)
        }
    }

    fun sendNow() {
        val w = webViewRef ?: return
        if (busy) return
        busy = true
        message = "3/3 Передаём показание ${job.reading}…"
        onStatus("Передаётся…")
        w.evaluateJavascript(autoSubmitScript(job.type)) { r ->
            val x = r ?: ""
            if (x.contains("\\\"ok\\\":true")) {
                message = "Команда отправлена. Ждём подтверждение сайта…"
                checkConfirmation(w)
            } else {
                busy = false
                message = "Кнопку передачи не нашли."
                onStatus("Требуется ввод")
            }
        }
    }

    Column(Modifier.fillMaxSize()) {
        Row(Modifier.fillMaxWidth().padding(8.dp), horizontalArrangement = Arrangement.SpaceBetween) {
            Text("Передача $index/$total", style = MaterialTheme.typography.titleMedium)
            TextButton(onClick = onBack, enabled = !busy) { Text("Назад") }
        }
        Text(message, Modifier.padding(horizontal = 12.dp))
        Row(Modifier.padding(8.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Button(onClick = { runFillAndSend() }, enabled = !busy && !confirmed) { Text("Передать") }
            Button(onClick = onNext, enabled = !busy) { Text(if (index < total) "Пропустить" else "Завершить") }
        }
        AndroidView(factory = { context ->
            WebView(context).apply {
                webViewRef = this
                onWebViewReady(this)
                settings.javaScriptEnabled = true
                settings.domStorageEnabled = true
                settings.databaseEnabled = true
                settings.cacheMode = android.webkit.WebSettings.LOAD_DEFAULT
                settings.loadsImagesAutomatically = true
                settings.javaScriptCanOpenWindowsAutomatically = true
                settings.setSupportMultipleWindows(false)
                settings.mixedContentMode = android.webkit.WebSettings.MIXED_CONTENT_COMPATIBILITY_MODE
                android.webkit.CookieManager.getInstance().setAcceptCookie(true)
                android.webkit.CookieManager.getInstance().setAcceptThirdPartyCookies(this, true)
                // Each job starts a fresh cabinet session. For GAS we deliberately
                // keep the WebView cache for speed, but never keep cookies/session
                // from the previous apartment. Form data is also cleared so WebView
                // autofill cannot reinsert an old apartment's credentials.
                if (job.type != MeterType.GAS) {
                    android.webkit.CookieManager.getInstance().removeAllCookies(null)
                    android.webkit.CookieManager.getInstance().flush()
                    clearHistory()
                    clearCache(true)
                    clearFormData()
                    clearSslPreferences()
                } else {
                    clearFormData()
                }
                settings.useWideViewPort = true
                settings.loadWithOverviewMode = true
                // Разрешаем увеличение/уменьшение страницы жестом двумя пальцами.
                settings.setSupportZoom(true)
                settings.builtInZoomControls = true
                settings.displayZoomControls = false
                settings.textZoom = 100
                // Keep the standard Android WebView user-agent. The Sevgaz cabinet can reject modified WebView user-agents.
                webChromeClient = object : WebChromeClient() {
                    override fun onReceivedTitle(view: WebView, title: String) {
                        super.onReceivedTitle(view, title)
                        if (title.isNotBlank()) message = "Страница: $title"
                    }
                }
                webViewClient = object : WebViewClient() {
                    override fun shouldOverrideUrlLoading(view: WebView, request: android.webkit.WebResourceRequest): Boolean {
                        // Let WebView handle normal form POST/redirect navigation itself.
                        // Intercepting and re-loading the URL can turn a POST login into a GET.
                        return false
                    }
                    override fun shouldOverrideUrlLoading(view: WebView, url: String): Boolean {
                        return false
                    }
                    override fun onPageStarted(view: WebView, url: String, favicon: android.graphics.Bitmap?) {
                        onWebViewReady(view)
                        message = "Загрузка: ${url.take(80)}…"
                    }
                    override fun onReceivedError(view: WebView, request: android.webkit.WebResourceRequest, error: android.webkit.WebResourceError) {
                        if (request.isForMainFrame) message = "Ошибка загрузки: ${error.description}"
                    }
                    override fun onPageFinished(view: WebView, loadedUrl: String) {
                        onWebViewReady(view)
                        if (!confirmed) {
                            if (job.type == MeterType.GAS) {
                                // Газ: используем тот же проверенный пошаговый сценарий, который
                                // применялся для квартиры 2: дождаться JSF-формы, заполнить
                                // логин/пароль, нажать штатную кнопку входа, дождаться кабинета,
                                // открыть «Счётчики» и форму показаний.
                                if (loadedUrl.contains("/irb/view/abonentInfo.xhtml", ignoreCase = true)) {
                                    // The server can return abonentInfo.xhtml while still showing
                                    // the login form (for example when the first submit did not
                                    // establish the session). Do not report success from URL alone.
                                    view.evaluateJavascript("""(function(){
                                         const visible=e=>!!(e&&(e.offsetWidth||e.offsetHeight||e.getClientRects().length));
                                         const body=((document.body&&document.body.innerText)||'').toLowerCase();
                                         const pwVisible=[...document.querySelectorAll('input[type="password"]')].some(visible);
                                         const loginWords=/регистрационные данные|войти в систему|забыли пароль/i.test(body);
                                         const cabinetWords=/лицевой\s*сч[её]т|абонент|сч[ёе]тчики|характеристики|история платежей/i.test(body);
                                         const cabinet=cabinetWords && !pwVisible;
                                         return cabinet ? 'CABINET_PAGE' : ((pwVisible||loginWords) ? 'LOGIN_PAGE' : 'UNKNOWN_PAGE');
                                    })()""") { stateResult ->
                                        val state = stateResult ?: ""
                                        when {
                                            state.contains("CABINET_PAGE") -> {
                                                busy = true
                                                message = "Газ: вход выполнен. Открываем «Счётчики»…"
                                                onStatus("Открываем счётчики")
                                                fun openGasForm(attempt: Int = 0) {
                                                    if (confirmed) return
                                                    if (attempt >= 30) {
                                                        busy = false
                                                        message = "Газ: кабинет открыт. Откройте «Счётчики» вручную."
                                                        onStatus("Открыта страница")
                                                        return
                                                    }
                                                    view.evaluateJavascript(openGasReadingFormScript()) { rr ->
                                                        if (confirmed) return@evaluateJavascript
                                                        when {
                                                            rr?.contains("gas_reading_form") == true -> {
                                                                busy = true
                                                                message = "Газ: форма показаний открыта. Заполняем значение…"
                                                                onStatus("Заполнение показания")
                                                                view.postDelayed({
                                                                    if (confirmed) return@postDelayed
                                                                    view.evaluateJavascript(fillGasReadingScript(job.reading)) { fr ->
                                                                        if (confirmed) return@evaluateJavascript
                                                                        if (fr?.contains("gas_reading_filled") == true && fr.contains("\"ok\":true")) {
                                                                            busy = false
                                                                            message = "Газ: показание ${job.reading} заполнено. Проверьте значение и нажмите OK вручную."
                                                                            onStatus("Показание заполнено")
                                                                        } else {
                                                                            busy = false
                                                                            message = "Газ: форма открыта, но поле показания не найдено. Проверьте его вручную."
                                                                            onStatus("Требуется проверка")
                                                                        }
                                                                    }
                                                                }, 150)
                                                            }
                                                            rr?.contains("gas_counters") == true -> {
                                                                message = "Газ: открываем раздел «Счётчики»…"
                                                                view.postDelayed({ openGasForm(attempt + 1) }, 350)
                                                            }
                                                            else -> view.postDelayed({ openGasForm(attempt + 1) }, 250)
                                                        }
                                                    }
                                                }
                                                view.postDelayed({ openGasForm() }, 200)
                                            }
                                            state.contains("LOGIN_PAGE") -> {
                                                // Если JSF вернул нас на форму входа, снова запускаем тот же
                                                // polling-алгоритм. Важно не оставлять заполненную форму без клика.
                                                message = "Газ: автоматически выполняем вход…"
                                                onStatus("Автоматический вход…")
                                                busy = false
                                                startGasAutoLogin(view)
                                                fun waitForGasLoginResult(attempt: Int) {
                                                    if (confirmed) return
                                                    if (attempt >= 50) {
                                                        busy = false
                                                        message = "Газ: кабинет не обнаружен. Если кабинет уже открыт, нажми «Передать» ещё раз."
                                                        onStatus("Вход не подтверждён")
                                                        return
                                                    }
                                                    view.postDelayed({
                                                        if (confirmed) return@postDelayed
                                                        view.evaluateJavascript("""(function(){
                                                             const visible=e=>!!(e&&(e.offsetWidth||e.offsetHeight||e.getClientRects().length));
                                                             const body=((document.body&&document.body.innerText)||'').toLowerCase();
                                                             const pwVisible=[...document.querySelectorAll('input[type="password"]')].some(visible);
                                                             const loginWords=/регистрационные данные|войти в систему|забыли пароль/i.test(body);
                                                             const cabinetWords=/лицевой\s*сч[ёе]т|абонент|сч[ёе]тчики|характеристики|история платежей/i.test(body);
                                                             const cabinet=cabinetWords && !pwVisible;
                                                             if (cabinet) return 'CABINET_PAGE';
                                                             if (pwVisible || loginWords) return 'LOGIN_PAGE';
                                                             return 'UNKNOWN_PAGE';
                                                        })()""") { rr ->
                                                            if (!confirmed) {
                                                            when {
                                                                rr.contains("CABINET_PAGE") -> {
                                                                    busy = false
                                                                    try {
                                                                        val cookies = android.webkit.CookieManager.getInstance().getCookie(GAS) ?: ""
                                                                        if (cookies.isNotBlank()) store.putGasCookies(job.apartmentId, cookies)
                                                                    } catch (_: Exception) {}
                                                                    message = "Газ: вход выполнен. Открыт личный кабинет."
                                                                    onStatus("Вход выполнен")
                                                                }
                                                                attempt >= 30 -> {
                                                                    busy = false
                                                                    message = "Газ: не дождались ответа сервера. Если кабинет уже открыт, можно продолжить."
                                                                    onStatus("Кабинет проверяется")
                                                                }
                                                                else -> waitForGasLoginResult(attempt + 1)
                                                            }
                                                            }
                                                        }
                                                    }, 500)
                                                }
                                                waitForGasLoginResult(0)
                                            }
                                            else -> {
                                                busy = false
                                                message = "Газ: проверяем результат входа…"
                                                onStatus("Проверка входа")
                                            }
                                        }
                                    }
                                } else if (!gasInitialPrepared) {
                                    gasInitialPrepared = true
                                    message = "Газ: готовим поля входа…"
                                    onStatus("Подготовка входа")
                                    webViewRef = view
                                    // The script itself polls for the JSF controls every 100 ms.
                                    // Start immediately after page load.
                                    startGasAutoLogin(view)
                                }
                            } else {
                                message = "Страница загружена. Подготовка передачи…"
                                view.postDelayed({ webViewRef = view; runFillAndSend() }, 1800)
                                view.postDelayed({ if (!confirmed) { busy = false; webViewRef = view; runFillAndSend() } }, 3000)
                                view.postDelayed({ if (!confirmed) { busy = false; webViewRef = view; runFillAndSend() } }, 6000)
                            }
                        }
                    }
                }
                if (job.type == MeterType.GAS) {
                    // Gas gets an isolated cookie jar per apartment. We still keep the
                    // WebView cache, but restore only this apartment's saved session.
                    // That makes repeat opens fast without leaking apartment A's session
                    // into apartment B.
                    val savedCookies = store.gasCookies(job.apartmentId)
                    val cm = android.webkit.CookieManager.getInstance()
                    cm.removeAllCookies {
                        val parts = savedCookies.split(';').map { it.trim() }.filter { it.contains('=') }
                        if (parts.isEmpty()) {
                            cm.flush()
                            post { loadUrl(url) }
                        } else {
                            var left = parts.size
                            parts.forEach { cookie ->
                                cm.setCookie(GAS, cookie) {
                                    left--
                                    if (left == 0) {
                                        cm.flush()
                                        post { loadUrl(url) }
                                    }
                                }
                            }
                        }
                    }
                } else {
                    loadUrl(url)
                }
            }
            }, modifier = Modifier.fillMaxSize())
    }
}

