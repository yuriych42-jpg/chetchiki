@file:OptIn(ExperimentalMaterial3Api::class, ExperimentalFoundationApi::class)
package ru.chetchiki.app

import android.annotation.SuppressLint
import android.app.Activity
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Typeface
import android.net.Uri
import android.os.Bundle
import android.os.SystemClock
import java.io.OutputStream
import java.io.BufferedReader
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.roundToInt
import android.view.MotionEvent
import android.webkit.WebView
import android.webkit.WebViewClient
import android.webkit.WebChromeClient
import org.json.JSONObject
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.compose.setContent
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.border
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.viewinterop.AndroidView
import androidx.compose.ui.platform.LocalContext

enum class MeterType { ELECTRICITY, WATER, GAS }

data class Meter(
    val id: Int,
    val type: MeterType,
    val title: String,
    val serial: String = "",
    val reading: String = "",
    val status: String = "Не передано"
)

data class Apartment(val id: Int, val address: String, val meters: List<Meter>)

data class Credentials(
    val energySurname: String = "",
    val energyAccount: String = "",
    val energySerial: String = "",
    val waterLogin: String = "",
    val waterPassword: String = "",
    val gasLogin: String = "",
    val gasPassword: String = ""
)

data class Job(
    val apartmentId: Int,
    val address: String,
    val meterId: Int,
    val type: MeterType,
    val title: String,
    val reading: String,
    val serial: String = "",
    val credentials: Credentials = Credentials(),
    val providerUrl: String = ""
)

private const val ENERGY = "https://sevenergosbyt.ru/flk/index.php"
private const val WATER = "https://sevvodokanal.org.ru/app/webroot/account.php"
private const val GAS = "http://lk.sevgas.ru:8080/irb/login.xhtml"
private const val APP_VERSION = BuildConfig.VERSION_NAME

private fun defaultApartments() = listOf(
    Apartment(1, "Адрес квартиры 1", listOf(
        Meter(1, MeterType.ELECTRICITY, "Электричество №1"), Meter(2, MeterType.WATER, "Вода №1"), Meter(3, MeterType.WATER, "Вода №2"), Meter(4, MeterType.GAS, "Газ")
    )),
    Apartment(2, "Адрес квартиры 2", listOf(
        Meter(5, MeterType.ELECTRICITY, "Электричество №1"), Meter(6, MeterType.WATER, "Вода"), Meter(7, MeterType.GAS, "Газ")
    )),
    Apartment(3, "Адрес квартиры 3", listOf(
        Meter(8, MeterType.ELECTRICITY, "Электричество №1"), Meter(9, MeterType.WATER, "Вода"), Meter(10, MeterType.GAS, "Газ")
    )),
    Apartment(4, "Адрес квартиры 4", listOf(
        Meter(11, MeterType.ELECTRICITY, "Электричество №1"), Meter(12, MeterType.WATER, "Вода №1"), Meter(13, MeterType.WATER, "Вода №2"), Meter(14, MeterType.GAS, "Газ")
    ))
)

private fun newApartment(id: Int) = Apartment(id, "Адрес квартиры $id", listOf(
    Meter(id * 100 + 1, MeterType.ELECTRICITY, "Электричество №1"),
    Meter(id * 100 + 2, MeterType.WATER, "Вода"),
    Meter(id * 100 + 3, MeterType.GAS, "Газ")
))

// ГАЗ КВАРТИР 1–4: автоматический вход и подготовка показания — ВЕРСИЯ 0.92
class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { MeterApp(applicationContext) }
    }
}

private class LocalStore(context: Context) {
    private val p = context.getSharedPreferences("meter_store", Context.MODE_PRIVATE)
    fun get(k: String, d: String = "") = p.getString(k, d) ?: d
    fun put(k: String, v: String) { p.edit().putString(k, v).commit() }
    fun gasCookies(id: Int): String = get("gas_cookies_$id")
    fun putGasCookies(id: Int, v: String) { p.edit().putString("gas_cookies_$id", v).apply() }
    fun commitAddress(k: String, v: String) { p.edit().putString(k, v).commit() }
    fun apartmentIds(): List<Int> {
        val saved = get("apartment_ids")
        if (saved.isBlank()) {
            val ids = defaultApartments().map { it.id }
            p.edit().putString("apartment_ids", ids.joinToString(",")).commit()
            return ids
        }
        return saved.split(",").mapNotNull { it.trim().toIntOrNull() }.distinct().sorted()
    }
    fun saveApartmentIds(ids: List<Int>) { p.edit().putString("apartment_ids", ids.distinct().sorted().joinToString(",")).commit() }
    fun providerUrl(id: Int, type: MeterType): String {
        val fallback = when (type) {
            MeterType.ELECTRICITY -> ENERGY
            MeterType.WATER -> WATER
            MeterType.GAS -> GAS
        }
        val saved = get("provider_url_${type.name}_$id", fallback)
        return if (type == MeterType.GAS) {
            when {
                saved.contains("lk.gup-sevgaz.ru", ignoreCase = true) -> saved.replace("https://lk.gup-sevgaz.ru:8081", "http://lk.sevgas.ru:8080", ignoreCase = true).replace("http://lk.gup-sevgaz.ru:8080", "http://lk.sevgas.ru:8080", ignoreCase = true)
                saved.contains(":8081", ignoreCase = true) -> saved.replace(":8081", ":8080").replace("https://", "http://")
                else -> saved
            }
        } else saved
    }
    fun saveProviderUrl(id: Int, type: MeterType, value: String) { put("provider_url_${type.name}_$id", value) }
    fun meterIds(id: Int, fallback: List<Meter>): List<Int> {
        val saved = get("meter_ids_$id")
        if (saved.isBlank()) {
            val ids = fallback.map { it.id }
            put("meter_ids_$id", ids.joinToString(","))
            return ids
        }
        return saved.split(",").mapNotNull { it.trim().toIntOrNull() }.distinct()
    }
    fun saveMeterIds(id: Int, ids: List<Int>) { put("meter_ids_$id", ids.distinct().joinToString(",")) }
    fun meterType(id: Int, meterId: Int, fallback: MeterType): MeterType = try { MeterType.valueOf(get("meter_type_${id}_$meterId", fallback.name)) } catch (_: Exception) { fallback }
    fun meterTitle(id: Int, meterId: Int, fallback: String): String = get("meter_title_${id}_$meterId", fallback)
    fun saveMeter(id: Int, meter: Meter) {
        put("meter_type_${id}_${meter.id}", meter.type.name)
        put("meter_title_${id}_${meter.id}", meter.title)
    }
    fun previousReading(meterId: Int): String = get("previous_reading_$meterId")
    fun savePreviousReading(meterId: Int, value: String) { if (value.isNotBlank()) put("previous_reading_$meterId", value) }
    fun clearReading(meterId: Int) {
        val current = get("reading_$meterId")
        if (current.isNotBlank()) savePreviousReading(meterId, current)
        p.edit().remove("reading_$meterId").putString("status_$meterId", "Не передано").apply()
    }
    fun deleteMeterData(meterId: Int) { p.edit().remove("reading_$meterId").remove("previous_reading_$meterId").remove("serial_$meterId").remove("status_$meterId").apply() }
    fun waterLogin(id: Int): String = get("water_login_$id")
    fun credentials(id: Int) = Credentials(
        get("energy_surname_$id"), get("energy_account_$id"), get("energy_serial_$id"),
        waterLogin(id), get("water_password_$id"), get("gas_login_$id"), get("gas_password_$id")
    )

    fun exportJson(): String {
        val root = JSONObject()
        root.put("format", "chetchiki-settings")
        root.put("formatVersion", 1)
        val values = JSONObject()
        p.all.forEach { (key, value) ->
            when (value) {
                is String -> values.put(key, value)
                is Boolean -> values.put(key, value)
                is Int -> values.put(key, value)
                is Long -> values.put(key, value)
                is Float -> values.put(key, value.toDouble())
            }
        }
        root.put("values", values)
        return root.toString(2)
    }

    fun importJson(json: String) {
        val root = JSONObject(json)
        require(root.optString("format") == "chetchiki-settings") { "Неверный файл настроек" }
        val values = root.optJSONObject("values") ?: error("В файле нет настроек")
        val editor = p.edit().clear()
        val keys = values.keys()
        while (keys.hasNext()) {
            val key = keys.next()
            when (val value = values.get(key)) {
                is String -> editor.putString(key, value)
                is Boolean -> editor.putBoolean(key, value)
                is Int -> editor.putInt(key, value)
                is Long -> editor.putLong(key, value)
                is Double -> editor.putFloat(key, value.toFloat())
            }
        }
        check(editor.commit()) { "Не удалось сохранить настройки" }
    }
}


private data class AppColors(
    val background: String = "#FFF7FB",
    val surface: String = "#FFFFFF",
    val primary: String = "#C2185B",
    val onPrimary: String = "#FFFFFF",
    val secondary: String = "#8E4A68",
    val onSecondary: String = "#FFFFFF",
    val text: String = "#2A2024",
    val mutedText: String = "#756A70",
    val outline: String = "#B9AAB2",
    val fieldBackground: String = "#FFF0F6",
    val fieldText: String = "#2A2024",
    val headerBackground: String = "#F8BBD0",
    val headerText: String = "#5A1735",
    val progress: String = "#C2185B",
    val cardBackground: String = "#FFFFFF"
) {
    fun color(hex: String, fallback: Color): Color = runCatching { Color(android.graphics.Color.parseColor(hex)) }.getOrDefault(fallback)
    fun scheme() = lightColorScheme(
        primary = color(primary, Color(0xFFC2185B)),
        onPrimary = color(onPrimary, Color.White),
        secondary = color(secondary, Color(0xFF8E4A68)),
        onSecondary = color(onSecondary, Color.White),
        background = color(background, Color(0xFFFFF7FB)),
        onBackground = color(text, Color(0xFF2A2024)),
        surface = color(surface, Color.White),
        onSurface = color(text, Color(0xFF2A2024)),
        surfaceVariant = color(fieldBackground, Color(0xFFFFF0F6)),
        onSurfaceVariant = color(mutedText, Color(0xFF756A70)),
        outline = color(outline, Color(0xFFB9AAB2)),
        outlineVariant = color(outline, Color(0xFFB9AAB2))
    )
    companion object {
        fun from(store: LocalStore) = AppColors(
            background = store.get("color_background", "#FFF7FB"),
            surface = store.get("color_surface", "#FFFFFF"),
            primary = store.get("color_primary", "#C2185B"),
            onPrimary = store.get("color_on_primary", "#FFFFFF"),
            secondary = store.get("color_secondary", "#8E4A68"),
            onSecondary = store.get("color_on_secondary", "#FFFFFF"),
            text = store.get("color_text", "#2A2024"),
            mutedText = store.get("color_muted_text", "#756A70"),
            outline = store.get("color_outline", "#B9AAB2"),
            fieldBackground = store.get("color_field_background", "#FFF0F6"),
            fieldText = store.get("color_field_text", "#2A2024"),
            headerBackground = store.get("color_header_background", "#F8BBD0"),
            headerText = store.get("color_header_text", "#5A1735"),
            progress = store.get("color_progress", "#C2185B"),
            cardBackground = store.get("color_card_background", "#FFFFFF")
        )
    }
}

private val LocalAppColors = staticCompositionLocalOf { AppColors() }

private fun AppColors.saveTo(store: LocalStore) {
    store.put("color_background", background)
    store.put("color_surface", surface)
    store.put("color_primary", primary)
    store.put("color_on_primary", onPrimary)
    store.put("color_secondary", secondary)
    store.put("color_on_secondary", onSecondary)
    store.put("color_text", text)
    store.put("color_muted_text", mutedText)
    store.put("color_outline", outline)
    store.put("color_field_background", fieldBackground)
    store.put("color_field_text", fieldText)
    store.put("color_header_background", headerBackground)
    store.put("color_header_text", headerText)
    store.put("color_progress", progress)
    store.put("color_card_background", cardBackground)
}

private fun AppColors.saveCustomTo(store: LocalStore, name: String) {
    store.put("custom_theme_name", name)
    store.put("custom_theme_background", background)
    store.put("custom_theme_surface", surface)
    store.put("custom_theme_primary", primary)
    store.put("custom_theme_on_primary", onPrimary)
    store.put("custom_theme_secondary", secondary)
    store.put("custom_theme_on_secondary", onSecondary)
    store.put("custom_theme_text", text)
    store.put("custom_theme_muted_text", mutedText)
    store.put("custom_theme_outline", outline)
    store.put("custom_theme_field_background", fieldBackground)
    store.put("custom_theme_field_text", fieldText)
    store.put("custom_theme_header_background", headerBackground)
    store.put("custom_theme_header_text", headerText)
    store.put("custom_theme_progress", progress)
    store.put("custom_theme_card_background", cardBackground)
}

private fun loadCustomColors(store: LocalStore): AppColors? {
    val name = store.get("custom_theme_name", "")
    if (name.isBlank()) return null
    return AppColors(
        background = store.get("custom_theme_background", "#FFF7FB"),
        surface = store.get("custom_theme_surface", "#FFFFFF"),
        primary = store.get("custom_theme_primary", "#C2185B"),
        onPrimary = store.get("custom_theme_on_primary", "#FFFFFF"),
        secondary = store.get("custom_theme_secondary", "#8E4A68"),
        onSecondary = store.get("custom_theme_on_secondary", "#FFFFFF"),
        text = store.get("custom_theme_text", "#2A2024"),
        mutedText = store.get("custom_theme_muted_text", "#756A70"),
        outline = store.get("custom_theme_outline", "#B9AAB2"),
        fieldBackground = store.get("custom_theme_field_background", "#FFF0F6"),
        fieldText = store.get("custom_theme_field_text", "#2A2024"),
        headerBackground = store.get("custom_theme_header_background", "#F8BBD0"),
        headerText = store.get("custom_theme_header_text", "#5A1735"),
        progress = store.get("custom_theme_progress", "#C2185B"),
        cardBackground = store.get("custom_theme_card_background", "#FFFFFF")
    )
}


private data class SavedColorTheme(val name: String, val colors: AppColors)

private fun AppColors.toJson(name: String): JSONObject = JSONObject().apply {
    put("name", name)
    put("background", background); put("surface", surface); put("primary", primary); put("onPrimary", onPrimary)
    put("secondary", secondary); put("onSecondary", onSecondary); put("text", text); put("mutedText", mutedText)
    put("outline", outline); put("fieldBackground", fieldBackground); put("fieldText", fieldText)
    put("headerBackground", headerBackground); put("headerText", headerText); put("progress", progress); put("cardBackground", cardBackground)
}

private fun JSONObject.toAppColors(): AppColors = AppColors(
    background = optString("background", "#FFF7FB"), surface = optString("surface", "#FFFFFF"),
    primary = optString("primary", "#C2185B"), onPrimary = optString("onPrimary", "#FFFFFF"),
    secondary = optString("secondary", "#8E4A68"), onSecondary = optString("onSecondary", "#FFFFFF"),
    text = optString("text", "#2A2024"), mutedText = optString("mutedText", "#756A70"),
    outline = optString("outline", "#B9AAB2"), fieldBackground = optString("fieldBackground", "#FFF0F6"),
    fieldText = optString("fieldText", "#2A2024"), headerBackground = optString("headerBackground", "#F8BBD0"),
    headerText = optString("headerText", "#5A1735"), progress = optString("progress", "#C2185B"),
    cardBackground = optString("cardBackground", "#FFFFFF")
)

private fun loadSavedColorThemes(store: LocalStore): List<SavedColorTheme> {
    val raw = store.get("saved_color_themes", "")
    if (raw.isNotBlank()) runCatching {
        val arr = org.json.JSONArray(raw)
        return (0 until arr.length()).mapNotNull { i ->
            val obj = arr.optJSONObject(i) ?: return@mapNotNull null
            val name = obj.optString("name", "Моя тема").trim().ifBlank { "Моя тема" }
            SavedColorTheme(name, obj.toAppColors())
        }
    }
    // Миграция старой единственной пользовательской темы в новый список.
    return loadCustomColors(store)?.let { listOf(SavedColorTheme(store.get("custom_theme_name", "Моя тема"), it)) } ?: emptyList()
}

private fun saveSavedColorThemes(store: LocalStore, themes: List<SavedColorTheme>) {
    val arr = org.json.JSONArray()
    themes.forEach { arr.put(it.colors.toJson(it.name)) }
    store.put("saved_color_themes", arr.toString())
}

private fun LocalStore.resetColors() {
    val keys = listOf("background","surface","primary","on_primary","secondary","on_secondary","text","muted_text","outline","field_background","field_text","header_background","header_text","progress","card_background")
    keys.forEach { put("color_$it", AppColors().let { c -> when(it) {
        "background" -> c.background; "surface" -> c.surface; "primary" -> c.primary; "on_primary" -> c.onPrimary
        "secondary" -> c.secondary; "on_secondary" -> c.onSecondary; "text" -> c.text; "muted_text" -> c.mutedText
        "outline" -> c.outline; "field_background" -> c.fieldBackground; "field_text" -> c.fieldText
        "header_background" -> c.headerBackground; "header_text" -> c.headerText; "progress" -> c.progress; else -> c.cardBackground
    }}) }
}

@Composable
fun MeterApp(context: Context) {
    val store = remember { LocalStore(context) }
    var themeVersion by remember { mutableIntStateOf(0) }
    val appColors = remember(themeVersion) { AppColors.from(store) }
    CompositionLocalProvider(LocalAppColors provides appColors) {
        MaterialTheme(colorScheme = appColors.scheme()) {
            MeterAppContent(context, onColorsChanged = { themeVersion++ })
        }
    }
}

@Composable
private fun MeterAppContent(context: Context, onColorsChanged: () -> Unit) {

    val store = remember { LocalStore(context) }
    var apartments by remember {
        mutableStateOf(store.apartmentIds().map { id ->
            val base = defaultApartments().firstOrNull { it.id == id } ?: newApartment(id)
            val baseById = base.meters.associateBy { it.id }
            val ids = store.meterIds(id, base.meters)
            val configuredMeters = ids.mapNotNull { meterId ->
                val fallback = baseById[meterId]
                if (fallback != null) fallback else {
                    val type = store.meterType(id, meterId, MeterType.WATER)
                    val title = store.meterTitle(id, meterId, if (type == MeterType.ELECTRICITY) "Электричество №1" else "Вода")
                    Meter(meterId, type, title)
                }
            }.map { m -> m.copy(type = store.meterType(id, m.id, m.type), title = store.meterTitle(id, m.id, m.title), serial = store.get("serial_${m.id}"), reading = store.get("reading_${m.id}"), status = store.get("status_${m.id}", "Не передано")) }
            base.copy(address = store.get("address_${id}", base.address), meters = configuredMeters)
        })
    }
    var credentialsVersion by remember { mutableIntStateOf(0) }
    var jobs by remember { mutableStateOf(listOf<Job>()) }
    var activeJobIndex by remember { mutableIntStateOf(0) }
    var returnApartmentId by remember { mutableStateOf<Int?>(null) }
    var webUrl by remember { mutableStateOf<String?>(null) }
    var webViewRef by remember { mutableStateOf<WebView?>(null) }
    var settings by remember { mutableStateOf(false) }
    var settingsApartmentId by remember { mutableStateOf<Int?>(null) }
    var help by remember { mutableStateOf(false) }
    var reports by remember { mutableStateOf(false) }
    var apartmentOneSummary by remember { mutableStateOf(false) }
    var summaryApartmentId by remember { mutableIntStateOf(1) }
    var electricityReport by remember { mutableStateOf(false) }
    var electricityReportApartmentScreenId by remember { mutableStateOf<Int?>(null) }
    var electricityReportRefreshVersion by remember { mutableIntStateOf(0) }
    var gasReport by remember { mutableStateOf(false) }
    var gasReportApartmentId by remember { mutableStateOf<Int?>(1) }
    var gasReportApartmentScreenId by remember { mutableStateOf<Int?>(null) }
    var gasReportFetchApartmentId by remember { mutableStateOf<Int?>(null) }
    var gasReportAllFetch by remember { mutableStateOf(false) }
    var gasReportAllIndex by remember { mutableIntStateOf(0) }
    var gasReportAllIds by remember { mutableStateOf<List<Int>>(emptyList()) }
    var gasReportAllScreen by remember { mutableStateOf(false) }
    var gasReportRefreshVersion by remember { mutableIntStateOf(0) }
    var waterReport by remember { mutableStateOf(false) }
    var waterReportFetchApartmentId by remember { mutableStateOf<Int?>(null) }
    var waterReportAllFetch by remember { mutableStateOf(false) }
    var waterReportAllIndex by remember { mutableIntStateOf(0) }
    var waterReportAllScreen by remember { mutableStateOf(false) }
    var waterReportApartmentScreenId by remember { mutableStateOf<Int?>(null) }
    var waterReportRefreshVersion by remember { mutableIntStateOf(0) }
    val activity = LocalContext.current as? Activity

    // Системная кнопка «Назад» телефона: внутри экранов возвращает назад,
    // а на главном экране полностью закрывает приложение — как кнопка «Выход».
    BackHandler {
        when {
            webUrl != null -> webUrl = null
            settings -> settings = false
            help -> help = false
            gasReportFetchApartmentId != null || gasReportAllFetch -> {
                gasReportFetchApartmentId = null
                gasReportAllFetch = false
                gasReport = true
            }
            gasReportAllScreen -> { gasReportAllScreen = false; gasReport = true }
            gasReportApartmentScreenId != null -> { gasReportApartmentScreenId = null; gasReport = true }
            gasReport -> { gasReport = false; reports = true }
            waterReportApartmentScreenId != null -> {
                waterReportFetchApartmentId = null
                waterReportApartmentScreenId = null
                waterReport = true
            }
            waterReportAllScreen -> { waterReportAllScreen = false; waterReport = true }
            waterReportFetchApartmentId != null || waterReportAllFetch -> {
                waterReportFetchApartmentId = null
                waterReportAllFetch = false
                waterReport = true
            }
            waterReport -> { waterReport = false; reports = true }
            electricityReportApartmentScreenId != null -> { electricityReportApartmentScreenId = null; electricityReport = true }
            electricityReport -> { electricityReport = false; reports = true }
            apartmentOneSummary -> { apartmentOneSummary = false; reports = true }
            reports -> reports = false
            else -> activity?.finishAffinity()
        }
    }
    val exportLauncher = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
        if (result.resultCode == Activity.RESULT_OK) {
            result.data?.data?.let { uri ->
                runCatching {
                    context.contentResolver.openOutputStream(uri)?.use { output ->
                        output.write(store.exportJson().toByteArray(Charsets.UTF_8))
                    } ?: error("Не удалось открыть файл")
                }
            }
        }
    }
    val importLauncher = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
        if (result.resultCode == Activity.RESULT_OK) {
            result.data?.data?.let { uri ->
                runCatching {
                    val json = context.contentResolver.openInputStream(uri)?.use { it.readBytes().toString(Charsets.UTF_8) }
                        ?: error("Не удалось открыть файл")
                    store.importJson(json)
                    activity?.recreate()
                }
            }
        }
    }

    fun updateMeter(apartmentId: Int, meterId: Int, reading: String? = null, serial: String? = null, status: String? = null) {
        apartments = apartments.map { a -> if (a.id != apartmentId) a else a.copy(meters = a.meters.map { m -> if (m.id != meterId) m else m.copy(reading = reading ?: m.reading, serial = serial ?: m.serial, status = status ?: m.status) }) }
        if (reading != null) store.put("reading_$meterId", reading)
        if (serial != null) store.put("serial_$meterId", serial)
        if (status != null) store.put("status_$meterId", status)
    }
    fun updateStatus(job: Job, status: String) = updateMeter(job.apartmentId, job.meterId, status = status)
    fun clearMeterReading(apartmentId: Int, meterId: Int) {
        apartments = apartments.map { a -> if (a.id != apartmentId) a else a.copy(meters = a.meters.map { m -> if (m.id == meterId) m.copy(reading = "", status = "Не передано") else m }) }
        store.clearReading(meterId)
    }
    fun clearApartmentReadings(apartmentId: Int) {
        val apartment = apartments.firstOrNull { it.id == apartmentId } ?: return
        apartment.meters.forEach { store.clearReading(it.id) }
        apartments = apartments.map { a -> if (a.id != apartmentId) a else a.copy(meters = a.meters.map { it.copy(reading = "", status = "Не передано") }) }
    }
    fun clearAllReadings() {
        apartments.flatMap { it.meters }.forEach { store.clearReading(it.id) }
        apartments = apartments.map { a -> a.copy(meters = a.meters.map { it.copy(reading = "", status = "Не передано") }) }
    }

    fun makeJob(a: Apartment, m: Meter): Job {
        // Критично: серийный номер и показание берём по ID конкретного счётчика
        // из постоянного хранилища. Это исключает подмену Вода №2 значениями Вода №1
        // при повторном создании списка заданий после сохранения настроек.
        val credentials = store.credentials(a.id)
        val serial = store.get("serial_${m.id}", m.serial).trim()
        val reading = store.get("reading_${m.id}", m.reading).trim()
        return Job(
            apartmentId = a.id,
            address = a.address,
            meterId = m.id,
            type = m.type,
            title = m.title,
            reading = reading,
            serial = serial,
            credentials = credentials,
            providerUrl = store.providerUrl(a.id, m.type)
        )
    }

    // Единый алгоритм передачи для каждой квартиры:
    // 1) электричество -> 2) вода -> 3) газ.
    // Порядок не зависит от того, как счётчики записаны в конфигурации квартиры.
    fun orderedJobs(a: Apartment, meters: List<Meter> = a.meters): List<Job> {
        val order = listOf(MeterType.ELECTRICITY, MeterType.WATER, MeterType.GAS)
        return order.flatMap { type ->
            meters.filter { it.type == type }.map { makeJob(a, it) }
        }
    }

    fun startJobs(newJobs: List<Job>) {
        if (newJobs.isNotEmpty()) {
            jobs = newJobs
            activeJobIndex = 0
            returnApartmentId = newJobs[0].apartmentId
            webUrl = newJobs[0].providerUrl
        }
    }
    fun nextJob() {
        val next = activeJobIndex + 1
        if (next >= jobs.size) {
            returnApartmentId = jobs.getOrNull(activeJobIndex)?.apartmentId
            webUrl = null
        } else {
            activeJobIndex = next
            returnApartmentId = jobs[next].apartmentId
            webUrl = jobs[next].providerUrl
        }
    }

    if (help) {
        Scaffold(
            topBar = {
                TopAppBar(
                    title = { Text("Справка") },
                    navigationIcon = { TextButton(onClick = { help = false }) { Text("Назад") } }
                )
            }
        ) { padding ->
            Column(Modifier.fillMaxSize().padding(padding).padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Text("Счётчики", style = MaterialTheme.typography.titleLarge)
                Text("Версия приложения: $APP_VERSION", style = MaterialTheme.typography.bodyLarge)
                Text("Здесь будет размещена подробная справка по работе приложения.", style = MaterialTheme.typography.bodyMedium)
            }
        }
        return
    }

    if (settings) {
        SettingsScreen(
            apartments = apartments,
            store = store,
            initialApartmentId = settingsApartmentId,
            onUpdateAddress = { id, value -> apartments = apartments.map { if (it.id == id) it.copy(address = value) else it }; store.commitAddress("address_$id", value) },
            onUpdateSerial = { id, value -> apartments = apartments.map { a -> a.copy(meters = a.meters.map { m -> if (m.id == id) m.copy(serial = value) else m }) }; store.put("serial_$id", value) },
            onUpdateTitle = { id, value -> apartments = apartments.map { a -> a.copy(meters = a.meters.map { m -> if (m.id == id) m.copy(title = value) else m }) } },
            onAddMeter = addMeter@{ apartmentId, type ->
                val apartment = apartments.firstOrNull { it.id == apartmentId }
                if (apartment == null) return@addMeter
                val newMeterId = (apartments.flatMap { it.meters }.maxOfOrNull { it.id } ?: 0) + 1
                val count = apartment.meters.count { it.type == type } + 1
                val title = if (type == MeterType.ELECTRICITY) { "Электричество №$count" } else { "Вода №$count" }
                val meter = Meter(newMeterId, type, title)
                val orderedMeters = buildList {
                    addAll(apartment.meters.filter { it.type == MeterType.ELECTRICITY })
                    if (type == MeterType.ELECTRICITY) add(meter)
                    addAll(apartment.meters.filter { it.type == MeterType.WATER })
                    if (type == MeterType.WATER) add(meter)
                    addAll(apartment.meters.filter { it.type == MeterType.GAS })
                }
                apartments = apartments.map { if (it.id == apartmentId) it.copy(meters = orderedMeters) else it }
                store.saveMeter(apartmentId, meter)
                store.saveMeterIds(apartmentId, apartments.first { it.id == apartmentId }.meters.map { it.id })
            },
            onDeleteMeter = deleteMeter@{ apartmentId, meterId ->
                val apartment = apartments.firstOrNull { it.id == apartmentId }
                if (apartment == null) return@deleteMeter
                val meter = apartment.meters.firstOrNull { it.id == meterId }
                if (meter == null || (meter.type != MeterType.ELECTRICITY && meter.type != MeterType.WATER)) return@deleteMeter
                val remaining = apartment.meters.filterNot { it.id == meterId }
                apartments = apartments.map { if (it.id == apartmentId) it.copy(meters = remaining) else it }
                store.saveMeterIds(apartmentId, remaining.map { it.id })
                store.deleteMeterData(meterId)
            },
            onAddApartment = {
                val newId = ((apartments.maxOfOrNull { it.id } ?: 0) + 1)
                val added = newApartment(newId)
                apartments = apartments + added
                store.saveApartmentIds(apartments.map { it.id })
            },
            onDeleteApartment = { id ->
                if (apartments.size > 1) {
                    apartments = apartments.filterNot { it.id == id }
                    store.saveApartmentIds(apartments.map { it.id })
                }
            },
            onSaved = { credentialsVersion++ },
            onExportSettings = {
                val intent = Intent(Intent.ACTION_CREATE_DOCUMENT).apply {
                    addCategory(Intent.CATEGORY_OPENABLE)
                    type = "application/json"
                    putExtra(Intent.EXTRA_TITLE, "chetchiki-settings.json")
                }
                exportLauncher.launch(intent)
            },
            onImportSettings = {
                val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
                    addCategory(Intent.CATEGORY_OPENABLE)
                    type = "application/json"
                }
                importLauncher.launch(intent)
            },
            onColorsChanged = onColorsChanged,
            onBack = { settings = false }
        )
        return
    }

    if (electricityReportApartmentScreenId != null) {
        val id = electricityReportApartmentScreenId!!
        ElectricityReportScreen(apartments.firstOrNull { it.id == id }, store,
            onBack = { electricityReportApartmentScreenId = null; electricityReport = true })
        return
    }

    if (electricityReport) {
        ElectricityReportHubScreen(apartments, store,
            onFetchApartment = { id -> electricityReportApartmentScreenId = id },
            onBack = { electricityReport = false; reports = true })
        return
    }

    if (gasReportFetchApartmentId != null) {
        val reportApartmentId = gasReportFetchApartmentId
        val reportApartment = apartments.firstOrNull { it.id == reportApartmentId }
        if (reportApartment != null) {
            val gm = reportApartment.meters.firstOrNull { it.type == MeterType.GAS }
            if (gm != null) {
                val gasJob = Job(
                    apartmentId = reportApartment.id,
                    address = store.apartmentAddress(reportApartment),
                    meterId = gm.id,
                    type = MeterType.GAS,
                    title = gm.title,
                    reading = "",
                    serial = gm.serial,
                    credentials = store.credentials(reportApartment.id),
                    providerUrl = store.providerUrl(reportApartment.id, MeterType.GAS)
                )
                key("gas-report-fetch-${reportApartment.id}") {
                    ProviderScreen(
                        url = gasJob.providerUrl,
                        job = gasJob,
                        index = 1,
                        total = 1,
                        store = store,
                        reportMode = true,
                        gasReportMode = true,
                        gasReportAllFetch = gasReportAllFetch,
                        onGasReportData = { supply, maintenance, _, _ ->
                            store.put("gas_report_supply_${reportApartment.id}", supply)
                            store.put("gas_report_maintenance_${reportApartment.id}", maintenance)
                            store.put("gas_report_generated_${reportApartment.id}", SimpleDateFormat("dd.MM.yyyy HH:mm", Locale.getDefault()).format(Date()))
                            gasReportRefreshVersion++
                            if (gasReportAllFetch && gasReportAllIds.isNotEmpty()) {
                                val nextIndex = gasReportAllIndex + 1
                                if (nextIndex < gasReportAllIds.size) {
                                    gasReportAllIndex = nextIndex
                                    val nextId = gasReportAllIds[nextIndex]
                                    gasReportApartmentId = nextId
                                    gasReportFetchApartmentId = nextId
                                } else {
                                    gasReportAllFetch = false
                                    gasReportAllIndex = 0
                                    gasReportAllIds = emptyList()
                                    gasReportFetchApartmentId = null
                                    gasReportAllScreen = true
                                }
                            } else {
                                gasReportFetchApartmentId = null
                                gasReportApartmentId = reportApartment.id
                                gasReport = true
                            }
                        },
                        onWebViewReady = { webViewRef = it },
                        onStatus = {},
                        onNext = {},
                        onBack = {}
                    )
                }
            } else {
                gasReportFetchApartmentId = null
                gasReport = true
            }
        } else {
            gasReportFetchApartmentId = null
            gasReport = true
        }
        return
    }

    // Water report UI stays visible while the hidden WebView fetches the data.
    // This avoids replacing the report screen with a blank WebView during loading.
    if (gasReportAllScreen) {
        GasReportAllScreen(
            apartments = apartments,
            store = store,
            onBack = { gasReportAllScreen = false; gasReportAllFetch = false; gasReportAllIndex = 0; gasReportAllIds = emptyList(); gasReport = true }
        )
        return
    }

    if (gasReportAllFetch && gasReportAllIds.isNotEmpty() && gasReportFetchApartmentId == null) {
        val targetId = gasReportAllIds.getOrNull(gasReportAllIndex)
        if (targetId != null) {
            gasReportApartmentId = targetId
            gasReportFetchApartmentId = targetId
        }
    }

    if (gasReportApartmentScreenId != null) {
        val id = gasReportApartmentScreenId!!
        GasReportScreen(
            apartment = apartments.firstOrNull { it.id == id },
            store = store,
            refreshVersion = gasReportRefreshVersion,
            onFetch = { gasReportApartmentId = it; gasReportFetchApartmentId = it },
            onBack = { gasReportApartmentScreenId = null; gasReport = true }
        )
        return
    }

    if (gasReport) {
        GasReportHubScreen(
            apartments = apartments,
            store = store,
            onFetchApartment = { id -> gasReportApartmentScreenId = id },
            onFetchAll = {
                val ids = apartments.filter { store.hasConfiguredGasReport(it.id) }.map { it.id }
                gasReportAllIds = ids
                gasReportAllIndex = 0
                gasReportAllFetch = ids.isNotEmpty()
                gasReportApartmentId = ids.firstOrNull()
                gasReportFetchApartmentId = ids.firstOrNull()
                if (ids.isEmpty()) gasReportAllScreen = true
            },
            onBack = { gasReport = false; reports = true }
        )
        return
    }

    if (apartmentOneSummary) {
        ApartmentSummaryScreen(
            apartment = apartments.firstOrNull { it.id == summaryApartmentId },
            apartmentId = summaryApartmentId,
            store = store,
            refreshVersion = electricityReportRefreshVersion + gasReportRefreshVersion + waterReportRefreshVersion,
            onBack = { apartmentOneSummary = false; reports = true }
        )
        return
    }

    if (reports) {
        ReportsHubScreen(
            store = store,
            apartments = apartments,
            onElectricity = { electricityReport = true; reports = false },
            onWater = { waterReport = true; reports = false },
            onGas = { gasReport = true; reports = false },
            onApartmentSummary = { id -> summaryApartmentId = id; apartmentOneSummary = true; reports = false },
            onBack = { reports = false }
        )
        return
    }

    if (waterReportApartmentScreenId != null) {
        val reportApartmentId = waterReportApartmentScreenId
        val reportApartment = apartments.firstOrNull { it.id == reportApartmentId }
        Column(Modifier.fillMaxSize()) {
            WaterReportScreen(
                apartment = reportApartment,
                store = store,
                refreshVersion = waterReportRefreshVersion,
                onFetch = { id ->
                    waterReportFetchApartmentId = id
                    waterReportApartmentScreenId = id
                    waterReport = false
                },
                onBack = { 
                    waterReportFetchApartmentId = null
                    waterReportApartmentScreenId = null
                    waterReport = true
                }
            )
            if (waterReportFetchApartmentId == reportApartmentId) {
                val a = reportApartment
                val wm = a?.meters?.firstOrNull { it.type == MeterType.WATER }
                if (a != null && wm != null) {
                    val reportJob = Job(
                        apartmentId = a.id,
                        address = store.apartmentAddress(a),
                        meterId = wm.id,
                        type = MeterType.WATER,
                        title = wm.title,
                        reading = "",
                        serial = wm.serial,
                        credentials = store.credentials(a.id),
                        providerUrl = store.providerUrl(a.id, MeterType.WATER)
                    )
                    key("water-report-fetch-${a.id}") {
                        ProviderScreen(
                            url = reportJob.providerUrl,
                            job = reportJob,
                            index = 1,
                            total = 1,
                            store = store,
                            reportMode = true,
                            onReportData = { over, debt, penalty ->
                                store.put("water_report_overpayment_${a.id}", over)
                                store.put("water_report_debt_${a.id}", debt)
                                store.put("water_report_penalty_${a.id}", penalty)
                                waterReportRefreshVersion++
                                if (waterReportAllFetch) {
                                    val waterIds = apartments.filter { ap ->
                                            ap.meters.any { it.type == MeterType.WATER } &&
                                                store.waterLogin(ap.id).isNotBlank() &&
                                                store.get("water_password_${ap.id}").isNotBlank()
                                        }.map { it.id }
                                    val nextIndex = waterReportAllIndex + 1
                                    if (nextIndex < waterIds.size) {
                                        waterReportAllIndex = nextIndex
                                        waterReportApartmentScreenId = waterIds[nextIndex]
                                        waterReportFetchApartmentId = waterIds[nextIndex]
                                    } else {
                                        waterReportAllFetch = false
                                        waterReportFetchApartmentId = null
                                        waterReportApartmentScreenId = null
                                        waterReportAllScreen = true
                                    }
                                } else {
                                    waterReportFetchApartmentId = null
                                }
                            },
                            onWebViewReady = { webViewRef = it },
                            onStatus = {},
                            onNext = {},
                            onBack = {}
                        )
                    }
                }
            }
        }
        return
    }

    if (waterReportAllScreen) {
        WaterReportAllScreen(
            apartments = apartments,
            store = store,
            onBack = { waterReportAllScreen = false; waterReport = true }
        )
        return
    }

    if (waterReportFetchApartmentId != null || waterReportAllFetch) {
        // Для общего отчёта берём ТОЛЬКО квартиры, для которых действительно
        // настроены счётчик воды + логин + пароль. Раньше здесь попадали все
        // квартиры с водой, включая квартиры без ЛК, и общий отчёт останавливался
        // на первой такой квартире.
        val configuredWaterIds = apartments
            .filter { store.hasConfiguredWaterReport(it.id) }
            .map { it.id }

        val targetId = if (waterReportAllFetch) {
            configuredWaterIds.getOrNull(waterReportAllIndex)
        } else waterReportFetchApartmentId
        val a = apartments.firstOrNull { it.id == targetId }
        if (a != null) {
            waterReportApartmentScreenId = a.id
            waterReportFetchApartmentId = a.id
            return
        } else {
            waterReportAllFetch = false
            waterReportFetchApartmentId = null
            waterReport = true
            return
        }
    }

    if (waterReport) {
        WaterReportHubScreen(
            apartments = apartments,
            store = store,
            onFetchApartment = { id ->
                val a = apartments.firstOrNull { it.id == id }
                if (a != null && a.meters.any { it.type == MeterType.WATER } &&
                    store.waterLogin(id).isNotBlank() &&
                    store.get("water_password_$id").isNotBlank()) {
                    waterReportApartmentScreenId = id
                    waterReportFetchApartmentId = id
                    waterReport = false
                }
            },
            onFetchAll = {
                val configuredIds = apartments
                    .filter { store.hasConfiguredWaterReport(it.id) }
                    .map { it.id }
                waterReportAllIndex = 0
                waterReportAllFetch = configuredIds.isNotEmpty()
                waterReport = false
            },
            onBack = { waterReport = false; reports = true }
        )
        return
    }

    if (webUrl != null && jobs.isNotEmpty()) {
        val job = jobs[activeJobIndex]
        ProviderScreen(
            url = webUrl!!,
            job = job,
            index = activeJobIndex + 1,
            total = jobs.size,
            store = store,
            onWebViewReady = { webViewRef = it },
            // Finance is stored under the active electricity job's apartment ID, so this
            // works for apartments 1–4 and any additional apartments created in settings.
            onElectricityFinanceData = if (job.type == MeterType.ELECTRICITY) ({ overpayment, debt, penalty, overpaymentLabel, debtLabel, penaltyLabel ->
                val apartmentId = job.apartmentId
                store.put(electricityReportKey(apartmentId, "overpayment"), overpayment)
                store.put(electricityReportKey(apartmentId, "cabinet_debt"), debt)
                store.put(electricityReportKey(apartmentId, "penalty"), penalty)
                store.put(electricityReportKey(apartmentId, "overpayment_label"), overpaymentLabel)
                store.put(electricityReportKey(apartmentId, "debt_label"), debtLabel)
                store.put(electricityReportKey(apartmentId, "penalty_label"), penaltyLabel)
                store.put(electricityReportKey(apartmentId, "generated"), SimpleDateFormat("dd.MM.yyyy HH:mm", Locale.getDefault()).format(Date()))
                electricityReportRefreshVersion++
            }) else null,
            onStatus = { updateStatus(job, it) },
            onNext = { nextJob() },
            onBack = { returnApartmentId = job.apartmentId; webUrl = null }
        )
        return
    }

    val mainListState = rememberLazyListState()
    LaunchedEffect(returnApartmentId, apartments) {
        val targetId = returnApartmentId ?: return@LaunchedEffect
        val apartmentIndex = apartments.indexOfFirst { it.id == targetId }
        if (apartmentIndex >= 0) {
            // Перед квартирами идут блок быстрых переходов и кнопка очистки,
            // затем для каждой квартиры stickyHeader + содержимое.
            val headerIndex = 2 + apartmentIndex * 2
            mainListState.scrollToItem(headerIndex)
        }
        returnApartmentId = null
    }

    Scaffold(topBar = { TopAppBar(title = {}, actions = { TextButton(onClick = { reports = true }) { Text("Отчёты") }; TextButton(onClick = { settingsApartmentId = null; settings = true }) { Text("Настройки") }; TextButton(onClick = { help = true }) { Text("Справка") }; TextButton(onClick = { activity?.finishAffinity() }) { Text("Выход") } }) }, bottomBar = {
        Button(onClick = { startJobs(apartments.flatMap { a -> orderedJobs(a) }) }, modifier = Modifier.fillMaxWidth().padding(12.dp)) { Text("Передать всё — все квартиры") }
    }) { padding ->
        Column(Modifier.fillMaxSize()) {
            Surface(Modifier.fillMaxWidth(), tonalElevation = 4.dp) {
                Text("КОНТРОЛЬНАЯ ВЕРСИЯ 1.04", modifier = Modifier.padding(16.dp), style = MaterialTheme.typography.headlineSmall)
            }
            LazyColumn(state = mainListState, modifier = Modifier.weight(1f).padding(padding).padding(start = 12.dp, end = 12.dp, top = 3.dp, bottom = 8.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
            item(key = "apartment-quick-navigation") {
                Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
                    Text("Квартиры — быстрый переход", style = MaterialTheme.typography.titleMedium)
                    apartments.forEach { apartment ->
                        OutlinedButton(onClick = { returnApartmentId = apartment.id }, modifier = Modifier.fillMaxWidth()) {
                            Column(Modifier.fillMaxWidth()) {
                                Text(store.get("apartment_label_${apartment.id}", "Кв. ${apartment.id}"), style = MaterialTheme.typography.titleSmall, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                Text(store.apartmentAddress(apartment).ifBlank { "Адрес не указан" }, style = MaterialTheme.typography.bodySmall, maxLines = 2, overflow = TextOverflow.Ellipsis)
                            }
                        }
                    }
                }
            }
            item {
                OutlinedButton(onClick = { clearAllReadings() }, modifier = Modifier.fillMaxWidth()) { Text("Очистить показания всех квартир") }
            }
            apartments.forEach { apartment ->
                stickyHeader(key = "apartment-address-${apartment.id}") {
                    Surface(
                        Modifier
                            .fillMaxWidth()
                            .clickable { settingsApartmentId = apartment.id; settings = true },
                        color = LocalAppColors.current.color(LocalAppColors.current.headerBackground, MaterialTheme.colorScheme.primaryContainer),
                        contentColor = LocalAppColors.current.color(LocalAppColors.current.headerText, MaterialTheme.colorScheme.onPrimaryContainer),
                        tonalElevation = 6.dp
                    ) {
                        Column(
                            modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp),
                            verticalArrangement = Arrangement.spacedBy(2.dp)
                        ) {
                            Text(
                                store.get("apartment_label_${apartment.id}", "Кв. ${apartment.id}"),
                                color = LocalAppColors.current.color(LocalAppColors.current.headerText, MaterialTheme.colorScheme.onPrimaryContainer),
                                style = MaterialTheme.typography.bodySmall,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                            Text(
                                apartment.address,
                                color = LocalAppColors.current.color(LocalAppColors.current.headerText, MaterialTheme.colorScheme.onPrimaryContainer),
                                style = MaterialTheme.typography.titleMedium,
                                maxLines = 2,
                                overflow = TextOverflow.Ellipsis
                            )
                        }
                    }
                }
                item(key = "apartment-content-${apartment.id}") {
                Card(Modifier.fillMaxWidth()) { Column(Modifier.padding(12.dp)) {
                    val meterGroups = listOf(MeterType.ELECTRICITY, MeterType.WATER, MeterType.GAS)
                        .map { type -> type to apartment.meters.filter { it.type == type } }
                        .filter { it.second.isNotEmpty() }

                    meterGroups.forEach { (type, groupMeters) ->
                        val typeJobs = orderedJobs(apartment, groupMeters)
                        Column(
                            modifier = Modifier.fillMaxWidth(),
                            verticalArrangement = Arrangement.spacedBy(0.dp)
                        ) {
                            groupMeters.forEachIndexed { index, meter ->
                                val previous = store.previousReading(meter.id)
                                Box(modifier = Modifier.fillMaxWidth()) {
                                    OutlinedTextField(
                                        value = meter.reading,
                                        onValueChange = { v -> updateMeter(apartment.id, meter.id, reading = v, status = "Не передано") },
                                        label = { Text("${meter.title} — новое показание") },
                                        singleLine = true,
                                        modifier = Modifier.fillMaxWidth()
                                    )
                                    if (previous.isNotBlank()) {
                                        Text(
                                            text = "Предыдущее: $previous",
                                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                                            style = MaterialTheme.typography.bodySmall,
                                            maxLines = 1,
                                            softWrap = false,
                                            overflow = TextOverflow.Ellipsis,
                                            modifier = Modifier
                                                .align(Alignment.BottomStart)
                                                .padding(start = 16.dp, bottom = 6.dp)
                                        )
                                    }
                                }
                                if (meter.type == MeterType.WATER && meter.serial.isNotBlank()) {
                                    Text(
                                        text = "Заводской №: ${meter.serial}",
                                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                                        style = MaterialTheme.typography.bodySmall,
                                        maxLines = 1,
                                        softWrap = false,
                                        overflow = TextOverflow.Ellipsis,
                                        modifier = Modifier.padding(start = 16.dp, top = 2.dp, bottom = 2.dp)
                                    )
                                }
                                Row(
                                    Modifier
                                        .fillMaxWidth()
                                        .height(36.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text(
                                        meter.status,
                                        modifier = Modifier.weight(1f),
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis
                                    )
                                    if (index == groupMeters.lastIndex) {
                                        Button(
                                            onClick = { startJobs(typeJobs) },
                                            enabled = typeJobs.isNotEmpty(),
                                            contentPadding = PaddingValues(horizontal = 14.dp, vertical = 0.dp),
                                            modifier = Modifier.height(36.dp).padding(start = 6.dp)
                                        ) {
                                            Text("Передать")
                                        }
                                    }
                                    TextButton(
                                        onClick = { clearMeterReading(apartment.id, meter.id) },
                                        contentPadding = PaddingValues(horizontal = 8.dp, vertical = 0.dp),
                                        modifier = Modifier.height(36.dp)
                                    ) {
                                        Text("Очистить")
                                    }
                                }
                            }
                        }
                    }
                    Spacer(Modifier.height(6.dp))
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        OutlinedButton(onClick = { clearApartmentReadings(apartment.id) }, modifier = Modifier.weight(1f).height(40.dp)) { Text("Очистить всё") }
                        Button(onClick = { startJobs(orderedJobs(apartment)) }, modifier = Modifier.weight(1f).height(40.dp)) { Text("Передать всё") }
                    }
                } }
                }
            }
        }
        }
    }
    @Suppress("UNUSED_VARIABLE") val _keep = credentialsVersion
}

@Composable
private fun SettingsScreen(
    apartments: List<Apartment>,
    store: LocalStore,
    initialApartmentId: Int?,
    onUpdateAddress: (Int, String) -> Unit,
    onUpdateSerial: (Int, String) -> Unit,
    onUpdateTitle: (Int, String) -> Unit,
    onAddMeter: (Int, MeterType) -> Unit,
    onDeleteMeter: (Int, Int) -> Unit,
    onAddApartment: () -> Unit,
    onDeleteApartment: (Int) -> Unit,
    onSaved: () -> Unit,
    onExportSettings: () -> Unit,
    onImportSettings: () -> Unit,
    onColorsChanged: () -> Unit,
    onBack: () -> Unit
) {
    var selectedId by remember(initialApartmentId) { mutableIntStateOf(initialApartmentId ?: apartments.firstOrNull()?.id ?: 1) }
    var selectedTab by remember { mutableIntStateOf(0) }
    var address by remember { mutableStateOf("") }
    var apartmentLabel by remember { mutableStateOf("") }
    var showDeleteConfirmation by remember { mutableStateOf(false) }
    var showDeleteMeterConfirmation by remember { mutableStateOf(false) }
    var pendingDeleteMeterId by remember { mutableIntStateOf(-1) }
    var pendingDeleteMeterTitle by remember { mutableStateOf("") }
    var energySurname by remember { mutableStateOf("") }
    var energyAccount by remember { mutableStateOf("") }
    var energySerial by remember { mutableStateOf("") }
    var waterLogin by remember { mutableStateOf("") }
    var waterPassword by remember { mutableStateOf("") }
    var gasLogin by remember { mutableStateOf("") }
    var gasPassword by remember { mutableStateOf("") }
    var energyUrl by remember { mutableStateOf(ENERGY) }
    var waterUrl by remember { mutableStateOf(WATER) }
    var gasUrl by remember { mutableStateOf(GAS) }
    var showWaterPassword by remember { mutableStateOf(false) }
    var showGasPassword by remember { mutableStateOf(false) }
    val waterSerials = remember { mutableStateMapOf<Int, String>() }
    val meterTitles = remember { mutableStateMapOf<Int, String>() }

    fun loadApartment(id: Int) {
        val a = apartments.firstOrNull { it.id == id } ?: return
        selectedId = id
        address = store.get("address_$id", a.address)
        apartmentLabel = store.get("apartment_label_$id", "Кв. $id")
        energySurname = store.get("energy_surname_$id")
        energyAccount = store.get("energy_account_$id")
        energySerial = store.get("energy_serial_$id")
        waterLogin = store.waterLogin(id)
        waterPassword = store.get("water_password_$id")
        gasLogin = store.get("gas_login_$id")
        gasPassword = store.get("gas_password_$id")
        energyUrl = store.providerUrl(id, MeterType.ELECTRICITY)
        waterUrl = store.providerUrl(id, MeterType.WATER)
        gasUrl = store.providerUrl(id, MeterType.GAS)
        waterSerials.clear()
        meterTitles.clear()
        a.meters.filter { it.type == MeterType.WATER }.forEach { m ->
            waterSerials[m.id] = store.get("serial_${m.id}")
            meterTitles[m.id] = store.meterTitle(id, m.id, m.title)
        }
        showWaterPassword = false
        showGasPassword = false
    }

    LaunchedEffect(initialApartmentId) {
        loadApartment(initialApartmentId ?: selectedId)
    }

    fun saveApartment(id: Int = selectedId) {
        // IMPORTANT: only write fields when id is the currently displayed apartment.
        // This prevents a stale Compose field from being written to another apartment.
        if (id != selectedId) return
        store.commitAddress("address_$id", address)
        store.put("apartment_label_$id", apartmentLabel.trim().ifBlank { "Кв. $id" })
        onUpdateAddress(id, address)
        store.put("energy_surname_$id", energySurname)
        store.put("energy_account_$id", energyAccount)
        store.put("energy_serial_$id", energySerial)
        store.put("water_login_$id", waterLogin)
        store.put("water_password_$id", waterPassword)
        store.put("gas_login_$id", gasLogin)
        store.put("gas_password_$id", gasPassword)
        store.saveProviderUrl(id, MeterType.ELECTRICITY, energyUrl.trim().ifBlank { ENERGY })
        store.saveProviderUrl(id, MeterType.WATER, waterUrl.trim().ifBlank { WATER })
        store.saveProviderUrl(id, MeterType.GAS, gasUrl.trim().ifBlank { GAS })
        apartments.firstOrNull { it.id == id }?.meters?.filter { it.type == MeterType.WATER }?.forEach { m ->
            val title = meterTitles[m.id].orEmpty().trim().ifBlank { m.title }
            val serial = waterSerials[m.id].orEmpty().trim()
            store.put("meter_title_${id}_${m.id}", title)
            onUpdateTitle(m.id, title)
            store.put("serial_${m.id}", serial)
            onUpdateSerial(m.id, serial)
        }
        apartments.firstOrNull { it.id == id }?.meters?.forEach { m ->
            if (m.type == MeterType.ELECTRICITY) {
                store.put("meter_title_${id}_${m.id}", m.title.trim().ifBlank { m.title })
            }
        }
        apartments.firstOrNull { it.id == id }?.meters?.forEach { m ->
            if (m.type == MeterType.ELECTRICITY && energySerial.isNotBlank()) onUpdateSerial(m.id, energySerial)
        }
        onSaved()
    }

    Scaffold(topBar = { TopAppBar(title = { Text("Настройки") }, navigationIcon = { TextButton(onClick = onBack) { Text("Назад") } }) }) { padding ->
        Column(Modifier.padding(padding)) {
            TabRow(selectedTabIndex = selectedTab) {
                Tab(selected = selectedTab == 0, onClick = { selectedTab = 0 }, text = { Text("Основные") })
                Tab(selected = selectedTab == 1, onClick = { selectedTab = 1 }, text = { Text("Цвета") })
            }
            if (selectedTab == 1) {
                ColorsSettingsScreen(store = store, onColorsChanged = onColorsChanged)
                return@Scaffold
            }
        LazyColumn(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            item {
                Text("Резервная копия настроек", style = MaterialTheme.typography.titleMedium)
                Text(
                    "При экспорте Android предложит выбрать имя и место сохранения файла. В файл входят квартиры, названия, показания, номера счётчиков, логины и другие настройки. Пароли также входят в файл резервной копии.",
                    style = MaterialTheme.typography.bodySmall
                )
                Spacer(Modifier.height(4.dp))
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedButton(onClick = onExportSettings, modifier = Modifier.weight(1f)) { Text("Экспорт настроек") }
                    OutlinedButton(onClick = onImportSettings, modifier = Modifier.weight(1f)) { Text("Импорт настроек") }
                }
            }
            item {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text("Квартиры", style = MaterialTheme.typography.titleMedium)
                    Button(onClick = { saveApartment(); onAddApartment() }) { Text("+ Добавить") }
                }
            }
            item {
                Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    apartments.forEach { apartment ->
                        Button(
                            onClick = {
                                if (selectedId != apartment.id) {
                                    saveApartment(selectedId)
                                    loadApartment(apartment.id)
                                }
                            },
                            enabled = selectedId != apartment.id,
                            contentPadding = PaddingValues(horizontal = 10.dp, vertical = 8.dp)
                        ) {
                            Column {
                                Text(
                                    store.get("apartment_label_${apartment.id}", "Кв. ${apartment.id}"),
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                                Text(
                                    store.apartmentAddress(apartment).ifBlank { "Без адреса" },
                                    maxLines = 2,
                                    overflow = TextOverflow.Ellipsis,
                                    style = MaterialTheme.typography.labelSmall
                                )
                            }
                        }
                    }
                }
            }
            item {
                OutlinedTextField(
                    apartmentLabel,
                    { apartmentLabel = it },
                    label = { Text("Название кнопки квартиры") },
                    supportingText = { Text("Это название будет показано вместо «Кв. $selectedId».") },
                    modifier = Modifier.fillMaxWidth()
                )
            }
            item { OutlinedTextField(address, { address = it }, label = { Text("Адрес") }, modifier = Modifier.fillMaxWidth()) }
            item {
                if (apartments.size > 1) {
                    OutlinedButton(
                        onClick = { showDeleteConfirmation = true },
                        modifier = Modifier.fillMaxWidth()
                    ) { Text("Удалить квартиру $selectedId") }
                }
            }
            item {
                Text("Поля для передачи показаний", style = MaterialTheme.typography.titleMedium)
                Text("Можно добавлять и удалять поля для воды и электричества. Газ остаётся отдельным полем.", style = MaterialTheme.typography.bodySmall)
            }
            item {
                Text("Электричество", style = MaterialTheme.typography.titleSmall)
                apartments.firstOrNull { it.id == selectedId }?.meters
                    ?.filter { it.type == MeterType.ELECTRICITY }
                    ?.forEach { meter ->
                        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                            OutlinedTextField(
                                value = meter.title,
                                onValueChange = { onUpdateTitle(meter.id, it) },
                                singleLine = true,
                                label = { Text("Название") },
                                modifier = Modifier.weight(1f)
                            )
                            TextButton(onClick = {
                                pendingDeleteMeterId = meter.id
                                pendingDeleteMeterTitle = meter.title
                                showDeleteMeterConfirmation = true
                            }) { Text("Удалить") }
                        }
                    }
            }
            item {
                Button(onClick = { onAddMeter(selectedId, MeterType.ELECTRICITY) }, modifier = Modifier.fillMaxWidth()) {
                    Text("+ Добавить свет")
                }
            }
            item {
                Text("Вода", style = MaterialTheme.typography.titleSmall)
                apartments.firstOrNull { it.id == selectedId }?.meters
                    ?.filter { it.type == MeterType.WATER }
                    ?.forEach { meter ->
                        Column(Modifier.fillMaxWidth()) {
                            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                                OutlinedTextField(
                                    value = meterTitles[meter.id].orEmpty().ifBlank { meter.title },
                                    onValueChange = { meterTitles[meter.id] = it },
                                    singleLine = true,
                                    label = { Text("Название") },
                                    modifier = Modifier.weight(1f)
                                )
                                TextButton(onClick = {
                                    pendingDeleteMeterId = meter.id
                                    pendingDeleteMeterTitle = meter.title
                                    showDeleteMeterConfirmation = true
                                }) { Text("Удалить") }
                            }
                            OutlinedTextField(
                                value = waterSerials[meter.id].orEmpty(),
                                onValueChange = { waterSerials[meter.id] = it },
                                label = { Text("Заводской номер ${meterTitles[meter.id].orEmpty().ifBlank { meter.title }}") },
                                singleLine = true,
                                supportingText = { Text("Этот номер используется для поиска такого же счётчика в ЛК Водоканала") },
                                modifier = Modifier.fillMaxWidth()
                            )
                        }
                    }
            }
            item {
                Button(onClick = { onAddMeter(selectedId, MeterType.WATER) }, modifier = Modifier.fillMaxWidth()) {
                    Text("+ Добавить воду")
                }
            }
            item { Text("Севэнергосбыт", style = MaterialTheme.typography.titleMedium) }
            item { OutlinedTextField(energySurname, { energySurname = it }, label = { Text("Фамилия") }, modifier = Modifier.fillMaxWidth()) }
            item { OutlinedTextField(energyAccount, { energyAccount = it }, label = { Text("Лицевой счёт") }, modifier = Modifier.fillMaxWidth()) }
            item { OutlinedTextField(energySerial, { energySerial = it }, label = { Text("Номер счётчика") }, modifier = Modifier.fillMaxWidth()) }
            item { OutlinedTextField(energyUrl, { energyUrl = it }, label = { Text("Адрес личного кабинета") }, modifier = Modifier.fillMaxWidth()) }
            item { Text("Водоканал", style = MaterialTheme.typography.titleMedium) }
            item { OutlinedTextField(waterLogin, { waterLogin = it }, label = { Text("Лицевой счёт / логин") }, modifier = Modifier.fillMaxWidth()) }
            item { OutlinedTextField(waterPassword, { waterPassword = it }, label = { Text("Пароль") }, visualTransformation = if (showWaterPassword) androidx.compose.ui.text.input.VisualTransformation.None else PasswordVisualTransformation(), trailingIcon = { TextButton(onClick = { showWaterPassword = !showWaterPassword }) { Text(if (showWaterPassword) "Скрыть" else "Показать") } }, modifier = Modifier.fillMaxWidth()) }
            item { OutlinedTextField(waterUrl, { waterUrl = it }, label = { Text("Адрес личного кабинета") }, modifier = Modifier.fillMaxWidth()) }
            item { Text("Севгаз", style = MaterialTheme.typography.titleMedium) }
            item { OutlinedTextField(gasLogin, { gasLogin = it }, label = { Text("Логин") }, modifier = Modifier.fillMaxWidth()) }
            item { OutlinedTextField(gasPassword, { gasPassword = it }, label = { Text("Пароль") }, visualTransformation = if (showGasPassword) androidx.compose.ui.text.input.VisualTransformation.None else PasswordVisualTransformation(), trailingIcon = { TextButton(onClick = { showGasPassword = !showGasPassword }) { Text(if (showGasPassword) "Скрыть" else "Показать") } }, modifier = Modifier.fillMaxWidth()) }
            item { OutlinedTextField(gasUrl, { gasUrl = it }, label = { Text("Адрес личного кабинета") }, modifier = Modifier.fillMaxWidth()) }
            item { Text("Адреса личных кабинетов сохраняются отдельно для каждой квартиры.") }
            item { Text("Пароли сохраняются только на этом телефоне.") }
            item { Button(onClick = { saveApartment() }, modifier = Modifier.fillMaxWidth()) { Text("Сохранить") } }
        }
    }

    if (showDeleteMeterConfirmation) {
        AlertDialog(
            onDismissRequest = { showDeleteMeterConfirmation = false },
            title = { Text("Удалить поле?") },
            text = { Text("Удалить поле «${pendingDeleteMeterTitle.ifBlank { "Счётчик" }}»? Показания этого счётчика будут удалены из настроек.") },
            confirmButton = {
                TextButton(onClick = {
                    showDeleteMeterConfirmation = false
                    if (pendingDeleteMeterId >= 0) onDeleteMeter(selectedId, pendingDeleteMeterId)
                    pendingDeleteMeterId = -1
                    pendingDeleteMeterTitle = ""
                }) { Text("Удалить") }
            },
            dismissButton = { TextButton(onClick = { showDeleteMeterConfirmation = false }) { Text("Отмена") } }
        )
    }

    if (showDeleteConfirmation) {
        AlertDialog(
            onDismissRequest = { showDeleteConfirmation = false },
            title = { Text("Удалить квартиру?") },
            text = {
                Text(
                    "Квартира «${apartmentLabel.ifBlank { "Кв. $selectedId" }}» будет удалена вместе с её настройками. Это действие нельзя отменить."
                )
            },
            confirmButton = {
                TextButton(
                    onClick = {
                        showDeleteConfirmation = false
                        val deletedId = selectedId
                        saveApartment(deletedId)
                        onDeleteApartment(deletedId)
                        val next = apartments.firstOrNull { it.id != deletedId }
                        if (next != null) loadApartment(next.id)
                    }
                ) { Text("Удалить") }
            },
            dismissButton = {
                TextButton(onClick = { showDeleteConfirmation = false }) { Text("Отмена") }
            }
        )
    }
}
}


data class ElectricityReportData(val apartment:String,val address:String,val generatedAt:String,val overpayment:String,val cabinetDebt:String,val penalty:String,val overpaymentLabel:String,val debtLabel:String,val penaltyLabel:String)

private fun electricityReportKey(id:Int, field:String) = "electricity_report_${field}_$id"

@Composable private fun ElectricityReportHubScreen(apartments:List<Apartment>, store:LocalStore, onFetchApartment:(Int)->Unit, onBack:()->Unit) {
    Scaffold(topBar={ TopAppBar(title={Text("Отчёт по свету")}, navigationIcon={TextButton(onClick=onBack){Text("Назад")}}) }) { padding ->
        LazyColumn(Modifier.padding(padding).padding(12.dp), verticalArrangement=Arrangement.spacedBy(10.dp)) {
            item { Text("Выберите квартиру, чтобы открыть сохранённые финансовые данные.", style=MaterialTheme.typography.bodySmall) }
            items(apartments.filter { a -> a.meters.any { it.type == MeterType.ELECTRICITY } }, key={it.id}) { a ->
                Button(onClick={onFetchApartment(a.id)}, modifier=Modifier.fillMaxWidth()) { Text("${store.get("apartment_label_${a.id}", "Кв. ${a.id}")} — ${store.apartmentAddress(a).ifBlank { "Квартира ${a.id}" }}") }
            }
        }
    }
}

@Composable private fun ElectricityReportScreen(apartment:Apartment?, store:LocalStore, onBack:()->Unit) {
    val id=apartment?.id ?: 1
    val data=ElectricityReportData("Квартира $id", apartment?.let{store.apartmentAddress(it)}.orEmpty(), store.get(electricityReportKey(id,"generated")).ifBlank{"Не выгружался"}, store.get(electricityReportKey(id,"overpayment")).ifBlank{"Не получено"}, store.get(electricityReportKey(id,"cabinet_debt")).ifBlank{"Не получено"}, store.get(electricityReportKey(id,"penalty")).ifBlank{"Не получено"}, store.get(electricityReportKey(id,"overpayment_label")).ifBlank{"Переплата"}, store.get(electricityReportKey(id,"debt_label")).ifBlank{"Задолженность"}, store.get(electricityReportKey(id,"penalty_label")).ifBlank{"Пеня"})
    Scaffold(topBar={TopAppBar(title={Text("Отчёт по свету — Кв. $id")}, navigationIcon={TextButton(onClick=onBack){Text("Назад")}})}) { padding ->
        LazyColumn(Modifier.padding(padding).padding(12.dp), verticalArrangement=Arrangement.spacedBy(10.dp)) {
            item{Text(data.address,style=MaterialTheme.typography.titleMedium)}
            item{Text("Дата и время выгрузки отчёта: ${data.generatedAt}",style=MaterialTheme.typography.bodySmall)}
            item { Divider() }
            item{Text("Финансовые данные из ЛК", style=MaterialTheme.typography.titleMedium)}
            item{Text("${data.overpaymentLabel}: ${data.overpayment}${if (data.overpayment.toDoubleOrNull() != null) " руб." else ""}")}
            item{Text("${data.debtLabel}: ${data.cabinetDebt}${if (data.cabinetDebt.toDoubleOrNull() != null) " руб." else ""}")}
            item{Text("${data.penaltyLabel}: ${data.penalty}${if (data.penalty.toDoubleOrNull() != null) " руб." else ""}")}
        }
    }
}

data class GasReportData(
    val apartment: String,
    val address: String,
    val generatedAt: String,
    val supply: String,
    val maintenance: String
)

private fun gasReportHtml(data: GasReportData): String = """
<html><meta charset='utf-8'><body>
<h2>Отчёт по газу — ${data.apartment}</h2>
<p>${data.address}</p>
<table border='1' cellspacing='0' cellpadding='6'>
<tr><td>Газоснабжение</td><td>${data.supply}</td></tr>
<tr><td>Техобслуживание</td><td>${data.maintenance}</td></tr>
</table>
<p>Дата и время выгрузки: ${data.generatedAt}</p>
</body></html>
"""


private fun colorFromHex(value: String, fallback: Color = Color.Gray): Color =
    runCatching { Color(android.graphics.Color.parseColor(value)) }.getOrDefault(fallback)

private fun isLightColor(color: Color): Boolean {
    val r = color.red
    val g = color.green
    val b = color.blue
    return (0.299f * r + 0.587f * g + 0.114f * b) > 0.55f
}

private fun colorToHex(color: Color): String {
    val r = (color.red * 255f).roundToInt().coerceIn(0, 255)
    val g = (color.green * 255f).roundToInt().coerceIn(0, 255)
    val b = (color.blue * 255f).roundToInt().coerceIn(0, 255)
    return String.format(Locale.US, "#%02X%02X%02X", r, g, b)
}

private data class ColorThemePreset(val name: String, val colors: AppColors)

private fun colorThemePresets(): List<ColorThemePreset> = listOf(
    ColorThemePreset("Розовая", AppColors()),
    ColorThemePreset("Синяя", AppColors(
        background = "#F5F9FF", surface = "#FFFFFF", primary = "#1976D2", onPrimary = "#FFFFFF",
        secondary = "#455A64", onSecondary = "#FFFFFF", text = "#17212B", mutedText = "#607D8B",
        outline = "#90A4AE", fieldBackground = "#EAF3FF", fieldText = "#17212B",
        headerBackground = "#BBDEFB", headerText = "#0D47A1", progress = "#1976D2", cardBackground = "#FFFFFF"
    )),
    ColorThemePreset("Зелёная", AppColors(
        background = "#F5FBF6", surface = "#FFFFFF", primary = "#2E7D32", onPrimary = "#FFFFFF",
        secondary = "#558B2F", onSecondary = "#FFFFFF", text = "#1B2A1C", mutedText = "#607D63",
        outline = "#9BB59E", fieldBackground = "#EAF6EB", fieldText = "#1B2A1C",
        headerBackground = "#C8E6C9", headerText = "#1B5E20", progress = "#2E7D32", cardBackground = "#FFFFFF"
    )),
    ColorThemePreset("Тёмная", AppColors(
        background = "#17151A", surface = "#242127", primary = "#FF80AB", onPrimary = "#35101F",
        secondary = "#B39DDB", onSecondary = "#211A2D", text = "#F5EEF2", mutedText = "#C7BBC2",
        outline = "#5F5660", fieldBackground = "#302B34", fieldText = "#F5EEF2",
        headerBackground = "#5A3045", headerText = "#FFE5EE", progress = "#FF80AB", cardBackground = "#242127"
    )),
    ColorThemePreset("Песочная", AppColors(
        background = "#FFF9F0", surface = "#FFFFFF", primary = "#B56A1F", onPrimary = "#FFFFFF",
        secondary = "#7A5C3E", onSecondary = "#FFFFFF", text = "#33281F", mutedText = "#806F60",
        outline = "#C9B9A8", fieldBackground = "#FFF1DE", fieldText = "#33281F",
        headerBackground = "#FFE0B2", headerText = "#5D3510", progress = "#B56A1F", cardBackground = "#FFFFFF"
    )),
    ColorThemePreset("Windows XP", AppColors(
        background = "#ECE9D8", surface = "#FFFFFF", primary = "#316AC5", onPrimary = "#FFFFFF",
        secondary = "#3A8E3A", onSecondary = "#FFFFFF", text = "#003399", mutedText = "#666666",
        outline = "#7F9DB9", fieldBackground = "#FFFFFF", fieldText = "#000000",
        headerBackground = "#3A6EA5", headerText = "#FFFFFF", progress = "#316AC5", cardBackground = "#FFFFFF"
    )),
    ColorThemePreset("Windows 10", AppColors(
        background = "#F2F2F2", surface = "#FFFFFF", primary = "#0078D7", onPrimary = "#FFFFFF",
        secondary = "#5C5C5C", onSecondary = "#FFFFFF", text = "#1F1F1F", mutedText = "#666666",
        outline = "#BFBFBF", fieldBackground = "#FFFFFF", fieldText = "#1F1F1F",
        headerBackground = "#0078D7", headerText = "#FFFFFF", progress = "#0078D7", cardBackground = "#FFFFFF"
    )),
    ColorThemePreset("Windows 11", AppColors(
        background = "#F3F6FA", surface = "#FFFFFF", primary = "#0067C0", onPrimary = "#FFFFFF",
        secondary = "#4F5D6B", onSecondary = "#FFFFFF", text = "#202020", mutedText = "#6B7280",
        outline = "#D0D7DE", fieldBackground = "#F8FAFC", fieldText = "#202020",
        headerBackground = "#DDEEFF", headerText = "#004A8F", progress = "#0067C0", cardBackground = "#FFFFFF"
    )),
    ColorThemePreset("Чёрно-красная", AppColors(
        background = "#09090B", surface = "#151519", primary = "#D71920", onPrimary = "#FFFFFF",
        secondary = "#34343A", onSecondary = "#FFFFFF", text = "#F5F5F7", mutedText = "#A6A6AD",
        outline = "#5A171B", fieldBackground = "#202024", fieldText = "#F5F5F7",
        headerBackground = "#2A0B0E", headerText = "#FFD7DA", progress = "#E31B23", cardBackground = "#17171B"
    ))
)

@Composable
private fun PaletteColorDialog(
    colorTitle: String,
    initial: String,
    onSelect: (String) -> Unit,
    onDismiss: () -> Unit
) {
    val palette = listOf(
        "#000000", "#FFFFFF", "#F44336", "#E91E63", "#9C27B0", "#673AB7", "#3F51B5", "#2196F3",
        "#03A9F4", "#00BCD4", "#009688", "#4CAF50", "#8BC34A", "#CDDC39", "#FFEB3B", "#FFC107",
        "#FF9800", "#FF5722", "#795548", "#9E9E9E", "#607D8B", "#F8BBD0", "#C2185B", "#8E4A68",
        "#FFF7FB", "#FFF0F6", "#E3F2FD", "#E8F5E9", "#FFF3E0", "#F3E5F5", "#FFFDE7", "#ECEFF1"
    )
    var selected by remember(initial) { mutableStateOf(colorFromHex(initial)) }
    var hsv by remember(initial) {
        mutableStateOf(FloatArray(3).also { android.graphics.Color.colorToHSV(colorFromHex(initial).toArgb(), it) })
    }
    var hexText by remember(initial) { mutableStateOf(colorToHex(colorFromHex(initial))) }
    var hexError by remember(initial) { mutableStateOf(false) }

    fun setSelected(color: Color, exactHex: String? = null) {
        selected = color
        android.graphics.Color.colorToHSV(color.toArgb(), hsv)
        hsv = hsv.copyOf()
        hexText = exactHex ?: colorToHex(color)
        hexError = false
    }

    fun setFromHex(raw: String) {
        val normalized = raw.trim().let { if (it.startsWith("#")) it else "#$it" }
        if (normalized.matches(Regex("#[0-9A-Fa-f]{6}"))) {
            setSelected(colorFromHex(normalized))
        }
    }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Цвет: $colorTitle") },
        text = {
            Column(
                modifier = Modifier.verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Text("Готовая палитра", style = MaterialTheme.typography.titleSmall)
                Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    palette.chunked(8).forEach { row ->
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            row.forEach { hex ->
                                val swatchSelected = colorFromHex(hex).toArgb() == selected.toArgb()
                                Box(
                                    Modifier.size(34.dp)
                                        .then(if (swatchSelected) Modifier.border(2.dp, MaterialTheme.colorScheme.primary, MaterialTheme.shapes.small) else Modifier.border(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.45f), MaterialTheme.shapes.small))
                                        .padding(if (swatchSelected) 3.dp else 0.dp)
                                        .background(colorFromHex(hex), MaterialTheme.shapes.small)
                                        .clickable { setSelected(colorFromHex(hex), hex) }
                                )
                            }
                        }
                    }
                }
                HorizontalDivider()
                Text("Точный цвет", style = MaterialTheme.typography.titleSmall)
                Text("Введите HEX — пример справа/ниже должен совпадать с ним точно.", style = MaterialTheme.typography.bodySmall)
                OutlinedTextField(
                    value = hexText,
                    onValueChange = { value ->
                        val filtered = value.uppercase(Locale.US).filter { it == '#' || it.isDigit() || it in 'A'..'F' }.take(7)
                        hexText = filtered
                        val normalized = filtered.let { if (it.startsWith("#")) it else "#$it" }
                        if (normalized.matches(Regex("#[0-9A-F]{6}"))) {
                            setSelected(colorFromHex(normalized))
                        } else {
                            hexError = filtered.isNotEmpty()
                        }
                    },
                    label = { Text("HEX") },
                    placeholder = { Text("#RRGGBB") },
                    singleLine = true,
                    isError = hexError,
                    supportingText = { if (hexError) Text("Формат: #RRGGBB") },
                    modifier = Modifier.fillMaxWidth()
                )
                Surface(Modifier.fillMaxWidth(), color = selected, shape = MaterialTheme.shapes.medium) {
                    Column(Modifier.padding(12.dp)) {
                        Text("Пример цвета", color = if (isLightColor(selected)) Color.Black else Color.White, style = MaterialTheme.typography.bodySmall)
                        Text(colorToHex(selected), color = if (isLightColor(selected)) Color.Black else Color.White, style = MaterialTheme.typography.titleMedium)
                    }
                }
                Box(
                    Modifier.fillMaxWidth().height(190.dp).background(
                        Brush.verticalGradient(listOf(Color.White, Color.Transparent, Color.Black)),
                        MaterialTheme.shapes.medium
                    )
                ) {
                    Box(
                        Modifier.fillMaxSize().background(
                            Brush.horizontalGradient((0..360 step 30).map { Color(android.graphics.Color.HSVToColor(floatArrayOf(it.toFloat(), 1f, 1f))) }),
                            MaterialTheme.shapes.medium
                        ).pointerInput(Unit) {
                            detectDragGestures(
                                onDragStart = { offset ->
                                    val hue = (offset.x / size.width.toFloat()).coerceIn(0f, 1f) * 360f
                                    val vertical = (offset.y / size.height.toFloat()).coerceIn(0f, 1f)
                                    hsv = hsv.copyOf().also {
                                        it[0] = hue
                                        if (vertical < 0.5f) { it[1] = vertical * 2f; it[2] = 1f }
                                        else { it[1] = 1f; it[2] = (1f - vertical) * 2f }
                                    }
                                    setSelected(Color(android.graphics.Color.HSVToColor(hsv)))
                                },
                                onDrag = { change, _ ->
                                    val hue = (change.position.x / size.width.toFloat()).coerceIn(0f, 1f) * 360f
                                    val vertical = (change.position.y / size.height.toFloat()).coerceIn(0f, 1f)
                                    hsv = hsv.copyOf().also {
                                        it[0] = hue
                                        if (vertical < 0.5f) { it[1] = vertical * 2f; it[2] = 1f }
                                        else { it[1] = 1f; it[2] = (1f - vertical) * 2f }
                                    }
                                    setSelected(Color(android.graphics.Color.HSVToColor(hsv)))
                                }
                            )
                        }
                    )
                    androidx.compose.foundation.Canvas(Modifier.matchParentSize()) {
                        val x = (hsv[0].coerceIn(0f, 360f) / 360f) * size.width
                        val yFraction = if (hsv[1] < 1f) hsv[1].coerceIn(0f, 1f) / 2f else 1f - hsv[2].coerceIn(0f, 1f) / 2f
                        val y = yFraction * size.height
                        val center = androidx.compose.ui.geometry.Offset(x, y)
                        drawCircle(color = Color.White, radius = 11.dp.toPx(), center = center)
                        drawCircle(color = Color.Black, radius = 9.dp.toPx(), center = center, style = androidx.compose.ui.graphics.drawscope.Stroke(width = 2.dp.toPx()))
                        drawCircle(color = selected, radius = 5.dp.toPx(), center = center)
                    }
                }
                Text("Оттенок", style = MaterialTheme.typography.titleSmall)
                Text("Переместите ползунок, чтобы изменить оттенок выбранного цвета.", style = MaterialTheme.typography.bodySmall)
                Box(
                    Modifier.fillMaxWidth().height(44.dp)
                        .background(
                            Brush.horizontalGradient((0..360 step 30).map { Color(android.graphics.Color.HSVToColor(floatArrayOf(it.toFloat(), 1f, 1f))) }),
                            MaterialTheme.shapes.small
                        )
                        .pointerInput(Unit) {
                            detectDragGestures(
                                onDragStart = { offset ->
                                    hsv = hsv.copyOf().also {
                                        it[0] = (offset.x / size.width.toFloat() * 360f).coerceIn(0f, 360f)
                                        it[1] = 1f
                                        it[2] = 1f
                                    }
                                    setSelected(Color(android.graphics.Color.HSVToColor(hsv)))
                                },
                                onDrag = { change, _ ->
                                    hsv = hsv.copyOf().also {
                                        it[0] = (change.position.x / size.width.toFloat() * 360f).coerceIn(0f, 360f)
                                        it[1] = 1f
                                        it[2] = 1f
                                    }
                                    setSelected(Color(android.graphics.Color.HSVToColor(hsv)))
                                }
                            )
                        }) {
                    androidx.compose.foundation.Canvas(Modifier.matchParentSize()) {
                        val x = (hsv[0] / 360f).coerceIn(0f, 1f) * size.width
                        drawCircle(
                            color = Color.White,
                            radius = 10.dp.toPx(),
                            center = androidx.compose.ui.geometry.Offset(x, size.height / 2f)
                        )
                        drawCircle(
                            color = Color.Black,
                            radius = 7.dp.toPx(),
                            center = androidx.compose.ui.geometry.Offset(x, size.height / 2f),
                            style = androidx.compose.ui.graphics.drawscope.Stroke(width = 2.dp.toPx())
                        )
                    }
                }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    val normalized = hexText.trim().let { if (it.startsWith("#")) it else "#$it" }
                    if (normalized.matches(Regex("#[0-9A-Fa-f]{6}"))) {
                        onSelect(normalized.uppercase(Locale.US))
                        onDismiss()
                    } else {
                        hexError = true
                    }
                }
            ) { Text("Выбрать") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Отмена") } }
    )
}

@Composable
private fun ColorsSettingsScreen(store: LocalStore, onColorsChanged: () -> Unit) {
    val defaults = AppColors()
    var colors by remember { mutableStateOf(AppColors.from(store)) }
    var pickerKey by remember { mutableStateOf<String?>(null) }
    var saveThemeDialog by remember { mutableStateOf(false) }
    var renameThemeIndex by remember { mutableIntStateOf(-1) }
    var deleteThemeIndex by remember { mutableIntStateOf(-1) }
    var themeName by remember { mutableStateOf("") }
    var renamePaletteKey by remember { mutableStateOf<String?>(null) }
    var paletteName by remember { mutableStateOf("") }
    var paletteLabelVersion by remember { mutableIntStateOf(0) }
    var renameSectionKey by remember { mutableStateOf<String?>(null) }
    var sectionName by remember { mutableStateOf("") }
    var savedThemes by remember { mutableStateOf(loadSavedColorThemes(store)) }
    val themeListState = rememberLazyListState()

    fun set(key: String, value: String) {
        colors = when (key) {
            "background" -> colors.copy(background = value); "surface" -> colors.copy(surface = value)
            "primary" -> colors.copy(primary = value); "onPrimary" -> colors.copy(onPrimary = value)
            "secondary" -> colors.copy(secondary = value); "onSecondary" -> colors.copy(onSecondary = value)
            "text" -> colors.copy(text = value); "mutedText" -> colors.copy(mutedText = value)
            "outline" -> colors.copy(outline = value); "fieldBackground" -> colors.copy(fieldBackground = value)
            "fieldText" -> colors.copy(fieldText = value); "headerBackground" -> colors.copy(headerBackground = value)
            "headerText" -> colors.copy(headerText = value); "progress" -> colors.copy(progress = value)
            else -> colors.copy(cardBackground = value)
        }
        colors.saveTo(store); onColorsChanged(); pickerKey = null
    }

    val paletteDefaults = listOf(
        Triple("Фон приложения", "background", colors.background), Triple("Фон областей", "surface", colors.surface),
        Triple("Кнопки", "primary", colors.primary), Triple("Текст кнопок", "onPrimary", colors.onPrimary),
        Triple("Дополнительные кнопки", "secondary", colors.secondary), Triple("Текст дополнительных кнопок", "onSecondary", colors.onSecondary),
        Triple("Основной текст", "text", colors.text), Triple("Вторичный текст", "mutedText", colors.mutedText),
        Triple("Контуры полей", "outline", colors.outline), Triple("Фон полей ввода", "fieldBackground", colors.fieldBackground),
        Triple("Текст полей ввода", "fieldText", colors.fieldText), Triple("Фон заголовков", "headerBackground", colors.headerBackground),
        Triple("Текст заголовков", "headerText", colors.headerText), Triple("Прогресс", "progress", colors.progress),
        Triple("Фон карточек", "cardBackground", colors.cardBackground)
    )
    val paletteItems = remember(paletteLabelVersion, colors) { paletteDefaults.map { (label, key, value) -> Triple(store.get("palette_label_$key", label), key, value) } }

    LazyColumn(Modifier.fillMaxSize().padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        item {
            Text("Настройка цветов", style = MaterialTheme.typography.titleMedium)
        }
        item {
            Text(
                store.get("color_section_ready_themes", "Готовые темы"),
                style = MaterialTheme.typography.titleMedium,
                modifier = Modifier.pointerInput(paletteLabelVersion) {
                    detectTapGestures(onLongPress = {
                        renameSectionKey = "color_section_ready_themes"
                        sectionName = store.get("color_section_ready_themes", "Готовые темы")
                    })
                }
            )
            Text("Выберите готовое оформление одним нажатием.", style = MaterialTheme.typography.bodySmall)
        }
        items(colorThemePresets().chunked(2)) { row ->
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                row.forEach { preset ->
                    val isSelected = preset.colors == colors
                    OutlinedButton(onClick = { colors = preset.colors; preset.colors.saveTo(store); onColorsChanged() }, modifier = Modifier.weight(1f), contentPadding = PaddingValues(8.dp), border = androidx.compose.foundation.BorderStroke(if (isSelected) 2.dp else 1.dp, if (isSelected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.outline)) {
                        Surface(Modifier.size(28.dp), color = colorFromHex(preset.colors.primary), shape = MaterialTheme.shapes.small) {}
                        Spacer(Modifier.width(8.dp)); Text(preset.name, maxLines = 1)
                    }
                }
                if (row.size == 1) Spacer(Modifier.weight(1f))
            }
        }
        item {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedButton(onClick = { colors = defaults; defaults.saveTo(store); onColorsChanged() }, modifier = Modifier.fillMaxWidth()) { Text("Сбросить") }
            }
        }
        item {
            Text(
                store.get("color_section_my_themes", "Мои темы"),
                style = MaterialTheme.typography.titleMedium,
                modifier = Modifier.pointerInput(paletteLabelVersion) {
                    detectTapGestures(onLongPress = {
                        renameSectionKey = "color_section_my_themes"
                        sectionName = store.get("color_section_my_themes", "Мои темы")
                    })
                }
            )
        }
        items(savedThemes.withIndex().toList().chunked(2)) { rowThemes ->
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                rowThemes.forEach { indexed ->
                    val index = indexed.index
                    val theme = indexed.value
                    val isSelected = theme.colors == colors
                    Surface(
                        modifier = Modifier.weight(1f).heightIn(min = 48.dp),
                        shape = MaterialTheme.shapes.small,
                        tonalElevation = 0.dp,
                        border = androidx.compose.foundation.BorderStroke(if (isSelected) 2.dp else 1.dp, if (isSelected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.outline)
                    ) {
                        Row(Modifier.fillMaxWidth().heightIn(min = 48.dp).padding(start = 8.dp, end = 2.dp), verticalAlignment = Alignment.CenterVertically) {
                            Row(
                                modifier = Modifier.weight(1f).pointerInput(index, theme.name) {
                                    detectTapGestures(
                                        onTap = {
                                            colors = theme.colors
                                            theme.colors.saveTo(store)
                                            onColorsChanged()
                                        },
                                        onLongPress = {
                                            renameThemeIndex = index
                                            themeName = theme.name
                                        }
                                    )
                                }.padding(vertical = 6.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Surface(Modifier.size(24.dp), color = colorFromHex(theme.colors.primary), shape = MaterialTheme.shapes.extraSmall) {}
                                Spacer(Modifier.width(6.dp))
                                Text(theme.name, maxLines = 1, overflow = TextOverflow.Ellipsis, style = MaterialTheme.typography.labelMedium)
                            }
                            IconButton(onClick = { deleteThemeIndex = index }, modifier = Modifier.size(36.dp)) {
                                Icon(Icons.Filled.Delete, contentDescription = "Удалить тему", modifier = Modifier.size(18.dp))
                            }
                        }
                    }
                }
                if (rowThemes.size == 1) Spacer(Modifier.weight(1f))
            }
        }
        item {
            Button(onClick = { themeName = ""; saveThemeDialog = true }, modifier = Modifier.fillMaxWidth()) {
                Text("Добавить свою тему")
            }
        }
        item {
            Text(
                store.get("color_section_palette", "Цвета элементов приложения"),
                style = MaterialTheme.typography.titleMedium,
                modifier = Modifier.pointerInput(paletteLabelVersion) {
                    detectTapGestures(onLongPress = {
                        renameSectionKey = "color_section_palette"
                        sectionName = store.get("color_section_palette", "Цвета элементов приложения")
                    })
                }
            )
        }
        item {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                paletteItems.forEach { (label, key, value) ->
                    OutlinedButton(onClick = { pickerKey = key }, modifier = Modifier.fillMaxWidth(), contentPadding = PaddingValues(10.dp)) {
                        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                            Surface(Modifier.size(38.dp), color = colorFromHex(value), shape = MaterialTheme.shapes.small) {}
                            Spacer(Modifier.width(12.dp))
                            Text(label, modifier = Modifier.weight(1f).pointerInput(key, label) {
                                detectTapGestures(onLongPress = {
                                    renamePaletteKey = key
                                    paletteName = label
                                })
                            }, textAlign = androidx.compose.ui.text.style.TextAlign.Start)
                            Text("Выбрать", style = MaterialTheme.typography.bodySmall)
                        }
                    }
                }
            }
        }
        item {
            Surface(Modifier.fillMaxWidth(), color = colors.color(colors.headerBackground, MaterialTheme.colorScheme.primaryContainer), shape = MaterialTheme.shapes.medium) {
                Column(Modifier.padding(12.dp)) {
                    Text("Пример stickyHeader", color = colors.color(colors.headerText, MaterialTheme.colorScheme.onPrimaryContainer), style = MaterialTheme.typography.titleMedium)
                    Text("Кв. 1", color = colors.color(colors.headerText, MaterialTheme.colorScheme.onPrimaryContainer), style = MaterialTheme.typography.bodySmall)
                    Text("Адрес квартиры", color = colors.color(colors.headerText, MaterialTheme.colorScheme.onPrimaryContainer), style = MaterialTheme.typography.titleMedium)
                }
            }
        }
    }

    pickerKey?.let { key ->
        val current = paletteItems.first { it.second == key }.third
        PaletteColorDialog(colorTitle = paletteItems.first { it.second == key }.first, initial = current, onSelect = { set(key, it) }, onDismiss = { pickerKey = null })
    }

    if (saveThemeDialog || renameThemeIndex >= 0) {
        val renaming = renameThemeIndex >= 0
        AlertDialog(
            onDismissRequest = { saveThemeDialog = false; renameThemeIndex = -1 },
            title = { Text(if (renaming) "Переименовать тему" else "Сохранить свою тему") },
            text = {
                OutlinedTextField(value = themeName, onValueChange = { themeName = it }, label = { Text("Название темы") }, singleLine = true, modifier = Modifier.fillMaxWidth())
            },
            confirmButton = {
                Button(onClick = {
                    val name = themeName.trim().ifBlank { "Моя тема" }
                    if (renaming) {
                        savedThemes = savedThemes.mapIndexed { i, t -> if (i == renameThemeIndex) t.copy(name = name) else t }
                    } else {
                        savedThemes = listOf(SavedColorTheme(name, colors)) + savedThemes
                    }
                    saveSavedColorThemes(store, savedThemes)
                    saveThemeDialog = false; renameThemeIndex = -1; themeName = ""
                }) { Text(if (renaming) "Переименовать" else "Сохранить") }
            },
            dismissButton = { TextButton(onClick = { saveThemeDialog = false; renameThemeIndex = -1 }) { Text("Отмена") } }
        )
    }

    if (renameSectionKey != null) {
        AlertDialog(
            onDismissRequest = { renameSectionKey = null },
            title = { Text("Переименовать заголовок") },
            text = {
                OutlinedTextField(value = sectionName, onValueChange = { sectionName = it }, label = { Text("Название") }, singleLine = true, modifier = Modifier.fillMaxWidth())
            },
            confirmButton = {
                Button(onClick = {
                    renameSectionKey?.let { key ->
                        val fallback = when (key) {
                            "color_section_ready_themes" -> "Готовые темы"
                            "color_section_my_themes" -> "Мои темы"
                            else -> "Цвета элементов приложения"
                        }
                        store.put(key, sectionName.trim().ifBlank { fallback })
                    }
                    paletteLabelVersion++
                    renameSectionKey = null
                }) { Text("Сохранить") }
            },
            dismissButton = { TextButton(onClick = { renameSectionKey = null }) { Text("Отмена") } }
        )
    }

    if (renamePaletteKey != null) {
        AlertDialog(
            onDismissRequest = { renamePaletteKey = null },
            title = { Text("Переименовать заголовок") },
            text = {
                OutlinedTextField(value = paletteName, onValueChange = { paletteName = it }, label = { Text("Название") }, singleLine = true, modifier = Modifier.fillMaxWidth())
            },
            confirmButton = {
                Button(onClick = {
                    val key = renamePaletteKey
                    if (key != null) {
                        val fallback = paletteDefaults.first { it.second == key }.first
                        store.put("palette_label_$key", paletteName.trim().ifBlank { fallback })
                        paletteLabelVersion++
                    }
                    renamePaletteKey = null
                }) { Text("Сохранить") }
            },
            dismissButton = { TextButton(onClick = { renamePaletteKey = null }) { Text("Отмена") } }
        )
    }

    if (deleteThemeIndex >= 0) {
        val theme = savedThemes.getOrNull(deleteThemeIndex)
        if (theme != null) {
            AlertDialog(
                onDismissRequest = { deleteThemeIndex = -1 },
                title = { Text("Удалить тему?") },
                text = { Text("Удалить тему «${theme.name}»? Это действие нельзя отменить.") },
                confirmButton = {
                    Button(onClick = {
                        savedThemes = savedThemes.filterIndexed { i, _ -> i != deleteThemeIndex }
                        saveSavedColorThemes(store, savedThemes)
                        deleteThemeIndex = -1
                    }) { Text("Удалить") }
                },
                dismissButton = { TextButton(onClick = { deleteThemeIndex = -1 }) { Text("Отмена") } }
            )
        } else {
            deleteThemeIndex = -1
        }
    }
}

private fun saveGasReportAsDoc(context: Context, uri: Uri, data: GasReportData) {
    context.contentResolver.openOutputStream(uri)?.use { it.write(gasReportHtml(data).toByteArray(Charsets.UTF_8)) }
}

private fun saveGasReportAsExcel(context: Context, uri: Uri, data: GasReportData) {
    context.contentResolver.openOutputStream(uri)?.use { it.write(gasReportHtml(data).toByteArray(Charsets.UTF_8)) }
}

private fun saveGasReportAsImage(context: Context, uri: Uri, data: GasReportData) {
    val bitmap = Bitmap.createBitmap(1200, 520, Bitmap.Config.ARGB_8888)
    val canvas = Canvas(bitmap)
    canvas.drawColor(android.graphics.Color.WHITE)
    val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = android.graphics.Color.BLACK; textSize = 34f }
    canvas.drawText("Отчёт по газу — ${data.apartment}", 60f, 70f, paint)
    paint.textSize = 25f
    canvas.drawText(data.address, 60f, 115f, paint)
    paint.textSize = 28f
    canvas.drawText("Газоснабжение:", 70f, 205f, paint); canvas.drawText(data.supply, 560f, 205f, paint)
    canvas.drawText("Техобслуживание:", 70f, 285f, paint); canvas.drawText(data.maintenance, 560f, 285f, paint)
    paint.textSize = 22f
    canvas.drawText("Дата и время выгрузки: ${data.generatedAt}", 60f, 365f, paint)
    context.contentResolver.openOutputStream(uri)?.use { bitmap.compress(Bitmap.CompressFormat.PNG, 100, it) }
    bitmap.recycle()
}

private fun gasReportKey(id: Int, field: String) = "gas_report_${field}_$id"

@Composable
private fun ApartmentSummaryScreen(apartment: Apartment?, apartmentId: Int, store: LocalStore, refreshVersion: Int, onBack: () -> Unit) {
    val id = apartmentId
    val address = apartment?.let { store.apartmentAddress(it) }.orEmpty()
    val electricityAt = store.get(electricityReportKey(id, "generated")).ifBlank { "Не выгружался" }
    val electricity = listOfNotNull(
        store.get(electricityReportKey(id, "debt")).takeIf { it.isNotBlank() && it != "Не получено" }?.let { "Задолженность: $it" },
        store.get(electricityReportKey(id, "accrued")).takeIf { it.isNotBlank() && it != "Не получено" }?.let { "Начислено: $it" },
        store.get(electricityReportKey(id, "paid")).takeIf { it.isNotBlank() && it != "Не получено" }?.let { "Оплачено: $it" },
        store.get(electricityReportKey(id, "reading")).takeIf { it.isNotBlank() && it != "Не получено" }?.let { "Последнее показание: $it" },
        "${store.get(electricityReportKey(id, "overpayment_label")).ifBlank { "Переплата" }}: ${store.get(electricityReportKey(id, "overpayment")).ifBlank { "Не получено" }}",
        "${store.get(electricityReportKey(id, "debt_label")).ifBlank { "Задолженность" }}: ${store.get(electricityReportKey(id, "cabinet_debt")).ifBlank { "Не получено" }}",
        "${store.get(electricityReportKey(id, "penalty_label")).ifBlank { "Пеня" }}: ${store.get(electricityReportKey(id, "penalty")).ifBlank { "Не получено" }}"
    )
    val waterAt = store.get(waterReportKey(id, "generated")).ifBlank { "Не сохранено" }
    val water = listOf(
        "Переплата: ${store.get(waterReportKey(id, "overpayment")).ifBlank { "Не получено" }}",
        "Задолженность: ${store.get(waterReportKey(id, "debt")).ifBlank { "Не получено" }}",
        "Пеня: ${store.get(waterReportKey(id, "penalty")).ifBlank { "Не получено" }}"
    )
    val gasAt = store.get(gasReportKey(id, "generated")).ifBlank { "Не выгружался" }
    val gas = listOf(
        "Газоснабжение: ${store.get(gasReportKey(id, "supply")).ifBlank { "Не получено" }}",
        "Техобслуживание: ${store.get(gasReportKey(id, "maintenance")).ifBlank { "Не получено" }}"
    )
    val apartmentLabel = store.get("apartment_label_$id", "Квартира $id").ifBlank { "Квартира $id" }
    val summaryTitle = "Сводный отчёт — $apartmentLabel${if (address.isNotBlank()) " — $address" else ""}"
    Scaffold(topBar = { TopAppBar(title = { Text("") }, navigationIcon = { TextButton(onClick = onBack) { Text("Назад") } }) }) { padding ->
        LazyColumn(Modifier.padding(padding).padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            item { Text("$apartmentLabel${if (address.isNotBlank()) " — $address" else " — Адрес не указан в настройках"}", style = MaterialTheme.typography.titleLarge) }
            item { Divider() }
            item { Text("Свет", style = MaterialTheme.typography.titleMedium) }
            items(electricity) { Text(it) }
            item { Text("Дата и время выгрузки из ЛК: $electricityAt", style = MaterialTheme.typography.bodySmall) }
            item { Divider() }
            item { Text("Вода", style = MaterialTheme.typography.titleMedium) }
            items(water) { Text(it) }
            item { Text("Дата и время выгрузки из ЛК: $waterAt", style = MaterialTheme.typography.bodySmall) }
            item { Divider() }
            item { Text("Газ", style = MaterialTheme.typography.titleMedium) }
            items(gas) { Text(it) }
            item { Text("Дата и время выгрузки из ЛК: $gasAt", style = MaterialTheme.typography.bodySmall) }
            item { Text("Сводка показывает данные, уже сохранённые в соответствующих отчётах. Чтобы обновить значения, сначала обновите отчёт по нужной услуге.", style = MaterialTheme.typography.bodySmall) }
        }
    }
}

@Composable
private fun ReportsHubScreen(
    store: LocalStore,
    apartments: List<Apartment>,
    onElectricity: () -> Unit,
    onWater: () -> Unit,
    onGas: () -> Unit,
    onApartmentSummary: (Int) -> Unit,
    onBack: () -> Unit
) {
    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Отчёты") },
                navigationIcon = { TextButton(onClick = onBack) { Text("Назад") } }
            )
        }
    ) { padding ->
        LazyColumn(
            Modifier.padding(padding).padding(12.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            item {
                Button(onClick = onElectricity, modifier = Modifier.fillMaxWidth()) {
                    Text("Отчёт по свету")
                }
            }
            item {
                Button(onClick = onWater, modifier = Modifier.fillMaxWidth()) {
                    Text("Отчёт по воде")
                }
            }
            item {
                Button(onClick = onGas, modifier = Modifier.fillMaxWidth()) {
                    Text("Отчёт по газу")
                }
            }
            items(apartments.sortedBy { it.id }) { apartment ->
                val id = apartment.id
                val summaryAddress = store.apartmentAddress(apartment)
                val summaryLabel = store.get("apartment_label_$id", "Квартира $id").ifBlank { "Квартира $id" }
                val summaryButtonText = "Сводный отчёт\n$summaryLabel${if (summaryAddress.isNotBlank()) " — $summaryAddress" else ""}"
                Button(onClick = { onApartmentSummary(id) }, modifier = Modifier.fillMaxWidth().height(48.dp)) {
                    Text(summaryButtonText, style = MaterialTheme.typography.labelLarge, lineHeight = 16.sp, maxLines = 2, softWrap = true)
                }
            }
        }
    }
}
