@file:OptIn(ExperimentalMaterial3Api::class)
package ru.chetchiki.app

import android.annotation.SuppressLint
import android.app.Activity
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Typeface
import android.net.Uri
import android.os.Bundle
import android.os.SystemClock
import java.io.OutputStream
import java.io.BufferedReader
import java.io.InputStreamReader
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import android.view.MotionEvent
import android.webkit.WebView
import android.webkit.WebViewClient
import android.webkit.WebChromeClient
import org.json.JSONObject
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.rememberScrollState
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.viewinterop.AndroidView
import androidx.compose.ui.platform.LocalContext

enum class MeterType { ELECTRICITY, WATER, GAS }

data class Meter(
    val id: Int,
    val type: MeterType,
    val title: String,
    val serial: String = "",
    val reading: String = "",
    val status: String = "Не передано"
)

data class Apartment(val id: Int, val address: String, val meters: List<Meter>)

data class Credentials(
    val energySurname: String = "",
    val energyAccount: String = "",
    val energySerial: String = "",
    val waterLogin: String = "",
    val waterPassword: String = "",
    val gasLogin: String = "",
    val gasPassword: String = ""
)

data class Job(
    val apartmentId: Int,
    val address: String,
    val meterId: Int,
    val type: MeterType,
    val title: String,
    val reading: String,
    val serial: String = "",
    val credentials: Credentials = Credentials(),
    val providerUrl: String = ""
)

private const val ENERGY = "https://sevenergosbyt.ru/flk/index.php"
private const val WATER = "https://sevvodokanal.org.ru/app/webroot/account.php"
private const val GAS = "https://lk.gup-sevgaz.ru:8080/irb/login.xhtml"
private const val APP_VERSION = "2.15"

private fun defaultApartments() = listOf(
    Apartment(1, "Адрес квартиры 1", listOf(
        Meter(1, MeterType.ELECTRICITY, "Электричество №1"), Meter(2, MeterType.WATER, "Вода №1"), Meter(3, MeterType.WATER, "Вода №2"), Meter(4, MeterType.GAS, "Газ")
    )),
    Apartment(2, "Адрес квартиры 2", listOf(
        Meter(5, MeterType.ELECTRICITY, "Электричество №1"), Meter(6, MeterType.WATER, "Вода"), Meter(7, MeterType.GAS, "Газ")
    )),
    Apartment(3, "Адрес квартиры 3", listOf(
        Meter(8, MeterType.ELECTRICITY, "Электричество №1"), Meter(9, MeterType.WATER, "Вода"), Meter(10, MeterType.GAS, "Газ")
    )),
    Apartment(4, "Адрес квартиры 4", listOf(
        Meter(11, MeterType.ELECTRICITY, "Электричество №1"), Meter(12, MeterType.WATER, "Вода №1"), Meter(13, MeterType.WATER, "Вода №2"), Meter(14, MeterType.GAS, "Газ")
    ))
)

private fun newApartment(id: Int) = Apartment(id, "Адрес квартиры $id", listOf(
    Meter(id * 100 + 1, MeterType.ELECTRICITY, "Электричество №1"),
    Meter(id * 100 + 2, MeterType.WATER, "Вода"),
    Meter(id * 100 + 3, MeterType.GAS, "Газ")
))

// ГАЗ КВАРТИР 1–4: единый автоматический вход и подготовка показания
class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { MeterApp(applicationContext) }
    }
}

private class LocalStore(context: Context) {
    private val p = context.getSharedPreferences("meter_store", Context.MODE_PRIVATE)
    fun get(k: String, d: String = "") = p.getString(k, d) ?: d
    fun put(k: String, v: String) { p.edit().putString(k, v).commit() }
    fun gasCookies(id: Int): String = get("gas_cookies_$id")
    fun putGasCookies(id: Int, v: String) { p.edit().putString("gas_cookies_$id", v).apply() }
    fun commitAddress(k: String, v: String) { p.edit().putString(k, v).commit() }
    fun apartmentIds(): List<Int> {
        val saved = get("apartment_ids")
        if (saved.isBlank()) {
            val ids = defaultApartments().map { it.id }
            p.edit().putString("apartment_ids", ids.joinToString(",")).commit()
            return ids
        }
        return saved.split(",").mapNotNull { it.trim().toIntOrNull() }.distinct().sorted()
    }
    fun saveApartmentIds(ids: List<Int>) { p.edit().putString("apartment_ids", ids.distinct().sorted().joinToString(",")).commit() }
    fun providerUrl(id: Int, type: MeterType): String = get("provider_url_${type.name}_$id", when (type) { MeterType.ELECTRICITY -> ENERGY; MeterType.WATER -> WATER; MeterType.GAS -> GAS })
    fun saveProviderUrl(id: Int, type: MeterType, value: String) { put("provider_url_${type.name}_$id", value) }
    fun meterIds(id: Int, fallback: List<Meter>): List<Int> {
        val saved = get("meter_ids_$id")
        if (saved.isBlank()) {
            val ids = fallback.map { it.id }
            put("meter_ids_$id", ids.joinToString(","))
            return ids
        }
        return saved.split(",").mapNotNull { it.trim().toIntOrNull() }.distinct()
    }
    fun saveMeterIds(id: Int, ids: List<Int>) { put("meter_ids_$id", ids.distinct().joinToString(",")) }
    fun meterType(id: Int, meterId: Int, fallback: MeterType): MeterType = try { MeterType.valueOf(get("meter_type_${id}_$meterId", fallback.name)) } catch (_: Exception) { fallback }
    fun meterTitle(id: Int, meterId: Int, fallback: String): String = get("meter_title_${id}_$meterId", fallback)
    fun saveMeter(id: Int, meter: Meter) {
        put("meter_type_${id}_${meter.id}", meter.type.name)
        put("meter_title_${id}_${meter.id}", meter.title)
    }
    fun previousReading(meterId: Int): String = get("previous_reading_$meterId")
    fun savePreviousReading(meterId: Int, value: String) { if (value.isNotBlank()) put("previous_reading_$meterId", value) }
    fun clearReading(meterId: Int) {
        val current = get("reading_$meterId")
        if (current.isNotBlank()) savePreviousReading(meterId, current)
        p.edit().remove("reading_$meterId").putString("status_$meterId", "Не передано").apply()
    }
    fun deleteMeterData(meterId: Int) { p.edit().remove("reading_$meterId").remove("previous_reading_$meterId").remove("serial_$meterId").remove("status_$meterId").apply() }
    fun waterLogin(id: Int): String = get("water_login_$id")
    fun credentials(id: Int) = Credentials(
        get("energy_surname_$id"), get("energy_account_$id"), get("energy_serial_$id"),
        waterLogin(id), get("water_password_$id"), get("gas_login_$id"), get("gas_password_$id")
    )

    fun exportJson(): String {
        val root = JSONObject()
        root.put("format", "chetchiki-settings")
        root.put("formatVersion", 1)
        val values = JSONObject()
        p.all.forEach { (key, value) ->
            when (value) {
                is String -> values.put(key, value)
                is Boolean -> values.put(key, value)
                is Int -> values.put(key, value)
                is Long -> values.put(key, value)
                is Float -> values.put(key, value.toDouble())
            }
        }
        root.put("values", values)
        return root.toString(2)
    }

    fun importJson(json: String) {
        val root = JSONObject(json)
        require(root.optString("format") == "chetchiki-settings") { "Неверный файл настроек" }
        val values = root.optJSONObject("values") ?: error("В файле нет настроек")
        val editor = p.edit().clear()
        val keys = values.keys()
        while (keys.hasNext()) {
            val key = keys.next()
            when (val value = values.get(key)) {
                is String -> editor.putString(key, value)
                is Boolean -> editor.putBoolean(key, value)
                is Int -> editor.putInt(key, value)
                is Long -> editor.putLong(key, value)
                is Double -> editor.putFloat(key, value.toFloat())
            }
        }
        check(editor.commit()) { "Не удалось сохранить настройки" }
    }
}

@Composable
fun MeterApp(context: Context) {
    val store = remember { LocalStore(context) }
    var apartments by remember {
        mutableStateOf(store.apartmentIds().map { id ->
            val base = defaultApartments().firstOrNull { it.id == id } ?: newApartment(id)
            val baseById = base.meters.associateBy { it.id }
            val ids = store.meterIds(id, base.meters)
            val configuredMeters = ids.mapNotNull { meterId ->
                val fallback = baseById[meterId]
                if (fallback != null) fallback else {
                    val type = store.meterType(id, meterId, MeterType.WATER)
                    val title = store.meterTitle(id, meterId, if (type == MeterType.ELECTRICITY) "Электричество №1" else "Вода")
                    Meter(meterId, type, title)
                }
            }.map { m -> m.copy(type = store.meterType(id, m.id, m.type), title = store.meterTitle(id, m.id, m.title), serial = store.get("serial_${m.id}"), reading = store.get("reading_${m.id}"), status = store.get("status_${m.id}", "Не передано")) }
            base.copy(address = store.get("address_${id}", base.address), meters = configuredMeters)
        })
    }
    var credentialsVersion by remember { mutableIntStateOf(0) }
    var jobs by remember { mutableStateOf(listOf<Job>()) }
    var activeJobIndex by remember { mutableIntStateOf(0) }
    var webUrl by remember { mutableStateOf<String?>(null) }
    var webViewRef by remember { mutableStateOf<WebView?>(null) }
    var settings by remember { mutableStateOf(false) }
    var help by remember { mutableStateOf(false) }
    var waterReport by remember { mutableStateOf(false) }
    var gasReport by remember { mutableStateOf(false) }
    var gasReportFetchApartmentId by remember { mutableStateOf<Int?>(null) }
    var gasReportAllFetch by remember { mutableStateOf(false) }
    var gasReportAllIndex by remember { mutableIntStateOf(0) }
    var gasReportAllScreen by remember { mutableStateOf(false) }
    var gasReportApartmentScreenId by remember { mutableStateOf<Int?>(null) }
    var gasReportRefreshVersion by remember { mutableIntStateOf(0) }
    var waterReportFetchApartmentId by remember { mutableStateOf<Int?>(null) }
    var waterReportAllFetch by remember { mutableStateOf(false) }
    var waterReportAllIndex by remember { mutableIntStateOf(0) }
    var waterReportAllScreen by remember { mutableStateOf(false) }
    var waterReportApartmentScreenId by remember { mutableStateOf<Int?>(null) }
    var waterReportRefreshVersion by remember { mutableIntStateOf(0) }
    val activity = LocalContext.current as? Activity
    val exportLauncher = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
        if (result.resultCode == Activity.RESULT_OK) {
            result.data?.data?.let { uri ->
                runCatching {
                    context.contentResolver.openOutputStream(uri)?.use { output ->
                        output.write(store.exportJson().toByteArray(Charsets.UTF_8))
                    } ?: error("Не удалось открыть файл")
                }
            }
        }
    }
    val importLauncher = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
        if (result.resultCode == Activity.RESULT_OK) {
            result.data?.data?.let { uri ->
                runCatching {
                    val json = context.contentResolver.openInputStream(uri)?.use { it.readBytes().toString(Charsets.UTF_8) }
                        ?: error("Не удалось открыть файл")
                    store.importJson(json)
                    activity?.recreate()
                }
            }
        }
    }

    fun updateMeter(apartmentId: Int, meterId: Int, reading: String? = null, serial: String? = null, status: String? = null) {
        apartments = apartments.map { a -> if (a.id != apartmentId) a else a.copy(meters = a.meters.map { m -> if (m.id != meterId) m else m.copy(reading = reading ?: m.reading, serial = serial ?: m.serial, status = status ?: m.status) }) }
        if (reading != null) store.put("reading_$meterId", reading)
        if (serial != null) store.put("serial_$meterId", serial)
        if (status != null) store.put("status_$meterId", status)
    }
    fun updateStatus(job: Job, status: String) = updateMeter(job.apartmentId, job.meterId, status = status)
    fun clearMeterReading(apartmentId: Int, meterId: Int) {
        apartments = apartments.map { a -> if (a.id != apartmentId) a else a.copy(meters = a.meters.map { m -> if (m.id == meterId) m.copy(reading = "", status = "Не передано") else m }) }
        store.clearReading(meterId)
    }
    fun clearApartmentReadings(apartmentId: Int) {
        val apartment = apartments.firstOrNull { it.id == apartmentId } ?: return
        apartment.meters.forEach { store.clearReading(it.id) }
        apartments = apartments.map { a -> if (a.id != apartmentId) a else a.copy(meters = a.meters.map { it.copy(reading = "", status = "Не передано") }) }
    }
    fun clearAllReadings() {
        apartments.flatMap { it.meters }.forEach { store.clearReading(it.id) }
        apartments = apartments.map { a -> a.copy(meters = a.meters.map { it.copy(reading = "", status = "Не передано") }) }
    }

    fun makeJob(a: Apartment, m: Meter): Job {
        // Критично: учётные данные всегда принадлежат выбранной квартире.
        // Раньше здесь для света и газа был ошибочный hard-code credentials(1),
        // из-за чего после переключения квартиры оставался ЛК предыдущей квартиры.
        // Алгоритм передачи света/газа общий, но credentials — выбранной квартиры.
        val credentials = store.credentials(a.id)
        return Job(a.id, a.address, m.id, m.type, m.title, m.reading, m.serial, credentials, store.providerUrl(a.id, m.type))
    }

    // Единый алгоритм передачи для каждой квартиры:
    // 1) электричество -> 2) вода -> 3) газ.
    // Порядок не зависит от того, как счётчики записаны в конфигурации квартиры.
    fun orderedJobs(a: Apartment, meters: List<Meter> = a.meters): List<Job> {
        val order = listOf(MeterType.ELECTRICITY, MeterType.WATER, MeterType.GAS)
        return order.flatMap { type ->
            meters.filter { it.type == type }.map { makeJob(a, it) }
        }
    }

    fun startJobs(newJobs: List<Job>) {
        if (newJobs.isNotEmpty()) {
            jobs = newJobs
            activeJobIndex = 0
            webUrl = newJobs[0].providerUrl
        }
    }
    fun nextJob() { val next = activeJobIndex + 1; if (next >= jobs.size) { webUrl = null } else { activeJobIndex = next; webUrl = jobs[next].providerUrl } }

    if (help) {
        Scaffold(
            topBar = {
                TopAppBar(
                    title = { Text("Справка") },
                    navigationIcon = { TextButton(onClick = { help = false }) { Text("Назад") } }
                )
            }
        ) { padding ->
            Column(Modifier.fillMaxSize().padding(padding).padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Text("Счётчики", style = MaterialTheme.typography.titleLarge)
                Text("Версия приложения: $APP_VERSION", style = MaterialTheme.typography.bodyLarge)
                Text("Здесь будет размещена подробная справка по работе приложения.", style = MaterialTheme.typography.bodyMedium)
            }
        }
        return
    }

    if (settings) {
        SettingsScreen(
            apartments = apartments,
            store = store,
            onUpdateAddress = { id, value -> apartments = apartments.map { if (it.id == id) it.copy(address = value) else it }; store.commitAddress("address_$id", value) },
            onUpdateSerial = { id, value -> apartments = apartments.map { a -> a.copy(meters = a.meters.map { m -> if (m.id == id) m.copy(serial = value) else m }) }; store.put("serial_$id", value) },
            onUpdateTitle = { id, value -> apartments = apartments.map { a -> a.copy(meters = a.meters.map { m -> if (m.id == id) m.copy(title = value) else m }) } },
            onAddMeter = addMeter@{ apartmentId, type ->
                val apartment = apartments.firstOrNull { it.id == apartmentId }
                if (apartment == null) return@addMeter
                val newMeterId = (apartments.flatMap { it.meters }.maxOfOrNull { it.id } ?: 0) + 1
                val count = apartment.meters.count { it.type == type } + 1
                val title = if (type == MeterType.ELECTRICITY) { "Электричество №$count" } else { "Вода №$count" }
                val meter = Meter(newMeterId, type, title)
                val orderedMeters = buildList {
                    addAll(apartment.meters.filter { it.type == MeterType.ELECTRICITY })
                    if (type == MeterType.ELECTRICITY) add(meter)
                    addAll(apartment.meters.filter { it.type == MeterType.WATER })
                    if (type == MeterType.WATER) add(meter)
                    addAll(apartment.meters.filter { it.type == MeterType.GAS })
                }
                apartments = apartments.map { if (it.id == apartmentId) it.copy(meters = orderedMeters) else it }
                store.saveMeter(apartmentId, meter)
                store.saveMeterIds(apartmentId, apartments.first { it.id == apartmentId }.meters.map { it.id })
            },
            onDeleteMeter = deleteMeter@{ apartmentId, meterId ->
                val apartment = apartments.firstOrNull { it.id == apartmentId }
                if (apartment == null) return@deleteMeter
                val meter = apartment.meters.firstOrNull { it.id == meterId }
                if (meter == null || (meter.type != MeterType.ELECTRICITY && meter.type != MeterType.WATER)) return@deleteMeter
                val remaining = apartment.meters.filterNot { it.id == meterId }
                apartments = apartments.map { if (it.id == apartmentId) it.copy(meters = remaining) else it }
                store.saveMeterIds(apartmentId, remaining.map { it.id })
                store.deleteMeterData(meterId)
            },
            onAddApartment = {
                val newId = ((apartments.maxOfOrNull { it.id } ?: 0) + 1)
                val added = newApartment(newId)
                apartments = apartments + added
                store.saveApartmentIds(apartments.map { it.id })
            },
            onDeleteApartment = { id ->
                if (apartments.size > 1) {
                    apartments = apartments.filterNot { it.id == id }
                    store.saveApartmentIds(apartments.map { it.id })
                }
            },
            onSaved = { credentialsVersion++ },
            onExportSettings = {
                val intent = Intent(Intent.ACTION_CREATE_DOCUMENT).apply {
                    addCategory(Intent.CATEGORY_OPENABLE)
                    type = "application/json"
                    putExtra(Intent.EXTRA_TITLE, "chetchiki-settings.json")
                }
                exportLauncher.launch(intent)
            },
            onImportSettings = {
                val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
                    addCategory(Intent.CATEGORY_OPENABLE)
                    type = "application/json"
                }
                importLauncher.launch(intent)
            },
            onBack = { settings = false }
        )
        return
    }

    if (gasReportApartmentScreenId != null) {
        val reportApartmentId = gasReportApartmentScreenId
        val reportApartment = apartments.firstOrNull { it.id == reportApartmentId }
        Column(Modifier.fillMaxSize()) {
            GasReportScreen(
                apartment = reportApartment,
                store = store,
                refreshVersion = gasReportRefreshVersion,
                onFetch = { id -> gasReportFetchApartmentId = id; gasReportApartmentScreenId = id; gasReport = false },
                onBack = { gasReportFetchApartmentId = null; gasReportApartmentScreenId = null; gasReport = true }
            )
            if (gasReportFetchApartmentId == reportApartmentId) {
                val a = reportApartment
                val gm = a?.meters?.firstOrNull { it.type == MeterType.GAS }
                if (a != null && gm != null) {
                    val reportJob = Job(a.id, store.apartmentAddress(a), gm.id, MeterType.GAS, gm.title, "", gm.serial, store.credentials(a.id), store.providerUrl(a.id, MeterType.GAS))
                    key("gas-report-fetch-${a.id}") {
                        ProviderScreen(
                            url = reportJob.providerUrl, job = reportJob, index = 1, total = 1, store = store,
                            reportMode = true, gasReportMode = true,
                            onGasReportData = { supply, maintenance, debt, over ->
                                store.put("gas_report_supply_${a.id}", supply)
                                store.put("gas_report_maintenance_${a.id}", maintenance)
                                store.put("gas_report_debt_${a.id}", debt)
                                store.put("gas_report_overpayment_${a.id}", over)
                                gasReportRefreshVersion++
                                if (gasReportAllFetch) {
                                    val ids = apartments.filter { ap ->
                                        ap.meters.any { it.type == MeterType.GAS } &&
                                            store.credentials(ap.id).gasLogin.isNotBlank() && store.credentials(ap.id).gasPassword.isNotBlank()
                                    }.map { it.id }
                                    val next = gasReportAllIndex + 1
                                    if (next < ids.size) { gasReportAllIndex = next; gasReportApartmentScreenId = ids[next]; gasReportFetchApartmentId = ids[next] }
                                    else { gasReportAllFetch = false; gasReportFetchApartmentId = null; gasReportApartmentScreenId = null; gasReportAllScreen = true }
                                } else gasReportFetchApartmentId = null
                            },
                            onWebViewReady = { webViewRef = it }, onStatus = {}, onNext = {}, onBack = {}
                        )
                    }
                }
            }
        }
        return
    }
    if (gasReportAllScreen) {
        GasReportAllScreen(apartments = apartments, store = store, onBack = { gasReportAllScreen = false; gasReport = true })
        return
    }
    if (gasReportFetchApartmentId != null || gasReportAllFetch) {
        val ids = apartments.filter { a ->
            a.meters.any { it.type == MeterType.GAS } &&
                store.credentials(a.id).gasLogin.isNotBlank() && store.credentials(a.id).gasPassword.isNotBlank()
        }.map { it.id }
        val targetId = if (gasReportAllFetch) ids.getOrNull(gasReportAllIndex) else gasReportFetchApartmentId
        val a = apartments.firstOrNull { it.id == targetId }
        if (a != null) { gasReportApartmentScreenId = a.id; gasReportFetchApartmentId = a.id; return }
        gasReportAllFetch = false; gasReportFetchApartmentId = null; gasReport = true; return
    }
    if (gasReport) {
        GasReportHubScreen(
            apartments = apartments, store = store,
            onFetchApartment = { id ->
                val a = apartments.firstOrNull { it.id == id }
                if (a != null && a.meters.any { it.type == MeterType.GAS } && store.credentials(id).gasLogin.isNotBlank() && store.credentials(id).gasPassword.isNotBlank()) {
                    gasReportApartmentScreenId = id; gasReportFetchApartmentId = id; gasReport = false
                }
            },
            onFetchAll = { val ids = apartments.filter { a -> a.meters.any { it.type == MeterType.GAS } && store.credentials(a.id).gasLogin.isNotBlank() && store.credentials(a.id).gasPassword.isNotBlank() }.map { it.id }; gasReportAllIndex = 0; gasReportAllFetch = ids.isNotEmpty(); gasReport = false },
            onBack = { gasReport = false }
        )
        return
    }

    // Water report UI stays visible while the hidden WebView fetches the data.
    // This avoids replacing the report screen with a blank WebView during loading.
    if (waterReportApartmentScreenId != null) {
        val reportApartmentId = waterReportApartmentScreenId
        val reportApartment = apartments.firstOrNull { it.id == reportApartmentId }
        Column(Modifier.fillMaxSize()) {
            WaterReportScreen(
                apartment = reportApartment,
                store = store,
                refreshVersion = waterReportRefreshVersion,
                onFetch = { id ->
                    waterReportFetchApartmentId = id
                    waterReportApartmentScreenId = id
                    waterReport = false
                },
                onBack = { 
                    waterReportFetchApartmentId = null
                    waterReportApartmentScreenId = null
                    waterReport = true
                }
            )
            if (waterReportFetchApartmentId == reportApartmentId) {
                val a = reportApartment
                val wm = a?.meters?.firstOrNull { it.type == MeterType.WATER }
                if (a != null && wm != null) {
                    val reportJob = Job(
                        apartmentId = a.id,
                        address = store.apartmentAddress(a),
                        meterId = wm.id,
                        type = MeterType.WATER,
                        title = wm.title,
                        reading = "",
                        serial = wm.serial,
                        credentials = store.credentials(a.id),
                        providerUrl = store.providerUrl(a.id, MeterType.WATER)
                    )
                    key("water-report-fetch-${a.id}") {
                        ProviderScreen(
                            url = reportJob.providerUrl,
                            job = reportJob,
                            index = 1,
                            total = 1,
                            store = store,
                            reportMode = true,
                            onReportData = { over, debt, penalty ->
                                store.put("water_report_overpayment_${a.id}", over)
                                store.put("water_report_debt_${a.id}", debt)
                                store.put("water_report_penalty_${a.id}", penalty)
                                waterReportRefreshVersion++
                                if (waterReportAllFetch) {
                                    val waterIds = apartments.filter { ap ->
                                            ap.meters.any { it.type == MeterType.WATER } &&
                                                store.waterLogin(ap.id).isNotBlank() &&
                                                store.get("water_password_${ap.id}").isNotBlank()
                                        }.map { it.id }
                                    val nextIndex = waterReportAllIndex + 1
                                    if (nextIndex < waterIds.size) {
                                        waterReportAllIndex = nextIndex
                                        waterReportApartmentScreenId = waterIds[nextIndex]
                                        waterReportFetchApartmentId = waterIds[nextIndex]
                                    } else {
                                        waterReportAllFetch = false
                                        waterReportFetchApartmentId = null
                                        waterReportApartmentScreenId = null
                                        waterReportAllScreen = true
                                    }
                                } else {
                                    waterReportFetchApartmentId = null
                                }
                            },
                            onWebViewReady = { webViewRef = it },
                            onStatus = {},
                            onNext = {},
                            onBack = {}
                        )
                    }
                }
            }
        }
        return
    }

    if (waterReportAllScreen) {
        WaterReportAllScreen(
            apartments = apartments,
            store = store,
            onBack = { waterReportAllScreen = false; waterReport = true }
        )
        return
    }

    if (waterReportFetchApartmentId != null || waterReportAllFetch) {
        // Для общего отчёта берём ТОЛЬКО квартиры, для которых действительно
        // настроены счётчик воды + логин + пароль. Раньше здесь попадали все
        // квартиры с водой, включая квартиры без ЛК, и общий отчёт останавливался
        // на первой такой квартире.
        val configuredWaterIds = apartments
            .filter { store.hasConfiguredWaterReport(it.id) }
            .map { it.id }

        val targetId = if (waterReportAllFetch) {
            configuredWaterIds.getOrNull(waterReportAllIndex)
        } else waterReportFetchApartmentId
        val a = apartments.firstOrNull { it.id == targetId }
        if (a != null) {
            waterReportApartmentScreenId = a.id
            waterReportFetchApartmentId = a.id
            return
        } else {
            waterReportAllFetch = false
            waterReportFetchApartmentId = null
            waterReport = true
            return
        }
    }

    if (waterReport) {
        WaterReportHubScreen(
            apartments = apartments,
            store = store,
            onFetchApartment = { id ->
                val a = apartments.firstOrNull { it.id == id }
                if (a != null && a.meters.any { it.type == MeterType.WATER } &&
                    store.waterLogin(id).isNotBlank() &&
                    store.get("water_password_$id").isNotBlank()) {
                    waterReportApartmentScreenId = id
                    waterReportFetchApartmentId = id
                    waterReport = false
                }
            },
            onFetchAll = {
                val configuredIds = apartments
                    .filter { store.hasConfiguredWaterReport(it.id) }
                    .map { it.id }
                waterReportAllIndex = 0
                waterReportAllFetch = configuredIds.isNotEmpty()
                waterReport = false
            },
            onBack = { waterReport = false }
        )
        return
    }

    if (webUrl != null && jobs.isNotEmpty()) {
        val job = jobs[activeJobIndex]
        ProviderScreen(url = webUrl!!, job = job, index = activeJobIndex + 1, total = jobs.size, store = store, onWebViewReady = { webViewRef = it }, onStatus = { updateStatus(job, it) }, onNext = { nextJob() }, onBack = { webUrl = null })
        return
    }

    Scaffold(topBar = { TopAppBar(title = { Text("Счётчики") }, actions = { TextButton(onClick = { waterReport = true }) { Text("Отчёт воды") }; TextButton(onClick = { gasReport = true }) { Text("Отчёт газа") }; TextButton(onClick = { settings = true }) { Text("Настройки") }; TextButton(onClick = { help = true }) { Text("Справка") }; TextButton(onClick = { activity?.finishAffinity() }) { Text("Выход") } }) }, bottomBar = {
        Button(onClick = { startJobs(apartments.flatMap { a -> orderedJobs(a) }) }, modifier = Modifier.fillMaxWidth().padding(12.dp)) { Text("Передать всё — все квартиры") }
    }) { padding ->
        Column(Modifier.fillMaxSize()) {
            Surface(Modifier.fillMaxWidth(), tonalElevation = 4.dp) {
                Text("Версия $APP_VERSION", modifier = Modifier.padding(16.dp), style = MaterialTheme.typography.headlineSmall)
            }
            LazyColumn(Modifier.weight(1f).padding(padding).padding(12.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            item {
                OutlinedButton(onClick = { clearAllReadings() }, modifier = Modifier.fillMaxWidth()) { Text("Очистить показания всех квартир") }
            }
            items(apartments, key = { it.id }) { apartment ->
                Card(Modifier.fillMaxWidth()) { Column(Modifier.padding(12.dp)) {
                    Text(apartment.address, style = MaterialTheme.typography.titleMedium)
                    Spacer(Modifier.height(8.dp))
                    val meterGroups = listOf(MeterType.ELECTRICITY, MeterType.WATER, MeterType.GAS)
                        .map { type -> type to apartment.meters.filter { it.type == type } }
                        .filter { it.second.isNotEmpty() }

                    meterGroups.forEach { (type, groupMeters) ->
                        val typeJobs = orderedJobs(apartment, groupMeters)
                        Column(
                            modifier = Modifier.fillMaxWidth(),
                            verticalArrangement = Arrangement.spacedBy(0.dp)
                        ) {
                            groupMeters.forEachIndexed { index, meter ->
                                val previous = store.previousReading(meter.id)
                                Box(modifier = Modifier.fillMaxWidth()) {
                                    OutlinedTextField(
                                        value = meter.reading,
                                        onValueChange = { v -> updateMeter(apartment.id, meter.id, reading = v, status = "Не передано") },
                                        label = { Text("${meter.title} — новое показание") },
                                        singleLine = true,
                                        modifier = Modifier.fillMaxWidth()
                                    )
                                    if (previous.isNotBlank()) {
                                        Text(
                                            text = "Предыдущее: $previous",
                                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                                            style = MaterialTheme.typography.bodySmall,
                                            maxLines = 1,
                                            softWrap = false,
                                            overflow = TextOverflow.Ellipsis,
                                            modifier = Modifier
                                                .align(Alignment.BottomStart)
                                                .padding(start = 16.dp, bottom = 6.dp)
                                        )
                                    }
                                }
                                if (meter.type == MeterType.WATER && meter.serial.isNotBlank()) {
                                    Text(
                                        text = "Заводской №: ${meter.serial}",
                                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                                        style = MaterialTheme.typography.bodySmall,
                                        maxLines = 1,
                                        softWrap = false,
                                        overflow = TextOverflow.Ellipsis,
                                        modifier = Modifier.padding(start = 16.dp, top = 2.dp, bottom = 2.dp)
                                    )
                                }
                                Row(
                                    Modifier
                                        .fillMaxWidth()
                                        .height(36.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text(
                                        meter.status,
                                        modifier = Modifier.weight(1f),
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis
                                    )
                                    if (index == groupMeters.lastIndex) {
                                        Button(
                                            onClick = { startJobs(typeJobs) },
                                            enabled = typeJobs.isNotEmpty(),
                                            contentPadding = PaddingValues(horizontal = 14.dp, vertical = 0.dp),
                                            modifier = Modifier.height(36.dp)
                                        ) {
                                            Text("Передать")
                                        }
                                    }
                                    TextButton(
                                        onClick = { clearMeterReading(apartment.id, meter.id) },
                                        contentPadding = PaddingValues(horizontal = 8.dp, vertical = 0.dp),
                                        modifier = Modifier.height(36.dp)
                                    ) {
                                        Text("Очистить")
                                    }
                                }
                            }
                        }
                    }
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedButton(onClick = { clearApartmentReadings(apartment.id) }, modifier = Modifier.weight(1f).height(40.dp)) { Text("Очистить всё") }
                        Button(onClick = { startJobs(orderedJobs(apartment)) }, modifier = Modifier.weight(1f).height(40.dp)) { Text("Передать всё") }
                    }
                } }
            }
        }
        }
    }
    @Suppress("UNUSED_VARIABLE") val _keep = credentialsVersion
}

@Composable
private fun SettingsScreen(
    apartments: List<Apartment>,
    store: LocalStore,
    onUpdateAddress: (Int, String) -> Unit,
    onUpdateSerial: (Int, String) -> Unit,
    onUpdateTitle: (Int, String) -> Unit,
    onAddMeter: (Int, MeterType) -> Unit,
    onDeleteMeter: (Int, Int) -> Unit,
    onAddApartment: () -> Unit,
    onDeleteApartment: (Int) -> Unit,
    onSaved: () -> Unit,
    onExportSettings: () -> Unit,
    onImportSettings: () -> Unit,
    onBack: () -> Unit
) {
    var selectedId by remember { mutableIntStateOf(apartments.firstOrNull()?.id ?: 1) }
    var address by remember { mutableStateOf("") }
    var apartmentLabel by remember { mutableStateOf("") }
    var showDeleteConfirmation by remember { mutableStateOf(false) }
    var showDeleteMeterConfirmation by remember { mutableStateOf(false) }
    var pendingDeleteMeterId by remember { mutableIntStateOf(-1) }
    var pendingDeleteMeterTitle by remember { mutableStateOf("") }
    var energySurname by remember { mutableStateOf("") }
    var energyAccount by remember { mutableStateOf("") }
    var energySerial by remember { mutableStateOf("") }
    var waterLogin by remember { mutableStateOf("") }
    var waterPassword by remember { mutableStateOf("") }
    var gasLogin by remember { mutableStateOf("") }
    var gasPassword by remember { mutableStateOf("") }
    var energyUrl by remember { mutableStateOf(ENERGY) }
    var waterUrl by remember { mutableStateOf(WATER) }
    var gasUrl by remember { mutableStateOf(GAS) }
    var showWaterPassword by remember { mutableStateOf(false) }
    var showGasPassword by remember { mutableStateOf(false) }
    val waterSerials = remember { mutableStateMapOf<Int, String>() }
    val meterTitles = remember { mutableStateMapOf<Int, String>() }

    fun loadApartment(id: Int) {
        val a = apartments.firstOrNull { it.id == id } ?: return
        selectedId = id
        address = store.get("address_$id", a.address)
        apartmentLabel = store.get("apartment_label_$id", "Кв. $id")
        energySurname = store.get("energy_surname_$id")
        energyAccount = store.get("energy_account_$id")
        energySerial = store.get("energy_serial_$id")
        waterLogin = store.waterLogin(id)
        waterPassword = store.get("water_password_$id")
        gasLogin = store.get("gas_login_$id")
        gasPassword = store.get("gas_password_$id")
        energyUrl = store.providerUrl(id, MeterType.ELECTRICITY)
        waterUrl = store.providerUrl(id, MeterType.WATER)
        gasUrl = store.providerUrl(id, MeterType.GAS)
        waterSerials.clear()
        meterTitles.clear()
        a.meters.filter { it.type == MeterType.WATER }.forEach { m ->
            waterSerials[m.id] = store.get("serial_${m.id}")
            meterTitles[m.id] = store.meterTitle(id, m.id, m.title)
        }
        showWaterPassword = false
        showGasPassword = false
    }

    LaunchedEffect(Unit) { loadApartment(selectedId) }

    fun saveApartment(id: Int = selectedId) {
        // IMPORTANT: only write fields when id is the currently displayed apartment.
        // This prevents a stale Compose field from being written to another apartment.
        if (id != selectedId) return
        store.commitAddress("address_$id", address)
        store.put("apartment_label_$id", apartmentLabel.trim().ifBlank { "Кв. $id" })
        onUpdateAddress(id, address)
        store.put("energy_surname_$id", energySurname)
        store.put("energy_account_$id", energyAccount)
        store.put("energy_serial_$id", energySerial)
        store.put("water_login_$id", waterLogin)
        store.put("water_password_$id", waterPassword)
        store.put("gas_login_$id", gasLogin)
        store.put("gas_password_$id", gasPassword)
        store.saveProviderUrl(id, MeterType.ELECTRICITY, energyUrl.trim().ifBlank { ENERGY })
        store.saveProviderUrl(id, MeterType.WATER, waterUrl.trim().ifBlank { WATER })
        store.saveProviderUrl(id, MeterType.GAS, gasUrl.trim().ifBlank { GAS })
        apartments.firstOrNull { it.id == id }?.meters?.filter { it.type == MeterType.WATER }?.forEach { m ->
            val title = meterTitles[m.id].orEmpty().trim().ifBlank { m.title }
            val serial = waterSerials[m.id].orEmpty().trim()
            store.put("meter_title_${id}_${m.id}", title)
            onUpdateTitle(m.id, title)
            store.put("serial_${m.id}", serial)
            onUpdateSerial(m.id, serial)
        }
        apartments.firstOrNull { it.id == id }?.meters?.forEach { m ->
            if (m.type == MeterType.ELECTRICITY) {
                store.put("meter_title_${id}_${m.id}", m.title.trim().ifBlank { m.title })
            }
        }
        apartments.firstOrNull { it.id == id }?.meters?.forEach { m ->
            if (m.type == MeterType.ELECTRICITY && energySerial.isNotBlank()) onUpdateSerial(m.id, energySerial)
        }
        onSaved()
    }

    Scaffold(topBar = { TopAppBar(title = { Text("Настройки") }, navigationIcon = { TextButton(onClick = onBack) { Text("Назад") } }) }) { padding ->
        LazyColumn(Modifier.padding(padding).padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            item {
                Text("Резервная копия настроек", style = MaterialTheme.typography.titleMedium)
                Text(
                    "При экспорте Android предложит выбрать имя и место сохранения файла. В файл входят квартиры, названия, показания, номера счётчиков, логины и другие настройки. Пароли также входят в файл резервной копии.",
                    style = MaterialTheme.typography.bodySmall
                )
                Spacer(Modifier.height(4.dp))
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedButton(onClick = onExportSettings, modifier = Modifier.weight(1f)) { Text("Экспорт настроек") }
                    OutlinedButton(onClick = onImportSettings, modifier = Modifier.weight(1f)) { Text("Импорт настроек") }
                }
            }
            item {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text("Квартиры", style = MaterialTheme.typography.titleMedium)
                    Button(onClick = { saveApartment(); onAddApartment() }) { Text("+ Добавить") }
                }
            }
            item {
                Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    apartments.forEach { apartment ->
                        Button(
                            onClick = {
                                if (selectedId != apartment.id) {
                                    saveApartment(selectedId)
                                    loadApartment(apartment.id)
                                }
                            },
                            enabled = selectedId != apartment.id,
                            contentPadding = PaddingValues(horizontal = 10.dp, vertical = 8.dp)
                        ) {
                            Column {
                                Text(
                                    store.get("apartment_label_${apartment.id}", "Кв. ${apartment.id}"),
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                                Text(
                                    store.apartmentAddress(apartment).ifBlank { "Без адреса" },
                                    maxLines = 2,
                                    overflow = TextOverflow.Ellipsis,
                                    style = MaterialTheme.typography.labelSmall
                                )
                            }
                        }
                    }
                }
            }
            item {
                OutlinedTextField(
                    apartmentLabel,
                    { apartmentLabel = it },
                    label = { Text("Название кнопки квартиры") },
                    supportingText = { Text("Это название будет показано вместо «Кв. $selectedId».") },
                    modifier = Modifier.fillMaxWidth()
                )
            }
            item { OutlinedTextField(address, { address = it }, label = { Text("Адрес") }, modifier = Modifier.fillMaxWidth()) }
            item {
                if (apartments.size > 1) {
                    OutlinedButton(
                        onClick = { showDeleteConfirmation = true },
                        modifier = Modifier.fillMaxWidth()
                    ) { Text("Удалить квартиру $selectedId") }
                }
            }
            item {
                Text("Поля для передачи показаний", style = MaterialTheme.typography.titleMedium)
                Text("Можно добавлять и удалять поля для воды и электричества. Газ остаётся отдельным полем.", style = MaterialTheme.typography.bodySmall)
            }
            item {
                Text("Электричество", style = MaterialTheme.typography.titleSmall)
                apartments.firstOrNull { it.id == selectedId }?.meters
                    ?.filter { it.type == MeterType.ELECTRICITY }
                    ?.forEach { meter ->
                        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                            OutlinedTextField(
                                value = meter.title,
                                onValueChange = { onUpdateTitle(meter.id, it) },
                                singleLine = true,
                                label = { Text("Название") },
                                modifier = Modifier.weight(1f)
                            )
                            TextButton(onClick = {
                                pendingDeleteMeterId = meter.id
                                pendingDeleteMeterTitle = meter.title
                                showDeleteMeterConfirmation = true
                            }) { Text("Удалить") }
                        }
                    }
            }
            item {
                Button(onClick = { onAddMeter(selectedId, MeterType.ELECTRICITY) }, modifier = Modifier.fillMaxWidth()) {
                    Text("+ Добавить свет")
                }
            }
            item {
                Text("Вода", style = MaterialTheme.typography.titleSmall)
                apartments.firstOrNull { it.id == selectedId }?.meters
                    ?.filter { it.type == MeterType.WATER }
                    ?.forEach { meter ->
                        Column(Modifier.fillMaxWidth()) {
                            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                                OutlinedTextField(
                                    value = meterTitles[meter.id].orEmpty().ifBlank { meter.title },
                                    onValueChange = { meterTitles[meter.id] = it },
                                    singleLine = true,
                                    label = { Text("Название") },
                                    modifier = Modifier.weight(1f)
                                )
                                TextButton(onClick = {
                                    pendingDeleteMeterId = meter.id
                                    pendingDeleteMeterTitle = meter.title
                                    showDeleteMeterConfirmation = true
                                }) { Text("Удалить") }
                            }
                            OutlinedTextField(
                                value = waterSerials[meter.id].orEmpty(),
                                onValueChange = { waterSerials[meter.id] = it },
                                label = { Text("Заводской номер ${meterTitles[meter.id].orEmpty().ifBlank { meter.title }}") },
                                singleLine = true,
                                supportingText = { Text("Этот номер используется для поиска такого же счётчика в ЛК Водоканала") },
                                modifier = Modifier.fillMaxWidth()
                            )
                        }
                    }
            }
            item {
                Button(onClick = { onAddMeter(selectedId, MeterType.WATER) }, modifier = Modifier.fillMaxWidth()) {
                    Text("+ Добавить воду")
                }
            }
            item { Text("Севэнергосбыт", style = MaterialTheme.typography.titleMedium) }
            item { OutlinedTextField(energySurname, { energySurname = it }, label = { Text("Фамилия") }, modifier = Modifier.fillMaxWidth()) }
            item { OutlinedTextField(energyAccount, { energyAccount = it }, label = { Text("Лицевой счёт") }, modifier = Modifier.fillMaxWidth()) }
            item { OutlinedTextField(energySerial, { energySerial = it }, label = { Text("Номер счётчика") }, modifier = Modifier.fillMaxWidth()) }
            item { OutlinedTextField(energyUrl, { energyUrl = it }, label = { Text("Адрес личного кабинета") }, modifier = Modifier.fillMaxWidth()) }
            item { Text("Водоканал", style = MaterialTheme.typography.titleMedium) }
            item { OutlinedTextField(waterLogin, { waterLogin = it }, label = { Text("Лицевой счёт / логин") }, modifier = Modifier.fillMaxWidth()) }
            item { OutlinedTextField(waterPassword, { waterPassword = it }, label = { Text("Пароль") }, visualTransformation = if (showWaterPassword) androidx.compose.ui.text.input.VisualTransformation.None else PasswordVisualTransformation(), trailingIcon = { TextButton(onClick = { showWaterPassword = !showWaterPassword }) { Text(if (showWaterPassword) "Скрыть" else "Показать") } }, modifier = Modifier.fillMaxWidth()) }
            item { OutlinedTextField(waterUrl, { waterUrl = it }, label = { Text("Адрес личного кабинета") }, modifier = Modifier.fillMaxWidth()) }
            item { Text("Севгаз", style = MaterialTheme.typography.titleMedium) }
            item { OutlinedTextField(gasLogin, { gasLogin = it }, label = { Text("Логин") }, modifier = Modifier.fillMaxWidth()) }
            item { OutlinedTextField(gasPassword, { gasPassword = it }, label = { Text("Пароль") }, visualTransformation = if (showGasPassword) androidx.compose.ui.text.input.VisualTransformation.None else PasswordVisualTransformation(), trailingIcon = { TextButton(onClick = { showGasPassword = !showGasPassword }) { Text(if (showGasPassword) "Скрыть" else "Показать") } }, modifier = Modifier.fillMaxWidth()) }
            item { OutlinedTextField(gasUrl, { gasUrl = it }, label = { Text("Адрес личного кабинета") }, modifier = Modifier.fillMaxWidth()) }
            item { Text("Адреса личных кабинетов сохраняются отдельно для каждой квартиры.") }
            item { Text("Пароли сохраняются только на этом телефоне.") }
            item { Button(onClick = { saveApartment() }, modifier = Modifier.fillMaxWidth()) { Text("Сохранить") } }
        }
    }

    if (showDeleteMeterConfirmation) {
        AlertDialog(
            onDismissRequest = { showDeleteMeterConfirmation = false },
            title = { Text("Удалить поле?") },
            text = { Text("Удалить поле «${pendingDeleteMeterTitle.ifBlank { "Счётчик" }}»? Показания этого счётчика будут удалены из настроек.") },
            confirmButton = {
                TextButton(onClick = {
                    showDeleteMeterConfirmation = false
                    if (pendingDeleteMeterId >= 0) onDeleteMeter(selectedId, pendingDeleteMeterId)
                    pendingDeleteMeterId = -1
                    pendingDeleteMeterTitle = ""
                }) { Text("Удалить") }
            },
            dismissButton = { TextButton(onClick = { showDeleteMeterConfirmation = false }) { Text("Отмена") } }
        )
    }

    if (showDeleteConfirmation) {
        AlertDialog(
            onDismissRequest = { showDeleteConfirmation = false },
            title = { Text("Удалить квартиру?") },
            text = {
                Text(
                    "Квартира «${apartmentLabel.ifBlank { "Кв. $selectedId" }}» будет удалена вместе с её настройками. Это действие нельзя отменить."
                )
            },
            confirmButton = {
                TextButton(
                    onClick = {
                        showDeleteConfirmation = false
                        val deletedId = selectedId
                        saveApartment(deletedId)
                        onDeleteApartment(deletedId)
                        val next = apartments.firstOrNull { it.id != deletedId }
                        if (next != null) loadApartment(next.id)
                    }
                ) { Text("Удалить") }
            },
            dismissButton = {
                TextButton(onClick = { showDeleteConfirmation = false }) { Text("Отмена") }
            }
        )
    }
}


data class GasReportData(val apartment: String, val address: String, val generatedAt: String, val supply: String, val maintenance: String, val debt: String, val overpayment: String)
private fun gasReportKey(id: Int, field: String) = "gas_report_${field}_$id"
private fun gasReportHtml(data: GasReportData): String = """
<!DOCTYPE html><html><head><meta charset="UTF-8"><title>Отчёт по газу</title><style>body{font-family:Arial,sans-serif;font-size:14pt;margin:32px}h1{font-size:20pt}table{border-collapse:collapse;width:100%}td{border:1px solid #999;padding:10px}td:first-child{font-weight:bold;width:55%}.date{color:#555}</style></head><body><h1>Отчёт по газу — ${data.apartment}</h1><p>${data.address}</p><table><tr><td>Газоснабжение</td><td>${data.supply}</td></tr><tr><td>Техническое обслуживание</td><td>${data.maintenance}</td></tr><tr><td>Задолженность</td><td>${data.debt}</td></tr><tr><td>Переплата</td><td>${data.overpayment}</td></tr></table><p class="date">Дата и время выгрузки: ${data.generatedAt}</p></body></html>
""".trimIndent()
private fun saveGasReportAsDoc(context: Context, uri: Uri, data: GasReportData) { context.contentResolver.openOutputStream(uri)?.use { it.write(gasReportHtml(data).toByteArray(Charsets.UTF_8)) } }
private fun saveGasReportAsExcel(context: Context, uri: Uri, data: GasReportData) { context.contentResolver.openOutputStream(uri)?.use { it.write(gasReportHtml(data).toByteArray(Charsets.UTF_8)) } }
private fun saveGasReportAsImage(context: Context, uri: Uri, data: GasReportData) { val bitmap=Bitmap.createBitmap(1200,900,Bitmap.Config.ARGB_8888); val canvas=Canvas(bitmap); canvas.drawColor(android.graphics.Color.WHITE); val p=Paint(Paint.ANTI_ALIAS_FLAG).apply{color=android.graphics.Color.BLACK;textSize=42f}; canvas.drawText("Отчёт по газу — ${data.apartment}",60f,80f,p); p.textSize=28f; canvas.drawText(data.address,60f,130f,p); p.textSize=32f; canvas.drawText("Газоснабжение:",80f,230f,p); canvas.drawText(data.supply,600f,230f,p); canvas.drawText("Техническое обслуживание:",80f,310f,p); canvas.drawText(data.maintenance,600f,310f,p); canvas.drawText("Задолженность:",80f,390f,p); canvas.drawText(data.debt,600f,390f,p); canvas.drawText("Переплата:",80f,470f,p); canvas.drawText(data.overpayment,600f,470f,p); p.textSize=24f; canvas.drawText("Дата и время выгрузки: ${data.generatedAt}",60f,560f,p); context.contentResolver.openOutputStream(uri)?.use{bitmap.compress(Bitmap.CompressFormat.PNG,100,it)}; bitmap.recycle() }
private data class GasReportRow(val apartment: Apartment,val supply:String,val maintenance:String,val debt:String,val overpayment:String)
private fun gasReportAllHtml(rows: List<GasReportRow>, generatedAt: String): String = buildString { append("<html><meta charset='utf-8'><body><h2>Отчёт газа — все квартиры</h2><p>Дата и время выгрузки: ").append(generatedAt).append("</p><table border='1' cellspacing='0' cellpadding='6'><tr><th>Квартира</th><th>Адрес</th><th>Газоснабжение</th><th>Техническое обслуживание</th><th>Задолженность</th><th>Переплата</th></tr>"); rows.forEach{r->append("<tr><td>Кв. ").append(r.apartment.id).append("</td><td>").append(r.apartment.address).append("</td><td>").append(r.supply).append("</td><td>").append(r.maintenance).append("</td><td>").append(r.debt).append("</td><td>").append(r.overpayment).append("</td></tr>")}; append("</table></body></html>") }

@Composable private fun GasReportHubScreen(apartments: List<Apartment>, store: LocalStore, onFetchApartment:(Int)->Unit, onFetchAll:()->Unit, onBack:()->Unit) { Scaffold(topBar={TopAppBar(title={Text("Отчёты газа")},navigationIcon={TextButton(onClick=onBack){Text("Назад")}})}){padding->LazyColumn(Modifier.padding(padding).padding(12.dp),verticalArrangement=Arrangement.spacedBy(10.dp)){item{Text("Данные по газоснабжению и расчётам",style=MaterialTheme.typography.titleMedium)}; apartments.filter{a->a.meters.any{it.type==MeterType.GAS}&&store.credentials(a.id).gasLogin.isNotBlank()&&store.credentials(a.id).gasPassword.isNotBlank()}.forEach{a->item{Button(onClick={onFetchApartment(a.id)},modifier=Modifier.fillMaxWidth()){Text("Получить отчёт — ${store.apartmentAddress(a)}")}}}; if(apartments.any{it.meters.any{m->m.type==MeterType.GAS}&&store.credentials(it.id).gasLogin.isNotBlank()&&store.credentials(it.id).gasPassword.isNotBlank()})item{Button(onClick=onFetchAll,modifier=Modifier.fillMaxWidth()){Text("Получить отчёт всех квартир")}}; item{Text("Данные берутся из личного кабинета Севгаз.",style=MaterialTheme.typography.bodySmall)}}}}
@Composable private fun GasReportScreen(apartment: Apartment?,store:LocalStore,refreshVersion:Int,onFetch:(Int)->Unit,onBack:()->Unit){val context=LocalContext.current;val id=apartment?.id?:1;val now=remember{SimpleDateFormat("dd.MM.yyyy HH:mm",Locale.getDefault()).format(Date())};var supply by remember(id,refreshVersion){mutableStateOf(store.get(gasReportKey(id,"supply")))};var maintenance by remember(id,refreshVersion){mutableStateOf(store.get(gasReportKey(id,"maintenance")))};var debt by remember(id,refreshVersion){mutableStateOf(store.get(gasReportKey(id,"debt")))};var over by remember(id,refreshVersion){mutableStateOf(store.get(gasReportKey(id,"overpayment")))};fun persist(){store.put(gasReportKey(id,"supply"),supply.trim());store.put(gasReportKey(id,"maintenance"),maintenance.trim());store.put(gasReportKey(id,"debt"),debt.trim());store.put(gasReportKey(id,"overpayment"),over.trim())};val data=GasReportData("Квартира $id",apartment?.let{store.apartmentAddress(it)}?:(""),now,supply.ifBlank{"Не получено"},maintenance.ifBlank{"Не получено"},debt.ifBlank{"Не получено"},over.ifBlank{"Не получено"});val d=rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/msword")){u->if(u!=null)saveGasReportAsDoc(context,u,data)};val e=rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/vnd.ms-excel")){u->if(u!=null)saveGasReportAsExcel(context,u,data)};val i=rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("image/png")){u->if(u!=null)saveGasReportAsImage(context,u,data)};Scaffold(topBar={TopAppBar(title={Text("Отчёт газа — Кв. $id")},navigationIcon={TextButton(onClick={persist();onBack()}){Text("Назад")}})}){padding->LazyColumn(Modifier.padding(padding).padding(12.dp),verticalArrangement=Arrangement.spacedBy(10.dp)){item{Text(data.address,style=MaterialTheme.typography.titleMedium)};item{Text("Дата и время выгрузки: $now",style=MaterialTheme.typography.bodySmall)};item{Button(onClick={onFetch(id)},modifier=Modifier.fillMaxWidth()){Text("Получить данные из ЛК Севгаз")}};item{OutlinedTextField(supply,{supply=it;persist()},label={Text("Газоснабжение")},singleLine=true,modifier=Modifier.fillMaxWidth())};item{OutlinedTextField(maintenance,{maintenance=it;persist()},label={Text("Техническое обслуживание")},singleLine=true,modifier=Modifier.fillMaxWidth())};item{OutlinedTextField(debt,{debt=it;persist()},label={Text("Задолженность")},singleLine=true,modifier=Modifier.fillMaxWidth())};item{OutlinedTextField(over,{over=it;persist()},label={Text("Переплата")},singleLine=true,modifier=Modifier.fillMaxWidth())};item{Text("Сохранить отчёт",style=MaterialTheme.typography.titleMedium)};item{Button(onClick={persist();d.launch("Отчёт_газ_Кв$id.doc")},modifier=Modifier.fillMaxWidth()){Text("Сохранить DOC")}};item{Button(onClick={persist();e.launch("Отчёт_газ_Кв$id.xls")},modifier=Modifier.fillMaxWidth()){Text("Сохранить Excel")}};item{Button(onClick={persist();i.launch("Отчёт_газ_Кв$id.png")},modifier=Modifier.fillMaxWidth()){Text("Сохранить как картинку")}}}}}
@Composable private fun GasReportAllScreen(apartments:List<Apartment>,store:LocalStore,onBack:()->Unit){val context=LocalContext.current;val now=remember{SimpleDateFormat("dd.MM.yyyy HH:mm",Locale.getDefault()).format(Date())};val rows=apartments.filter{a->a.meters.any{it.type==MeterType.GAS}&&store.credentials(a.id).gasLogin.isNotBlank()&&store.credentials(a.id).gasPassword.isNotBlank()}.map{a->GasReportRow(a.copy(address=store.apartmentAddress(a)),store.get(gasReportKey(a.id,"supply")),store.get(gasReportKey(a.id,"maintenance")),store.get(gasReportKey(a.id,"debt")),store.get(gasReportKey(a.id,"overpayment")))};val d=rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/msword")){u->if(u!=null)context.contentResolver.openOutputStream(u)?.use{it.write(gasReportAllHtml(rows,now).toByteArray(Charsets.UTF_8))}};val e=rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/vnd.ms-excel")){u->if(u!=null)context.contentResolver.openOutputStream(u)?.use{it.write(gasReportAllHtml(rows,now).toByteArray(Charsets.UTF_8))}};Scaffold(topBar={TopAppBar(title={Text("Отчёт газа — все квартиры")},navigationIcon={TextButton(onClick=onBack){Text("Назад")}})}){padding->LazyColumn(Modifier.padding(padding).padding(12.dp),verticalArrangement=Arrangement.spacedBy(10.dp)){rows.forEach{r->item{Card(Modifier.fillMaxWidth()){Column(Modifier.padding(12.dp)){Text("Кв. ${r.apartment.id} — ${r.apartment.address}",style=MaterialTheme.typography.titleMedium);Text("Газоснабжение: ${r.supply}");Text("Техническое обслуживание: ${r.maintenance}");Text("Задолженность: ${r.debt}");Text("Переплата: ${r.overpayment}")}}}};item{Button(onClick={e.launch("Отчёт_газ_все_квартиры.xls")},modifier=Modifier.fillMaxWidth()){Text("Сохранить Excel")}}}}}

data class WaterReportData(
    val apartment: String,
    val address: String,
    val generatedAt: String,
    val overpayment: String,
    val debt: String,
    val penalty: String
)

private fun waterReportHtml(data: WaterReportData): String = """
<!DOCTYPE html><html><head><meta charset="UTF-8"><title>Отчёт по воде</title>
<style>body{font-family:Arial,sans-serif;font-size:14pt;margin:32px}h1{font-size:20pt}table{border-collapse:collapse;width:100%}td{border:1px solid #999;padding:10px}td:first-child{font-weight:bold;width:55%}.date{color:#555}</style>
</head><body><h1>Отчёт по воде — ${data.apartment}</h1><p>${data.address}</p>
<table><tr><td>Переплата</td><td>${data.overpayment}</td></tr><tr><td>Задолженность</td><td>${data.debt}</td></tr><tr><td>Пеня</td><td>${data.penalty}</td></tr></table>
<p class="date">Дата и время выгрузки: ${data.generatedAt}</p></body></html>
""".trimIndent()

private fun saveWaterReportAsDoc(context: Context, uri: Uri, data: WaterReportData) {
    context.contentResolver.openOutputStream(uri)?.use { it.write(waterReportHtml(data).toByteArray(Charsets.UTF_8)) }
}

private fun saveWaterReportAsExcel(context: Context, uri: Uri, data: WaterReportData) {
    // Excel открывает HTML-таблицу с расширением .xls без дополнительных библиотек.
    context.contentResolver.openOutputStream(uri)?.use { it.write(waterReportHtml(data).toByteArray(Charsets.UTF_8)) }
}

private fun saveWaterReportAsImage(context: Context, uri: Uri, data: WaterReportData) {
    val width = 1200
    val height = 760
    val bitmap = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888)
    val canvas = Canvas(bitmap)
    canvas.drawColor(android.graphics.Color.WHITE)
    val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = android.graphics.Color.BLACK; textSize = 42f; typeface = Typeface.DEFAULT }
    canvas.drawText("Отчёт по воде — ${data.apartment}", 60f, 80f, paint)
    paint.textSize = 28f
    canvas.drawText(data.address, 60f, 130f, paint)
    paint.textSize = 34f
    canvas.drawText("Переплата:", 80f, 230f, paint); canvas.drawText(data.overpayment, 620f, 230f, paint)
    canvas.drawText("Задолженность:", 80f, 310f, paint); canvas.drawText(data.debt, 620f, 310f, paint)
    canvas.drawText("Пеня:", 80f, 390f, paint); canvas.drawText(data.penalty, 620f, 390f, paint)
    paint.textSize = 25f
    paint.color = android.graphics.Color.DKGRAY
    canvas.drawText("Дата и время выгрузки: ${data.generatedAt}", 60f, 500f, paint)
    context.contentResolver.openOutputStream(uri)?.use { bitmap.compress(Bitmap.CompressFormat.PNG, 100, it) }
    bitmap.recycle()
}

@Composable
private fun WaterReportHubScreen(
    apartments: List<Apartment>,
    store: LocalStore,
    onFetchApartment: (Int) -> Unit,
    onFetchAll: () -> Unit,
    onBack: () -> Unit
) {
    Scaffold(topBar = { TopAppBar(title = { Text("Отчёты воды") }, navigationIcon = { TextButton(onClick = onBack) { Text("Назад") } }) }) { padding ->
        LazyColumn(Modifier.padding(padding).padding(12.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            item { Text("Получение отчёта отдельно для каждой квартиры", style = MaterialTheme.typography.titleMedium) }
            apartments
                .filter { apartment ->
                    store.hasConfiguredWaterReport(apartment.id)
                }
                .forEach { apartment ->
                    item {
                        Button(onClick = { onFetchApartment(apartment.id) }, modifier = Modifier.fillMaxWidth()) {
                            Text("Получить отчёт — ${store.apartmentAddress(apartment)}")
                        }
                    }
                }
            val configuredApartments = apartments.filter { store.hasConfiguredWaterReport(it.id) }
            if (configuredApartments.isNotEmpty()) {
                item {
                    Spacer(Modifier.height(8.dp))
                    Button(onClick = onFetchAll, modifier = Modifier.fillMaxWidth()) {
                        Text("Получить отчёт всех квартир")
                    }
                }
            }
            item { Text("Данные каждой квартиры берутся из её собственного ЛК Водоканала.", style = MaterialTheme.typography.bodySmall) }
        }
    }
}

private data class WaterReportRow(
    val apartment: Apartment,
    val overpayment: String,
    val debt: String,
    val penalty: String
)

private fun waterReportKey(id: Int, field: String) = "water_report_${field}_$id"

@Composable
private fun WaterReportScreen(apartment: Apartment?, store: LocalStore, refreshVersion: Int = 0, onFetch: (Int) -> Unit, onBack: () -> Unit) {
    val context = LocalContext.current
    val id = apartment?.id ?: 1
    val now = remember { SimpleDateFormat("dd.MM.yyyy HH:mm", Locale.getDefault()).format(Date()) }
    var overpayment by remember(id, refreshVersion) { mutableStateOf(store.get(waterReportKey(id, "overpayment"))) }
    var debt by remember(id, refreshVersion) { mutableStateOf(store.get(waterReportKey(id, "debt"))) }
    var penalty by remember(id, refreshVersion) { mutableStateOf(store.get(waterReportKey(id, "penalty"))) }
    val data = WaterReportData(
        apartment = "Квартира $id",
        address = apartment?.let { store.apartmentAddress(it) } ?: "",
        generatedAt = now,
        overpayment = overpayment.ifBlank { "Не получено" },
        debt = debt.ifBlank { "Не получено" },
        penalty = penalty.ifBlank { "Не получено" }
    )
    val docLauncher = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/msword")) { uri -> if (uri != null) saveWaterReportAsDoc(context, uri, data) }
    val excelLauncher = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/vnd.ms-excel")) { uri -> if (uri != null) saveWaterReportAsExcel(context, uri, data) }
    val imageLauncher = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("image/png")) { uri -> if (uri != null) saveWaterReportAsImage(context, uri, data) }
    fun persist() {
        store.put(waterReportKey(id, "overpayment"), overpayment.trim())
        store.put(waterReportKey(id, "debt"), debt.trim())
        store.put(waterReportKey(id, "penalty"), penalty.trim())
    }
    Scaffold(topBar = { TopAppBar(title = { Text("Отчёт воды — Кв. $id") }, navigationIcon = { TextButton(onClick = { persist(); onBack() }) { Text("Назад") } }) }) { padding ->
        LazyColumn(Modifier.padding(padding).padding(12.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            item { Text(data.address, style = MaterialTheme.typography.titleMedium) }
            item { Text("Дата и время выгрузки: $now", style = MaterialTheme.typography.bodySmall) }
            item { Text("Финансовая информация", style = MaterialTheme.typography.titleMedium) }
            item { Button(onClick = { onFetch(id) }, modifier = Modifier.fillMaxWidth()) { Text("Получить данные из ЛК Водоканала") } }
            item { OutlinedTextField(overpayment, { overpayment = it; persist() }, label = { Text("Переплата") }, singleLine = true, modifier = Modifier.fillMaxWidth()) }
            item { OutlinedTextField(debt, { debt = it; persist() }, label = { Text("Задолженность") }, singleLine = true, modifier = Modifier.fillMaxWidth()) }
            item { OutlinedTextField(penalty, { penalty = it; persist() }, label = { Text("Пеня") }, singleLine = true, modifier = Modifier.fillMaxWidth()) }
            item { Text("Сохранить отчёт", style = MaterialTheme.typography.titleMedium) }
            item { Button(onClick = { persist(); docLauncher.launch("Отчёт_вода_Кв$id.doc") }, modifier = Modifier.fillMaxWidth()) { Text("Сохранить DOC") } }
            item { Button(onClick = { persist(); excelLauncher.launch("Отчёт_вода_Кв$id.xls") }, modifier = Modifier.fillMaxWidth()) { Text("Сохранить Excel") } }
            item { Button(onClick = { persist(); imageLauncher.launch("Отчёт_вода_Кв$id.png") }, modifier = Modifier.fillMaxWidth()) { Text("Сохранить как картинку") } }
        }
    }
}

private fun waterReportAllHtml(rows: List<WaterReportRow>, generatedAt: String): String = buildString {
    append("<html><meta charset='utf-8'><body><h2>Отчёт воды — все квартиры</h2>")
    append("<p>Дата и время выгрузки: ").append(generatedAt).append("</p>")
    append("<table border='1' cellspacing='0' cellpadding='6'><tr><th>Квартира</th><th>Адрес</th><th>Переплата</th><th>Задолженность</th><th>Пеня</th></tr>")
    rows.forEach { r -> append("<tr><td>Кв. ").append(r.apartment.id).append("</td><td>").append(r.apartment.address).append("</td><td>").append(r.overpayment).append("</td><td>").append(r.debt).append("</td><td>").append(r.penalty).append("</td></tr>") }
    append("</table></body></html>")
}

@Composable
private fun WaterReportAllScreen(apartments: List<Apartment>, store: LocalStore, onBack: () -> Unit) {
    val context = LocalContext.current
    val now = remember { SimpleDateFormat("dd.MM.yyyy HH:mm", Locale.getDefault()).format(Date()) }
    val rows = apartments
        .filter { a ->
            store.hasConfiguredWaterReport(a.id)
        }
        .map { a ->
            val address = store.apartmentAddress(a)
            WaterReportRow(
                a.copy(address = address),
                store.get(waterReportKey(a.id, "overpayment")),
                store.get(waterReportKey(a.id, "debt")),
                store.get(waterReportKey(a.id, "penalty"))
            )
        }
    val docLauncher = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/msword")) { uri -> if (uri != null) context.contentResolver.openOutputStream(uri)?.use { it.write(waterReportAllHtml(rows, now).toByteArray(Charsets.UTF_8)) } }
    val excelLauncher = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/vnd.ms-excel")) { uri -> if (uri != null) context.contentResolver.openOutputStream(uri)?.use { it.write(waterReportAllHtml(rows, now).toByteArray(Charsets.UTF_8)) } }
    Scaffold(topBar = { TopAppBar(title = { Text("Отчёт воды — все квартиры") }, navigationIcon = { TextButton(onClick = onBack) { Text("Назад") } }) }) { padding ->
        LazyColumn(Modifier.padding(padding).padding(12.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            item { Text("Дата и время выгрузки: $now", style = MaterialTheme.typography.bodySmall) }
            rows.forEach { r ->
                item {
                    Text("Квартира ${r.apartment.id}", style = MaterialTheme.typography.titleMedium)
                    Text(r.apartment.address)
                    Text("Переплата: ${r.overpayment}")
                    Text("Задолженность: ${r.debt}")
                    Text("Пеня: ${r.penalty}")
                }
            }
            item { Button(onClick = { docLauncher.launch("Отчёт_вода_все_квартиры.doc") }, modifier = Modifier.fillMaxWidth()) { Text("Сохранить общий DOC") } }
            item { Button(onClick = { excelLauncher.launch("Отчёт_вода_все_квартиры.xls") }, modifier = Modifier.fillMaxWidth()) { Text("Сохранить общий Excel") } }
        }
    }
}


private fun LocalStore.hasConfiguredWaterReport(apartmentId: Int): Boolean {
    // The saved meter list can contain meters created by the settings screen.
    // For an existing default meter, use its real default type as the fallback;
    // for a newly-created/custom meter, the app creates it as WATER unless the
    // user explicitly selected another type. The previous implementation used
    // ELECTRICITY as the fallback for every saved meter, which made a valid
    // water meter invisible on the report screen after settings were restored.
    val base = defaultApartments().firstOrNull { it.id == apartmentId } ?: newApartment(apartmentId)
    val baseById = base.meters.associateBy { it.id }
    val ids = meterIds(apartmentId, base.meters)
    val hasWaterMeter = ids.any { meterId ->
        val fallbackType = baseById[meterId]?.type ?: MeterType.WATER
        meterType(apartmentId, meterId, fallbackType) == MeterType.WATER
    }
    return hasWaterMeter &&
        waterLogin(apartmentId).isNotBlank() &&
        get("water_password_$apartmentId").isNotBlank()
}

private fun LocalStore.apartmentAddress(apartment: Apartment): String =
    get("address_${apartment.id}", apartment.address)

private fun providerUrl(type: MeterType) = when (type) { MeterType.ELECTRICITY -> ENERGY; MeterType.WATER -> WATER; MeterType.GAS -> GAS }

private fun autoFillScript(job: Job): String {
    val reading = JSONObject.quote(job.reading); val serial = JSONObject.quote(job.serial)
    val surname = JSONObject.quote(job.credentials.energySurname); val account = JSONObject.quote(job.credentials.energyAccount)
    val waterLogin = JSONObject.quote(job.credentials.waterLogin); val waterPassword = JSONObject.quote(job.credentials.waterPassword)
    val gasLogin = JSONObject.quote(job.credentials.gasLogin); val gasPassword = JSONObject.quote(job.credentials.gasPassword)
    return """
    (function(){
      const reading=$reading, serial=$serial, surname=$surname, account=$account, wl=$waterLogin, wp=$waterPassword, gl=$gasLogin, gp=$gasPassword;
      function all(){ return [...document.querySelectorAll('input,textarea,[contenteditable="true"]')]; }
      function visible(e){return e && (e.offsetWidth||e.offsetHeight||e.getClientRects().length)}
      function unlock(e){ if(!e)return; e.removeAttribute('disabled'); e.removeAttribute('readonly'); }
      function desc(e){ return ((e.getAttribute('aria-label')||'')+' '+(e.getAttribute('placeholder')||'')+' '+(e.getAttribute('name')||'')+' '+(e.id||'')+' '+((e.labels&&e.labels[0])?e.labels[0].innerText:'')+' '+(e.getAttribute('title')||'')).toLowerCase(); }
      function set(e,v){
        if(!e||v===undefined||v===null||v==='')return false;
        unlock(e); e.focus();
        try{ const proto=e instanceof HTMLTextAreaElement?HTMLTextAreaElement.prototype:HTMLInputElement.prototype; const d=Object.getOwnPropertyDescriptor(proto,'value'); if(d&&d.set)d.set.call(e,v); else e.value=v; }catch(_){e.value=v;}
        try{e.dispatchEvent(new InputEvent('input',{bubbles:true,inputType:'insertText',data:String(v)}));}catch(_){e.dispatchEvent(new Event('input',{bubbles:true}));}
        e.dispatchEvent(new Event('change',{bubbles:true}));
        try{e.dispatchEvent(new KeyboardEvent('keyup',{bubbles:true,key:'1'}));}catch(_){ }
        return true;
      }
      function clickLogin(form){
        const scope=form||document;
        const bs=[...scope.querySelectorAll('button,input[type=submit],input[type=button],a')].filter(visible);
        const b=bs.find(x=>/(войти|вход|login|sign in|авториз|личный кабинет)/i.test((x.innerText||x.value||x.getAttribute('aria-label')||'')+' '+desc(x))) || bs.find(x=>x.type==='submit');
        if(b){unlock(b); b.click(); return true;} return false;
      }
      let found=0, filled=0;
      if(location.host.includes('gup-sevgaz.ru') && !location.host.includes('lk.gup-sevgaz.ru')){
        const links=[...document.querySelectorAll('a,button,[role=button],div[onclick],span[onclick]')].filter(visible);
        const lk=links.find(e=>/(личный кабинет|личный\s+кабинет)/i.test((e.innerText||e.textContent||e.getAttribute('aria-label')||'')+' '+desc(e)))
          || links.find(e=>/личный.?кабинет|lk\.|irb\/login|login/i.test((e.getAttribute('href')||'')+' '+(e.getAttribute('data-href')||'')+' '+(e.getAttribute('onclick')||'')));
        if(lk){ unlock(lk); try{lk.click();}catch(_){} return JSON.stringify({ok:false,phase:'gas_lk'}); }
        return JSON.stringify({ok:false,phase:'login_wait'});
      }
      if(location.host.includes('sevenergosbyt')){
        const f=all().find(e=>visible(e)&&/(фамил|surname)/i.test(desc(e))); if(f){found++; if(set(f,surname))filled++;}
        const a=all().find(e=>visible(e)&&/(лицев|account|абонент)/i.test(desc(e))); if(a){found++; if(set(a,account))filled++;}
        const sn=all().find(e=>visible(e)&&/(номер.*сч|serial|серийн)/i.test(desc(e))); if(sn){found++; if(set(sn,serial))filled++;}
      } else if(location.host.includes('sevvodokanal') || location.host.includes('gup-sevgaz') || location.host.includes('sevgas')) {
        const gas=location.host.includes('gup-sevgaz') || location.host.includes('sevgas'); const login=gas?gl:wl, pass=gas?gp:wp;
        const pw=all().find(e=>visible(e)&&String(e.type).toLowerCase()==='password');
        if(pw && login && pass){
          let form=pw.form || pw.closest('form'); let l=null;
          const loginRe=/(j_username|username|user(name)?|login|account(number)?|personal|lic|ls|лицев|абонент)/i;
          if(form) {
            const inputs=[...form.querySelectorAll('input')].filter(e=>visible(e)&&e!==pw&&!/(search|поиск)/i.test(desc(e)));
            l=inputs.find(e=>/j_username/i.test((e.name||'')+' '+(e.id||'')));
            if(!l) l=inputs.find(e=>loginRe.test(desc(e)) && ['text','number','tel'].includes(String(e.type||'text').toLowerCase()));
            if(!l) l=inputs.find(e=>/username|login|account|personal|j_username/i.test((e.name||'')+' '+(e.id||'')+' '+(e.autocomplete||'')));
            if(!l) l=inputs.find(e=>['text','number','tel'].includes(String(e.type||'text').toLowerCase()));
          }
          if(!l) l=all().find(e=>visible(e)&&e!==pw&&loginRe.test(desc(e))&&['text','number','tel'].includes(String(e.type||'text').toLowerCase()));
          if(!l) l=all().find(e=>visible(e)&&e!==pw&&['text','number','tel'].includes(String(e.type||'text').toLowerCase())&&!/(search|поиск)/i.test(desc(e)));
          if(l) { found++; if(set(l,login)) filled++; }
          found++; if(set(pw,pass)) filled++;
          // Only fill credentials here. The actual login is triggered separately
          // by Android with a real touch on the visible SevGaz button.
          return JSON.stringify({ok:filled===2,phase:'login_ready',found:found,filledCount:filled,loginUsed:login});
        }
        return JSON.stringify({ok:false,phase:'login',found:found,filledCount:filled,loginUsed:login});
      }
      // IMPORTANT: login pages are handled above. Never search for a meter-reading
      // field while a provider login form is still visible.
      const pageText=(document.body&&document.body.innerText||'').toLowerCase();
      if(location.host.includes('gup-sevgaz') || location.host.includes('sevgas')){
        const clickables=[...document.querySelectorAll('button,input[type=button],input[type=submit],input[type=image],a,[role=button]')].filter(visible);
        const clickText=e=>((e.innerText||e.value||e.getAttribute('aria-label')||e.getAttribute('title')||'')+' '+desc(e)).toLowerCase();
        const hasCounters=/(сч[её]тчики|узлы\s*уч[её]та|приборы\s*уч[её]та)/i.test(pageText);
        const hasReadingForm=/(предоставление показаний|показания сч[её]тчика|передать показания)/i.test(pageText);
        if(!hasCounters){
          const b=clickables.find(e=>/^(сч[её]тчики|узлы\s*уч[её]та)$/i.test((e.innerText||e.value||'').trim()))
            || clickables.find(e=>/сч[её]тчики|узлы\s*уч[её]та/i.test(clickText(e)));
          if(b){unlock(b); b.click(); return JSON.stringify({ok:false,phase:'gas_counters'});}
        }
        if(hasCounters && !hasReadingForm){
          const b=clickables.find(e=>/предоставление показаний|показания сч[её]тчика|передать показания/i.test(clickText(e)));
          if(b){unlock(b); b.click(); return JSON.stringify({ok:false,phase:'gas_readings'});}
        }
      }
      const visiblePassword=[...document.querySelectorAll('input[type=password]')].find(visible);
      const loginButtons=[...document.querySelectorAll('button,input[type=submit],input[type=button],input[type=image],a,[role=button]')].filter(visible)
        .filter(e=>/(войти|вход|login|sign in|авториз|посмотреть)/i.test((e.innerText||e.value||e.getAttribute('aria-label')||e.getAttribute('title')||'')+' '+desc(e)));
      if((location.host.includes('sevvodokanal') || location.host.includes('gup-sevgaz') || location.host.includes('sevgas')) && visiblePassword && loginButtons.length){
        return JSON.stringify({ok:false,phase:'login',found:0,filledCount:0,loginUsed:''});
      }
      // HARD GUARD: on water/gas login screens never search or submit meter readings.
      if(location.host.includes('sevvodokanal') || location.host.includes('gup-sevgaz') || location.host.includes('sevgas')){
        const pwNow=[...document.querySelectorAll('input[type=password]')].find(visible);
        const bodyNow=(document.body&&document.body.innerText||'').toLowerCase();
        const loginFormNow=pwNow || /(лицевый\s*сч[её]т|личный кабинет|войти в систему|введите.*парол|логин|пароль)/i.test(bodyNow);
        if(loginFormNow) return JSON.stringify({ok:false,phase:'login_wait',found:0,filledCount:0,loginUsed:''});
      }
      const meterWords=['показани','показан','потреблен','потребл','текущие показ','текущее показ','объём','объем','reading','meter reading','значение счетчика','значение счётчика'];
      const badWords=['captcha','капч','код с картинки','код картинки','цифр с картинки','изображен','код подтвержден','проверочн','security','защит','с картинки'];
      let candidates=all().filter(e=>visible(e)&&!e.disabled&&e.type!=='hidden'&&e.type!=='password'&&!badWords.some(w=>desc(e).includes(w))&&(e.type==='text'||e.type==='number'||e.tagName==='TEXTAREA'));
      let target=candidates.find(e=>meterWords.some(w=>desc(e).includes(w)));
      if(!target && location.host.includes('sevenergosbyt')) target=candidates.find(e=>!['фамил','лицев','account','счётчик','счетчик','serial','серийн','captcha','капч','картин','код','парол','login'].some(w=>desc(e).includes(w)));
      if(target){found++; if(set(target,reading))filled++; try{target.scrollIntoView({block:'center'});}catch(_){} }
      if(!target && location.host.includes('sevenergosbyt')) {
        const clickable=[...document.querySelectorAll('button,input[type=button],a,[role=button]')].filter(visible);
        const nav=clickable.find(e=>/(показани|передач.*показ|сч[её]тчик|meter)/i.test((e.innerText||e.value||e.getAttribute('aria-label')||e.getAttribute('title')||'')+' '+desc(e)));
        if(nav){ unlock(nav); nav.click(); return JSON.stringify({ok:false,phase:'navigate'}); }
        const menu=clickable.find(e=>/(menu|меню|навигац)/i.test((e.innerText||e.value||e.getAttribute('aria-label')||e.getAttribute('title')||'')+' '+desc(e)));
        if(menu){ unlock(menu); menu.click(); return JSON.stringify({ok:false,phase:'menu'}); }
      }
      return JSON.stringify({ok:filled>0,phase:'meter',found:found,filledCount:filled});
    })()
    """.trimIndent()
}


private fun loginFillOnlyScript(job: Job): String {
    val waterLogin = JSONObject.quote(job.credentials.waterLogin)
    val waterPassword = JSONObject.quote(job.credentials.waterPassword)
    val gasLogin = JSONObject.quote(job.credentials.gasLogin)
    val gasPassword = JSONObject.quote(job.credentials.gasPassword)
    return """
    (function(){
      const wl=$waterLogin, wp=$waterPassword, gl=$gasLogin, gp=$gasPassword;
      const gas=location.host.includes('gup-sevgaz') || location.host.includes('sevgas');
      const login=gas?gl:wl, pass=gas?gp:wp;
      function visible(e){return e && (e.offsetWidth||e.offsetHeight||e.getClientRects().length)}
      function desc(e){ return ((e.getAttribute('aria-label')||'')+' '+(e.getAttribute('placeholder')||'')+' '+(e.getAttribute('name')||'')+' '+(e.id||'')+' '+((e.labels&&e.labels[0])?e.labels[0].innerText:'')+' '+(e.getAttribute('title')||'')).toLowerCase(); }
      function setValue(e,v){
        if(!e||v==null)return false;
        try{e.removeAttribute('disabled'); e.removeAttribute('readonly');}catch(_){}
        const proto=e instanceof HTMLTextAreaElement?HTMLTextAreaElement.prototype:HTMLInputElement.prototype;
        try{const d=Object.getOwnPropertyDescriptor(proto,'value'); if(d&&d.set)d.set.call(e,String(v)); else e.value=String(v);}catch(_){e.value=String(v);}
        try{e.dispatchEvent(new Event('focus',{bubbles:true}));}catch(_){}
        try{e.dispatchEvent(new InputEvent('input',{bubbles:true,inputType:'insertText',data:String(v)}));}catch(_){try{e.dispatchEvent(new Event('input',{bubbles:true}));}catch(_) {}}
        try{e.dispatchEvent(new Event('change',{bubbles:true}));}catch(_){}
        try{e.dispatchEvent(new KeyboardEvent('keydown',{bubbles:true,key:'End',code:'End'}));}catch(_){}
        try{e.dispatchEvent(new KeyboardEvent('keyup',{bubbles:true,key:'End',code:'End'}));}catch(_){}
        return true;
      }
      const inputs=[...document.querySelectorAll('input')].filter(visible);
      const pw=inputs.find(e=>String(e.type).toLowerCase()==='password');
      if(!pw) return JSON.stringify({ok:false,phase:'no_password',url:location.href});
      const form=pw.form || pw.closest('form');
      const candidates=form?[...form.querySelectorAll('input')].filter(e=>visible(e)&&e!==pw):inputs.filter(e=>e!==pw);
      const loginRe=/(j_username|username|user(name)?|login|account(number)?|personal|lic|ls|лицев|абонент)/i;
      let l=candidates.find(e=>/j_username/i.test((e.name||'')+' '+(e.id||'')));
      if(!l) l=candidates.find(e=>loginRe.test(desc(e))&&['text','number','tel'].includes(String(e.type||'text').toLowerCase()));
      if(!l) l=candidates.find(e=>/username|login|account|personal|j_username/i.test((e.name||'')+' '+(e.id||'')+' '+(e.autocomplete||'')));
      if(!l) l=candidates.find(e=>['text','number','tel'].includes(String(e.type||'text').toLowerCase()));
      if(!l) return JSON.stringify({ok:false,phase:'no_login',url:location.href});
      const a=setValue(l,login), b=setValue(pw,pass);
      const buttons=[...document.querySelectorAll('button,input[type=submit],input[type=button],a')].filter(visible);
      const submit=buttons.find(e=>/(войти в систему|войти|вход|login|sign in|авториз)/i.test((e.innerText||e.value||e.getAttribute('aria-label')||e.getAttribute('title')||'')+' '+desc(e)));
      if(submit){ try{submit.removeAttribute('disabled'); submit.removeAttribute('readonly');}catch(_){} }
      if(a&&b&&submit){
        try{submit.focus();}catch(_){}
        try{submit.dispatchEvent(new MouseEvent('mousedown',{bubbles:true,cancelable:true,view:window}));}catch(_){}
        try{submit.dispatchEvent(new MouseEvent('mouseup',{bubbles:true,cancelable:true,view:window}));}catch(_){}
        try{submit.click();}catch(_){}
      }
      return JSON.stringify({ok:a&&b,phase:(a&&b&&submit)?'login_submitted':'login_filled',loginField:l.name||l.id||l.type,passwordField:pw.name||pw.id||'password',submitEnabled:!!submit,url:location.href});
    })()
    """.trimIndent()
}



private fun nativeGasLoginScript(): String = """
(function(){
  const vis=e=>!!(e&&(e.offsetWidth||e.offsetHeight||e.getClientRects().length));
  const pw=[...document.querySelectorAll('input[type=password]')].find(vis);
  const form=pw && (pw.form||pw.closest('form'));
  if(!form) return JSON.stringify({ok:false,reason:'NO_FORM'});
  const submit=[...form.querySelectorAll('button,input[type=submit],input[type=button]')].find(vis);
  const fields=[...form.querySelectorAll('input')].filter(e=>e.name).map(e=>({
    name:e.name, value:e.value||'', type:e.type||'text'
  }));
  return JSON.stringify({
    ok:true,
    action:form.action||location.href,
    method:(form.method||'post').toUpperCase(),
    fields:fields,
    submit:submit?{name:submit.name||'',value:submit.value||''}:null,
    url:location.href
  });
})()
""".trimIndent()

private fun fallbackGasWebLogin(w: WebView) {
    w.evaluateJavascript("""
        (function(){
          const vis=e=>!!(e&&(e.offsetWidth||e.offsetHeight||e.getClientRects().length));
          const pw=[...document.querySelectorAll('input[type=password]')].find(vis);
          const form=pw && (pw.form||pw.closest('form'));
          if(!form)return 'NO_FORM';
          const buttons=[...form.querySelectorAll('button,input[type=submit],input[type=button]')].filter(vis);
          const txt=e=>((e.innerText||e.value||e.textContent||e.getAttribute('aria-label')||e.getAttribute('title')||'')+'');
          const submit=buttons.find(e=>/(войти в систему|войти|вход|login|sign in|авториз)/i.test(txt(e))) || buttons.find(e=>String(e.type||'').toLowerCase()==='submit');
          if(!submit)return 'NO_BUTTON';
          try{submit.removeAttribute('disabled');submit.removeAttribute('readonly');submit.focus();}catch(_){ }
          try{submit.click();return 'CLICK';}catch(_){return 'FAILED';}
        })()
    """.trimIndent()) { }
}

private fun startNativeGasLogin(w: WebView, job: Job, isManualLoginRequested: () -> Boolean) {
    w.evaluateJavascript(nativeGasLoginScript()) { raw ->
        val jsonText = try { JSONObject("{\"data\":$raw}").optString("data", raw ?: "") } catch (_: Exception) { raw ?: "" }
        val data = try { JSONObject(jsonText) } catch (_: Exception) {
            return@evaluateJavascript
        }
        if (isManualLoginRequested()) return@evaluateJavascript
        if (!data.optBoolean("ok", false)) {
            return@evaluateJavascript
        }
        val fields = data.optJSONArray("fields") ?: run {
            return@evaluateJavascript
        }
        val userAgent = w.settings.userAgentString
        val referer = data.optString("url", GAS)
        val initialCookies = android.webkit.CookieManager.getInstance().getCookie(data.optString("action", GAS)).orEmpty()
        Thread {
            var conn: HttpURLConnection? = null
            try {
                val actionRaw = data.optString("action", GAS)
                val action = if (actionRaw.endsWith("/irb/login.xhtml", true)) actionRaw.removeSuffix("/login.xhtml") + "/login" else actionRaw
                val params = LinkedHashMap<String, String>()
                for (i in 0 until fields.length()) {
                    val f = fields.optJSONObject(i) ?: continue
                    val name = f.optString("name")
                    if (name.isNotBlank()) params[name] = f.optString("value")
                }
                params["tab1:username"] = job.credentials.gasLogin
                params["tab1:password"] = job.credentials.gasPassword
                val submit = data.optJSONObject("submit")
                if (submit != null && submit.optString("name").isNotBlank()) {
                    params[submit.optString("name")] = submit.optString("value")
                }
                fun encode(values: Map<String, String>): String = values.entries.joinToString("&") {
                    URLEncoder.encode(it.key, "UTF-8") + "=" + URLEncoder.encode(it.value, "UTF-8")
                }

                val cookieManager = android.webkit.CookieManager.getInstance()
                var cookieHeader = initialCookies
                var currentUrl = action
                var finalUrl = action
                var success = false

                conn = (URL(currentUrl).openConnection() as HttpURLConnection).apply {
                    requestMethod = "POST"
                    doOutput = true
                    instanceFollowRedirects = false
                    connectTimeout = 5000
                    readTimeout = 7000
                    setRequestProperty("User-Agent", userAgent)
                    setRequestProperty("Referer", referer)
                    setRequestProperty("Content-Type", "application/x-www-form-urlencoded")
                    if (cookieHeader.isNotBlank()) setRequestProperty("Cookie", cookieHeader)
                }
                conn!!.outputStream.use { it.write(encode(params).toByteArray(Charsets.UTF_8)) }
                val code = conn!!.responseCode
                val setCookies = conn!!.headerFields?.entries?.filter { it.key.equals("Set-Cookie", true) }?.flatMap { it.value ?: emptyList() } ?: emptyList()
                if (setCookies.isNotEmpty()) {
                    val map = LinkedHashMap<String, String>()
                    cookieHeader.split(";").map { it.trim() }.filter { it.contains("=") }.forEach {
                        map[it.substringBefore("=").trim()] = it.substringAfter("=").trim()
                    }
                    setCookies.forEach { rawCookie ->
                        val first = rawCookie.substringBefore(";").trim()
                        if (first.contains("=")) map[first.substringBefore("=").trim()] = first.substringAfter("=").trim()
                    }
                    cookieHeader = map.entries.joinToString("; ") { "${it.key}=${it.value}" }
                }
                val location = conn!!.getHeaderField("Location")
                conn!!.disconnect()
                conn = null

                if (code in 300..399 && !location.isNullOrBlank()) {
                    currentUrl = URL(URL(action), location).toString()
                    finalUrl = currentUrl
                    conn = (URL(currentUrl).openConnection() as HttpURLConnection).apply {
                        requestMethod = "GET"
                        instanceFollowRedirects = false
                        connectTimeout = 5000
                        readTimeout = 7000
                        setRequestProperty("User-Agent", userAgent)
                        setRequestProperty("Referer", action)
                        if (cookieHeader.isNotBlank()) setRequestProperty("Cookie", cookieHeader)
                    }
                    val getCode = conn!!.responseCode
                    success = getCode in 200..399 && currentUrl.contains("/irb/view/", true)
                    conn!!.disconnect()
                    conn = null
                } else {
                    val stream = try { conn?.inputStream } catch (_: Exception) { conn?.errorStream }
                    val body = stream?.bufferedReader()?.use(BufferedReader::readText).orEmpty()
                    success = code in 200..399 && body.contains("abonentInfo", true)
                    finalUrl = action
                    conn?.disconnect()
                    conn = null
                }

                w.post {
                    if (isManualLoginRequested()) return@post
                    cookieHeader.split(";").map { it.trim() }.filter { it.contains("=") }.forEach {
                        val k = it.substringBefore("=").trim()
                        val v = it.substringAfter("=").trim()
                        if (k.isNotBlank()) cookieManager.setCookie("https://lk.gup-sevgaz.ru:8080", "$k=$v; Path=/")
                    }
                    cookieManager.flush()
                    if (success) {
                        w.loadUrl(finalUrl)
                    } else {
                        fallbackGasWebLogin(w)
                    }
                }
            } catch (_: Exception) {
                w.post {
                    if (!isManualLoginRequested()) fallbackGasWebLogin(w)
                }
            } finally { conn?.disconnect() }
        }.start()
    }
}

private fun autoGasLoginScript(job: Job): String {
    // Gas: fill credentials and identify the real login control.  The cabinet may
    // place the visible login button outside the password field's <form>, so search
    // the whole document and use several normal browser submission mechanisms.
    val gasLogin = JSONObject.quote(job.credentials.gasLogin)
    val gasPassword = JSONObject.quote(job.credentials.gasPassword)
    return """
    (function(){
      const login=$gasLogin, pass=$gasPassword;
      const visible=e=>!!(e&&(e.offsetWidth||e.offsetHeight||e.getClientRects().length));
      const desc=e=>(((e.getAttribute('aria-label')||'')+' '+(e.getAttribute('placeholder')||'')+' '+(e.getAttribute('name')||'')+' '+(e.id||'')+' '+(e.getAttribute('title')||'')+' '+((e.labels&&e.labels[0])?e.labels[0].innerText:''))+'').toLowerCase();
      const text=e=>((e.innerText||e.value||e.textContent||e.getAttribute('aria-label')||e.getAttribute('title')||'')+' '+desc(e));
      function setValue(e,v){
        if(!e)return false;
        try{e.removeAttribute('disabled');e.removeAttribute('readonly');}catch(_){ }
        try{
          const proto=e instanceof HTMLTextAreaElement?HTMLTextAreaElement.prototype:HTMLInputElement.prototype;
          const d=Object.getOwnPropertyDescriptor(proto,'value');
          if(d&&d.set)d.set.call(e,String(v)); else e.value=String(v);
        }catch(_){try{e.value=String(v);}catch(__){}}
        try{e.dispatchEvent(new Event('input',{bubbles:true}));}catch(_){ }
        try{e.dispatchEvent(new Event('change',{bubbles:true}));}catch(_){ }
        try{e.dispatchEvent(new Event('blur',{bubbles:true}));}catch(_){ }
        return String(e.value||'')===String(v);
      }
      const pw=[...document.querySelectorAll('input[type=password]')].find(visible);
      if(!pw) return JSON.stringify({ok:false,phase:'login_wait'});
      const form=pw.form||pw.closest('form');
      const pool=form?[...form.querySelectorAll('input')].filter(visible):[...document.querySelectorAll('input')].filter(visible);
      const re=/(j_username|username|user(name)?|login|account(number)?|personal|lic|ls|лицев|абонент)/i;
      let lf=pool.find(e=>e!==pw&&/j_username/i.test((e.name||'')+' '+(e.id||'')));
      if(!lf)lf=pool.find(e=>e!==pw&&re.test(desc(e))&&['text','number','tel'].includes(String(e.type||'text').toLowerCase()));
      if(!lf)lf=pool.find(e=>e!==pw&&['text','number','tel'].includes(String(e.type||'text').toLowerCase()));
      if(!lf) return JSON.stringify({ok:false,phase:'login_wait'});
      const loginOk=setValue(lf,login), passOk=setValue(pw,pass);

      // Do not require the submit control to belong to pw.form: some versions
      // of the cabinet render the visible button outside that form.
      const allButtons=[...document.querySelectorAll('button,input[type=submit],input[type=button],a,[role=button]')].filter(visible);
      const buttonWords=/(войти в систему|войти|вход|login|sign in|авториз)/i;
      let submit=allButtons.find(e=>buttonWords.test(text(e)));
      if(!submit) submit=allButtons.find(e=>e.form===form && String(e.type||'').toLowerCase()==='submit');
      if(!submit) return JSON.stringify({ok:loginOk&&passOk,phase:'login_filled'});
      try{submit.removeAttribute('disabled');submit.removeAttribute('readonly');submit.scrollIntoView({block:'center',inline:'center'});}catch(_){ }
      const r=submit.getBoundingClientRect();
      return JSON.stringify({ok:loginOk&&passOk,phase:'login_ready',x:r.left+r.width/2,y:r.top+r.height/2,w:r.width,h:r.height,tag:submit.tagName,type:submit.type||'',id:submit.id||'',name:submit.name||''});
    })()
    """.trimIndent()
}

private fun openGasReadingFormScript(): String {
    return """
    (function(){
      const norm=s=>(s||'').replace(/\\s+/g,' ').trim().toLowerCase();
      const text=e=>norm((e.innerText||e.value||e.textContent||e.getAttribute('aria-label')||e.getAttribute('title')||'')+'');
      const vis=e=>!!(e&&(e.offsetWidth||e.offsetHeight||e.getClientRects().length));
      const body=norm(document.body&&document.body.innerText||'');
      // The counters page itself contains the button text “Предоставление показаний счётчика”.
      // That text alone is NOT proof that the input dialog is open. Require a real visible
      // reading input/dialog marker instead.
      const visibleInputs=[...document.querySelectorAll('input,textarea')].filter(vis);
      const readingInput=visibleInputs.find(e=>/показани|значени|сч[её]тчик/i.test(text(e)) || /показани|значени|сч[её]тчик/i.test((e.name||'')+' '+(e.id||'')+' '+(e.placeholder||'')));
      const dialogText=[...document.querySelectorAll('[role="dialog"], .ui-dialog, .modal, .modal-dialog')].filter(vis).some(e=>/предоставление показаний|введите показания|показания сч[её]тчика/i.test(text(e)));
      const formOpen=!!readingInput || dialogText || /введите показания/i.test(body);
      if(formOpen) return JSON.stringify({ok:true,phase:'gas_reading_form'});

      function activate(el){
        if(!el) return false;
        let x=el;
        for(let i=0;i<7 && x;i++,x=x.parentElement){
          try{x.removeAttribute('disabled');x.removeAttribute('readonly');}catch(_){}
          try{x.scrollIntoView({block:'center',inline:'center'});}catch(_){}
          try{x.focus();}catch(_){}
          try{x.dispatchEvent(new MouseEvent('mousedown',{bubbles:true,cancelable:true,view:window}));}catch(_){}
          try{x.dispatchEvent(new MouseEvent('mouseup',{bubbles:true,cancelable:true,view:window}));}catch(_){}
          try{x.dispatchEvent(new MouseEvent('click',{bubbles:true,cancelable:true,view:window}));}catch(_){}
          try{if(typeof x.click==='function') x.click();}catch(_){}
          try{if(typeof x.onclick==='function') x.onclick.call(x); }catch(_){}
          if(x.matches && x.matches('a,button,input[type=button],input[type=submit],[role=button]')) return true;
        }
        return false;
      }

      const all=[...document.querySelectorAll('*')].filter(vis);
      const readingRe=/предоставление показаний|показания сч[её]тчика|передать показания/i;
      const counterRe=/^сч[её]тчики$|^сч[её]тчики\s*$/i;

      // First look for the actual control, not just its parent text.
      let reading=all.find(e=>readingRe.test(text(e)) && text(e).length<120 &&
        (e.matches('a,button,input[type=button],input[type=submit],[role=button]') || e.onclick || e.closest('a,button,input[type=button],input[type=submit],[role=button]')));
      if(reading){
        const target=reading.closest('a,button,input[type=button],input[type=submit],[role=button]') || reading;
        if(activate(target)) return JSON.stringify({ok:true,phase:'gas_readings'});
      }

      // Some JSF pages put the command text inside a table cell or span.
      let readingText=all.find(e=>readingRe.test(text(e)) && text(e).length<120);
      if(readingText && activate(readingText)) return JSON.stringify({ok:true,phase:'gas_readings'});

      // If still on the cabinet info page, open Counters. Prefer the actual tab/control.
      let counters=all.find(e=>counterRe.test(text(e)) &&
        (e.matches('a,button,input[type=button],input[type=submit],[role=button],td,li') || e.onclick || e.closest('a,button,input[type=button],input[type=submit],[role=button]')));
      if(!counters) counters=all.find(e=>/сч[её]тчики/.test(text(e)) && text(e).length<50);
      if(counters){
        const target=counters.closest('a,button,input[type=button],input[type=submit],[role=button]') || counters;
        if(activate(target)) return JSON.stringify({ok:true,phase:'gas_counters'});
      }

      return JSON.stringify({ok:false,phase:'gas_wait',bodyHasCounters:/сч[её]тчики/.test(body),bodyHasReading:readingRe.test(body)});
    })()
    """.trimIndent()
}


private fun fillGasReadingScript(reading: String): String {
    val value = JSONObject.quote(reading)
    return """
    (function(){
      const wanted=$value;
      const vis=e=>!!(e&&(e.offsetWidth||e.offsetHeight||e.getClientRects().length));
      const desc=e=>(((e.getAttribute('aria-label')||'')+' '+(e.getAttribute('placeholder')||'')+' '+(e.getAttribute('name')||'')+' '+(e.id||'')+' '+(e.getAttribute('title')||'')+' '+((e.labels&&e.labels[0])?e.labels[0].innerText:''))+'').toLowerCase();
      const set=(e,v)=>{
        if(!e) return false;
        try{e.removeAttribute('disabled');e.removeAttribute('readonly');e.focus();}catch(_){}
        try{
          const proto=e instanceof HTMLTextAreaElement?HTMLTextAreaElement.prototype:HTMLInputElement.prototype;
          const d=Object.getOwnPropertyDescriptor(proto,'value');
          if(d&&d.set)d.set.call(e,v); else e.value=v;
        }catch(_){try{e.value=v;}catch(__){return false;}}
        try{e.dispatchEvent(new InputEvent('input',{bubbles:true,inputType:'insertText',data:String(v)}));}catch(_){try{e.dispatchEvent(new Event('input',{bubbles:true}));}catch(__){}}
        try{e.dispatchEvent(new Event('change',{bubbles:true}));}catch(_){}
        try{e.dispatchEvent(new KeyboardEvent('keyup',{bubbles:true,key:'End'}));}catch(_){}
        return String(e.value||'')===String(v);
      };
      const dialogs=[...document.querySelectorAll('[role="dialog"], .ui-dialog, .modal, .modal-dialog')].filter(vis);
      const scopes=dialogs.length?dialogs:[document];
      let target=null;
      for(const scope of scopes){
        const inputs=[...scope.querySelectorAll('input,textarea')].filter(vis).filter(e=>e.type!=='hidden'&&e.type!=='password'&&e.type!=='button'&&e.type!=='submit');
        target=inputs.find(e=>/показани|значени|введите.*показ|сч[её]тчик/i.test(desc(e)));
        if(!target) target=inputs.find(e=>['text','number','tel'].includes(String(e.type||'text').toLowerCase()) && !/год|year|поиск|search/i.test(desc(e)));
        if(target) break;
      }
      if(!target) return JSON.stringify({ok:false,phase:'gas_reading_input_not_found'});
      const ok=set(target,wanted);
      try{target.scrollIntoView({block:'center',inline:'center'});}catch(_){}
      return JSON.stringify({ok:ok,phase:'gas_reading_filled',value:String(target.value||'')});
    })()
    """.trimIndent()
}

private fun autoSubmitScript(type: MeterType): String {
    return """
    (function(){
      const text=e=>((e.innerText||e.value||e.getAttribute('aria-label')||e.getAttribute('title')||'')+'').toLowerCase();
      const vis=e=>e&&(e.offsetWidth||e.offsetHeight||e.getClientRects().length);
      const bad=/(captcha|капч|код с картинки|код картинки|цифр с картинки|изображен|код подтвержден|проверочн|security|защит)/i;
      const buttons=[...document.querySelectorAll('button,input[type=submit],input[type=button],input[type=image],a,[role=button]')].filter(vis);
      const body=(document.body&&document.body.innerText||'').toLowerCase();
      if(typeName==='GAS'){}
      function clickBy(re){
        const b=buttons.find(e=>re.test(text(e)));
        if(b){try{b.removeAttribute('disabled');b.removeAttribute('readonly');b.focus();}catch(_){} try{b.click();return true;}catch(_){} }
        return false;
      }
      const typeName='%TYPE%';
      if(typeName==='GAS'){
        // After login the gas cabinet requires entering the Counters section first.
        if(!/(предоставление показаний|показания счетчика|показания сч[её]тчика|сч[её]тчики)/i.test(body)){
          if(clickBy(/^(сч[её]тчики|показания)$/i)) return JSON.stringify({ok:true,phase:'gas_counters'});
          if(clickBy(/сч[её]тчики|показани/i)) return JSON.stringify({ok:true,phase:'gas_counters'});
        }
        if(!/(предоставление показаний|показания счетчика|показания сч[её]тчика)/i.test(body)){
          if(clickBy(/предоставление показаний|показания счетчика|показания сч[её]тчика/i)) return JSON.stringify({ok:true,phase:'gas_readings'});
        }
      }
      const captcha=!![...document.querySelectorAll('input,textarea')].find(e=>vis(e)&&bad.test(((e.placeholder||'')+' '+(e.name||'')+' '+(e.id||'')+' '+(e.getAttribute('aria-label')||'')+' '+((e.parentElement&&e.parentElement.innerText)||''))));
      const re=/(передать|отправить|отправка|записать(?:\s+показания)?|записать|сохранить|подтвердить|подтверждаю|submit|send|save|confirm)/i;
      const candidates=buttons.filter(b=>re.test(text(b))&&!/(войти|вход|login|sign in|авториз|посмотреть)/i.test(text(b)));
      const btn=(typeName==='WATER' ? candidates.find(b=>/записать(?:\s+показания)?|передать|отправить/i.test(text(b))) : null)||candidates.find(b=>/передать|отправить|записать|submit|send/i.test(text(b)))||candidates[0];
      if(btn){ try{btn.removeAttribute('disabled');btn.removeAttribute('readonly');}catch(_){}; try{btn.click();}catch(_){} return JSON.stringify({ok:true,clicked:text(btn)}); }
      return JSON.stringify({ok:false,manual:false,captcha:captcha});
    })()
    """.trimIndent().replace("%TYPE%", type.name)
}

@SuppressLint("SetJavaScriptEnabled")

private fun waterReportExtractScript(): String = """
(function(){
  const clean=s=>String(s||'').replace(/\u00a0/g,' ').replace(/[\t ]+/g,' ').replace(/\r/g,'').trim();
  const body=clean((document.body&&document.body.innerText)||'');
  const head=clean(body.slice(0,4000));
  const money=/(-?\d+(?:[.,]\d+)?)\s*(?:руб\.?|р\.?)(?![\d])/i;
  function first(re){ const m=head.match(re); return m ? (m[1]||'').replace(',','.').trim() : ''; }
  // The water cabinet displays the financial statement at the very top,
  // e.g. "У Вас переплата 0.01 руб.". Read that statement directly.
  const over=first(/(?:у\s+вас\s+)?переплат[а-яё]*[^\n]{0,120}?(-?\d+(?:[.,]\d+)?)\s*(?:руб\.?|р\.?)/i);
  const debt=first(/(?:у\s+вас\s+)?(?:задолженн[а-яё]*|долг)[^\n]{0,120}?(-?\d+(?:[.,]\d+)?)\s*(?:руб\.?|р\.?)/i);
  const penalty=first(/(?:у\s+вас\s+)?(?:пен[яеи]|неустойк[а-яё]*)[^\n]{0,120}?(-?\d+(?:[.,]\d+)?)\s*(?:руб\.?|р\.?)/i);
  const hasFinance=/(переплат|задолженн|\bдолг\b|пен[яеи]|неустойк)/i.test(head);
  return JSON.stringify({found:hasFinance,overpayment:over||'отсутствует',debt:debt||'отсутствует',penalty:penalty||'отсутствует',url:location.href,source:head.slice(0,800)});
})()
""".trimIndent()

private fun gasReportExtractScript(): String = """
(function(){
 const clean=s=>String(s||'').replace(/\\u00a0/g,' ').replace(/[\\t ]+/g,' ').trim();
 const body=clean((document.body&&document.body.innerText)||'');
 const lines=body.split(/\\n+/).map(clean).filter(Boolean);
 const amount=/(-?\\d+(?:[.,]\\d+)?)\\s*(?:руб\\.?|р\\.?)(?![\\d])/i;
 function val(re){
   for(let i=0;i<lines.length;i++) if(re.test(lines[i])) { let m=lines[i].match(amount); if(m)return m[1].replace(',','.'); for(let j=1;j<=2;j++){if(lines[i+j]){m=lines[i+j].match(amount);if(m)return m[1].replace(',','.')}} }
   return '';
 }
 const supply=val(/газоснабжени/i), maintenance=val(/техническ(?:ое|ого)\\s+обслуживани|техобслуживани/i), debt=val(/задолженн|\\bдолг\\b/i), over=val(/переплат/i);
 const found=!!(supply||maintenance||debt||over);
 return JSON.stringify({found:found,gasSupply:supply||'отсутствует',maintenance:maintenance||'отсутствует',debt:debt||'отсутствует',overpayment:over||'отсутствует',url:location.href,source:body.slice(0,1200)});
})()
""".trimIndent()

private fun waterReportOpenCalculationsScript(): String = """(function(){return JSON.stringify({ok:false,disabled:true});})()"""

private fun fillWaterReadingOnlyScript(job: Job): String {
    val reading = JSONObject.quote(job.reading)
    val serial = JSONObject.quote(job.serial.trim())
    val rowNo = if (job.title.contains("№2")) "2" else "1"
    return """
    (function(){
      const reading=$reading, serial=$serial, rowNo="$rowNo";
      const visible=e=>!!(e&&(e.offsetWidth||e.offsetHeight||e.getClientRects().length));
      const clean=s=>String(s||'').replace(/\\s+/g,' ').trim();
      const txt=e=>clean(e ? ((e.innerText||e.textContent||'')+' '+(e.getAttribute?.('aria-label')||'')+' '+(e.getAttribute?.('placeholder')||'')+' '+(e.getAttribute?.('name')||'')+' '+(e.id||'')) : '');
      const allRoots=[document,...[...document.querySelectorAll('iframe')].map(f=>{try{return f.contentDocument}catch(_){return null}}).filter(Boolean)];
      const roots=allRoots;
      function setValue(e,v){
        if(!e)return false;
        try{e.removeAttribute('disabled');e.removeAttribute('readonly');e.focus();}catch(_){ }
        try{
          const proto=e instanceof HTMLTextAreaElement?HTMLTextAreaElement.prototype:HTMLInputElement.prototype;
          const d=Object.getOwnPropertyDescriptor(proto,'value');
          if(d&&d.set)d.set.call(e,String(v)); else e.value=String(v);
        }catch(_){try{e.value=String(v);}catch(__){}}
        try{e.dispatchEvent(new InputEvent('input',{bubbles:true,inputType:'insertText',data:String(v)}));}catch(_){try{e.dispatchEvent(new Event('input',{bubbles:true}));}catch(__){}}
        try{e.dispatchEvent(new Event('change',{bubbles:true}));}catch(_){ }
        try{e.dispatchEvent(new KeyboardEvent('keyup',{bubbles:true,key:'End'}));}catch(_){ }
        return String(e.value||'')===String(v);
      }
      function editable(x){
        if(!visible(x))return false;
        const typ=String(x.type||'text').toLowerCase();
        return /text|number|tel/.test(typ) || x.isContentEditable;
      }
      function goodInput(x){
        if(!editable(x))return false;
        const d=(txt(x)+' '+String(x.name||'')+' '+String(x.id||'')+' '+String(x.getAttribute('data-field')||'')).toLowerCase();
        if(/лицев|логин|парол|account|password|серийн|serial|предыдущ|previous|расход|тариф/.test(d))return false;
        return !x.hasAttribute('readonly')&&!x.hasAttribute('disabled');
      }
      function rows(root){return [...root.querySelectorAll('tr,[role="row"]')].filter(visible)}
      function cells(row){return [...row.children].filter(visible)}
      function findHeader(root){
        const cells=[...root.querySelectorAll('th,td,[role="columnheader"]')].filter(visible);
        return cells.find(c=>/новые\s*показания/i.test(txt(c)))||null;
      }
      function normSerial(s){return String(s||'').replace(/\\D/g,'');}
      function findRow(root){
        const rs=rows(root);
        const ns=normSerial(serial);
        if(ns){
          const bySerial=rs.find(r=>normSerial(txt(r)).includes(ns));
          if(bySerial)return {row:bySerial,matched:'serial'};
        }
        const byNo=rs.find(r=>{
          const cs=cells(r);
          const first=clean(cs[0] ? (cs[0].innerText||cs[0].textContent||'') : '');
          return first===rowNo || first.replace(/\\D/g,'')===rowNo;
        });
        if(byNo)return {row:byNo,matched:'row_number'};
        return null;
      }
      function checkboxFor(row){
        if(!row)return false;
        const boxes=[...row.querySelectorAll('input[type=checkbox],[role=checkbox]')].filter(visible);
        const b=boxes.find(e=>/подтверж|подтвержда/i.test(txt(e)+' '+txt(e.parentElement)))||boxes[0];
        if(!b)return false;
        try{if(b.tagName==='INPUT'){if(!b.checked)b.click();return !!b.checked;} if(b.getAttribute('aria-checked')!=='true')b.click();return true;}catch(_){return false;}
      }
      for(const root of roots){
        const header=findHeader(root);
        if(!header)continue;
        const headerRow=header.closest('tr,[role="row"]');
        if(!headerRow)continue;
        const headerCells=cells(headerRow);
        let col=headerCells.indexOf(header);
        if(col<0){col=headerCells.findIndex(c=>/новые\s*показания/i.test(txt(c)));}
        if(col<0)continue;
        const rr=findRow(root);
        if(!rr)continue;
        const row=rr.row, rowCells=cells(row);
        let targetCell=rowCells[col];
        if(!targetCell){
          const dataRows=rows(root).filter(r=>cells(r).length>col);
          const same=dataRows.find(r=>txt(r).includes(serial)||new RegExp('(^|\\s)'+rowNo+'(\\s|$)').test(txt(r)));
          if(same)targetCell=cells(same)[col];
        }
        if(!targetCell)continue;
        let target=[...targetCell.querySelectorAll('input,textarea,[contenteditable="true"]')].find(goodInput);
        if(!target){
          target=[...targetCell.querySelectorAll('input,textarea,[contenteditable="true"]')].find(x=>visible(x) && !/checkbox|radio|button|submit|hidden/i.test(String(x.type||'')));
        }
        if(!target){
          const rowInputs=[...row.querySelectorAll('input,textarea,[contenteditable="true"]')].filter(x=>visible(x) && !/checkbox|radio|button|submit|hidden/i.test(String(x.type||'')));
          if(rowInputs.length===1)target=rowInputs[0];
        }
        if(!target)continue;
        const valueOk=setValue(target,reading);
        const checked=checkboxFor(row);
        try{target.scrollIntoView({block:'center',inline:'center'});}catch(_){ }
        return JSON.stringify({ok:valueOk,phase:'water_reading_filled',row:rowNo,serial:serial,matchedBy:rr.matched,column:col,checked:checked,value:String(target.value||'')});
      }
      return JSON.stringify({ok:false,phase:'reading_field_not_found',row:rowNo,serial:serial,roots:roots.length,headerFound:roots.some(r=>!!findHeader(r))});
    })()
    """.trimIndent()
}

@Composable
private fun ProviderScreen(url: String, job: Job, index: Int, total: Int, store: LocalStore, reportMode: Boolean = false, gasReportMode: Boolean = false, onReportData: ((String, String, String) -> Unit)? = null, onGasReportData: ((String, String, String, String) -> Unit)? = null, onWebViewReady: (WebView) -> Unit, onStatus: (String) -> Unit, onNext: () -> Unit, onBack: () -> Unit) {
    var message by remember(url, job.meterId) { mutableStateOf("${job.address}\n${job.title}: ${job.reading}\nПередача $index из $total") }
    var webViewRef by remember { mutableStateOf<WebView?>(null) }
    var busy by remember { mutableStateOf(false) }
    var gasInitialPrepared by remember(url, job.meterId) { mutableStateOf(false) }
    var gasCabinetHandled by remember(url, job.meterId) { mutableStateOf(false) }
    var gasLoginFormPolls by remember(url, job.meterId) { mutableStateOf(0) }
    var manualGasLoginRequested by remember(url, job.meterId) { mutableStateOf(false) }
    var confirmed by remember { mutableStateOf(false) }
    var reportStarted by remember(url, job.meterId) { mutableStateOf(false) }
    var reportCalcClicked by remember(url, job.meterId) { mutableStateOf(false) }
    val context = LocalContext.current
    var pendingHtml by remember { mutableStateOf<String?>(null) }
    val htmlLauncher = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("text/html")) { uri ->
        if (uri != null) {
            try {
                context.contentResolver.openOutputStream(uri)?.use { out ->
                    out.write((pendingHtml ?: "").toByteArray(Charsets.UTF_8))
                }
                message = "HTML страницы сохранён. Прикрепите файл сюда."
                onStatus("HTML сохранён")
            } catch (e: Exception) {
                message = "Не удалось сохранить HTML: ${e.message ?: "ошибка"}"
                onStatus("Ошибка сохранения")
            }
        }
        pendingHtml = null
    }

    fun saveCurrentPageHtml(w: WebView) {
        w.evaluateJavascript("""
            (function(){
              const c=document.documentElement.cloneNode(true);
              c.querySelectorAll('input[type=password]').forEach(e=>{
                try { e.value=''; e.removeAttribute('value'); } catch(_){}
              });
              c.querySelectorAll('input').forEach(e=>{
                const n=((e.name||'')+' '+(e.id||'')).toLowerCase();
                if (n.includes('password') || n.includes('passwd') || n.includes('pwd')) {
                  try { e.value=''; e.removeAttribute('value'); } catch(_){}
                }
              });
              return c.outerHTML;
            })()
        """) { raw ->
            val html = try { JSONObject("{\"data\":$raw}").optString("data", "") } catch (_: Exception) { "" }
            if (html.isBlank()) {
                message = "Не удалось получить HTML текущей страницы."
                onStatus("HTML не получен")
                return@evaluateJavascript
            }
            pendingHtml = html
            htmlLauncher.launch("sev-gaz-login-page.html")
        }
    }

    fun checkConfirmation(w: WebView, attempt: Int = 0) {
        if (confirmed) return
        w.evaluateJavascript("""
            (function(){
              const t=(document.body&&document.body.innerText||'').toLowerCase();
              const ok=/(данн(ые|ых).*(принят|передан|сохран)|показани.*(принят|передан|сохран)|успешн.*(перед|сохран)|спасибо|операция выполнен|передача выполнен|данные отправлен|успешно)/i.test(t);
              const fail=/(ошибк|не удалось|не принят|не передан|неверн|введите капч|captcha)/i.test(t);
              return JSON.stringify({ok:ok,fail:fail});
            })()
        """.trimIndent()) { raw ->
            val r = raw ?: ""
            if (r.contains("\\\"ok\\\":true")) {
                confirmed = true
                busy = false
                message = "✓ ${job.title}: ${job.reading} — показание подтверждено"
                onStatus("Передано ✓")
                w.postDelayed({ onNext() }, 1200)
            } else if (attempt < 10 && !r.contains("\\\"fail\\\":true")) {
                w.postDelayed({ checkConfirmation(w, attempt + 1) }, 900)
            } else {
                busy = false
                message = "Команда отправлена. Подтверждение сайта не найдено — проверь страницу."
                onStatus("Проверить результат")
            }
        }
    }

    fun submitGasLogin(w: WebView, attempt: Int = 0, manual: Boolean = false) {
        if (confirmed) return
        if (attempt >= 250) {
            busy = false
            message = "Газ: вход не запущен. Диагностика: кнопка/JSF не найдены за 10 секунд."
            onStatus("Вход: тайм-аут")
            return
        }
        w.evaluateJavascript("""
            (function(){
              function visible(e){return !!(e && (e.offsetWidth || e.offsetHeight || e.getClientRects().length));}
              function primeReady(win){return !!(win && win.PrimeFaces && typeof win.PrimeFaces.onPost==='function');}
              function inspect(doc, win, frame){
                if(!doc) return null;
                let e=null;
                try{e=doc.getElementById('tab1:j_idt23');}catch(_){ }
                if(!e){
                  try{e=[...doc.querySelectorAll('button,input[type=submit],input[type=button],[role=button],a')].find(x=>visible(x)&&/(войти в систему|войти|login|sign in)/i.test((x.innerText||x.value||x.textContent||'')+' '+(x.id||'')+' '+(x.name||''));}catch(_){ }
                }
                if(e && visible(e)) return {e:e,win:win,frame:frame||'main'};
                try{
                  for(const f of doc.querySelectorAll('iframe,frame')){
                    try{
                      const d=f.contentDocument || (f.contentWindow && f.contentWindow.document);
                      const hit=inspect(d,f.contentWindow,frame ? frame+'/iframe' : 'iframe');
                      if(hit) return hit;
                    }catch(_){ }
                  }
                }catch(_){ }
                return null;
              }
              const hit=inspect(document,window,'main');
              if(!hit) return 'NO_BUTTON';
              if(!primeReady(hit.win)) return 'WAIT_PRIMEFACES:'+hit.frame;
              const e=hit.e;
              try{e.removeAttribute('disabled');e.removeAttribute('readonly');e.focus();e.scrollIntoView({block:'center',inline:'center'});}catch(_){ }
              try{
                e.click();
                return 'CLICKED:'+hit.frame+':'+(e.id||e.name||e.tagName);
              }catch(err){
                return 'CLICK_ERROR:'+hit.frame+':'+(err && err.message ? err.message : 'unknown');
              }
            })()
        """.trimIndent()) { result ->
            if (confirmed) return@evaluateJavascript
            val r = (result ?: "").trim('"')
            when {
                r.startsWith("CLICKED:") -> {
                    busy = true
                    message = if (manual)
                        "Кв. ${job.apartmentId}: кнопка «Войти в систему» нажата вручную через страницу. Ждём ответ сайта…"
                    else
                        "Кв. ${job.apartmentId}: кнопка «Войти в систему» нажата автоматически. Ждём ответ сайта…"
                    onStatus("Вход: кнопка нажата")
                }
                r.startsWith("WAIT_PRIMEFACES:") -> {
                    busy = false
                    message = "Газ: кнопка найдена (${r.substringAfter(':')}), ждём JSF/PrimeFaces… (${attempt + 1})"
                    onStatus("Вход: ждём PrimeFaces")
                    w.postDelayed({ submitGasLogin(w, attempt + 1, manual) }, 40)
                }
                r == "NO_BUTTON" -> {
                    busy = false
                    message = "Газ: кнопку «Войти в систему» не нашли в странице/iframe. (${attempt + 1})"
                    onStatus("Вход: ищем кнопку")
                    w.postDelayed({ submitGasLogin(w, attempt + 1, manual) }, 40)
                }
                r.startsWith("CLICK_ERROR:") -> {
                    busy = false
                    message = "Газ: ошибка нажатия: ${r.removePrefix("CLICK_ERROR:")}"
                    onStatus("Вход: ошибка кнопки")
                }
                else -> {
                    busy = false
                    message = "Газ: неизвестный результат входа: $r"
                    onStatus("Вход: диагностика")
                }
            }
        }
    }

    fun startGasAutoLogin(w: WebView, attempt: Int = 0) {
        if (confirmed || attempt >= 250) {
            if (!confirmed) {
                busy = false
                message = "Газ: диагностика формы не завершена. Проверьте страницу."
                onStatus("Диагностика не завершена")
            }
            return
        }
        w.evaluateJavascript(autoGasLoginScript(job)) { raw ->
            if (confirmed) return@evaluateJavascript
            val r = raw ?: ""
            if (r.contains("login_ready") || r.contains("login_filled")) {
                busy = true
                message = "Кв. ${job.apartmentId}: выполняем быстрый автоматический вход…"
                onStatus("Автовход: отправка")
                if (job.type == MeterType.GAS && !manualGasLoginRequested) {
                    startNativeGasLogin(w, job) { manualGasLoginRequested }
                } else if (job.type == MeterType.GAS) {
                    message = "Газ: автоматический вход остановлен — выбран ручной вход."
                    onStatus("Ручной вход")
                } else {
                    message = "Газ: данные входа заполнены. Нажмите «Войти в систему»."
                    onStatus("Готово к входу")
                }
                return@evaluateJavascript
            }
            if (attempt % 25 == 0) {
                busy = false
                message = "Газ: ждём форму входа… (${attempt + 1})"
                onStatus("Диагностика: ждём форму")
            }
            w.postDelayed({ startGasAutoLogin(w, attempt + 1) }, 40)
        }
    }

    fun manualGasLogin(w: WebView) {
        if (confirmed) return
        manualGasLoginRequested = true
        busy = false
        message = "Газ: заполняем данные входа…"
        onStatus("Подготовка входа")
        w.evaluateJavascript(autoGasLoginScript(job)) { raw ->
            if (confirmed) return@evaluateJavascript
            val ok = (raw ?: "").contains("login_ready") || (raw ?: "").contains("login_filled")
            if (!ok) {
                message = "Газ: форма входа ещё не готова."
                onStatus("Ожидание формы")
                return@evaluateJavascript
            }
            message = "Газ: форма заполнена. Проверяем готовность сайта…"
            onStatus("Форма готова")
            submitGasLogin(w, manual = true)
        }
    }

    fun runWaterReportRead(w: WebView, attempt: Int = 0) {
        if (!reportMode || confirmed) return
        w.evaluateJavascript(waterReportExtractScript()) { raw ->
            val r = raw ?: ""
            // evaluateJavascript returns a JSON-encoded string. Decode it first,
            // then read the exact values returned by the page parser.
            val json = try { JSONObject("{\"data\":$r}").optString("data", r) } catch (_: Exception) { r }
            val over = Regex("""\"overpayment\":\"([^\"]*)\"""").find(json)?.groupValues?.getOrNull(1).orEmpty()
            val debt = Regex("""\"debt\":\"([^\"]*)\"""").find(json)?.groupValues?.getOrNull(1).orEmpty()
            val penalty = Regex("""\"penalty\":\"([^\"]*)\"""").find(json)?.groupValues?.getOrNull(1).orEmpty()
            val found = Regex("""\"found\":true""").containsMatchIn(json)
            if (found) {
                confirmed = true
                busy = false
                message = "✓ Финансовые данные получены с текущей страницы ЛК"
                onReportData?.invoke(over.ifBlank { "отсутствует" }, debt.ifBlank { "отсутствует" }, penalty.ifBlank { "отсутствует" })
                return@evaluateJavascript
            }
            if (attempt < 15) w.postDelayed({ runWaterReportRead(w, attempt + 1) }, 900)
            else { busy = false; message = "На текущей странице ЛК финансовый блок не найден." }
        }
    }

    fun runFillAndSend() {
        val w = webViewRef ?: run { message = "Страница ещё загружается."; return }
        if (busy) return
        // Water: fill credentials and click the site's normal login button.
        // There is no CAPTCHA handling here; the site login is used as-is.
        // Gas remains in the manual-click test flow for now.
        if (job.type == MeterType.WATER) {
            busy = true
            if (job.apartmentId == 1) {
                message = "Кв. 1: открываем ЛК воды…"
                onStatus("Вход…")
                w.evaluateJavascript(autoFillScript(job)) { result ->
                    val r = result ?: ""
                    val phase = Regex("\"phase\":\"([^\"]+)\"").find(r)?.groupValues?.getOrNull(1) ?: ""
                    if (phase == "login" || r.contains("\"ok\":true") || r.contains("login_filled")) {
                        message = "Кв. 1: вход выполняется…"
                        onStatus("Вход…")
                    }
                    w.postDelayed({
                        if (confirmed) return@postDelayed
                        w.evaluateJavascript(fillWaterReadingOnlyScript(job)) { fillResult ->
                            busy = false
                            val fr = fillResult ?: ""
                            if (fr.contains("water_reading_filled") && fr.contains("\"ok\":true")) {
                                message = "Кв. 1: показание ${job.reading} записано в «Новые показания». Галочка подтверждения установлена. Кнопку «Отправить показания» не нажимаем."
                                onStatus("Показание заполнено")
                            } else {
                                message = "Кв. 1: ЛК открыт, но строка «Новые показания» не найдена. Проверьте страницу вручную."
                                onStatus("Проверьте ЛК")
                            }
                        }
                    }, 4500)
                }
            } else {
                message = "Вода: заполняем логин и пароль и выполняем вход…"
                onStatus("Вход…")
                w.evaluateJavascript(autoFillScript(job)) { result ->
                    val r = result ?: ""
                    val ok = r.contains("\"ok\":true") || r.contains("login_filled")
                    val phase = Regex("\"phase\":\"([^\"]+)\"").find(r)?.groupValues?.getOrNull(1) ?: ""
                    if (ok || phase == "login") {
                        message = "Вода: данные заполнены, выполняем вход…"
                        onStatus("Вход…")
                        w.postDelayed({ if (!confirmed) runFillAndSend() }, 4200)
                    } else {
                        busy = false
                        message = "Вода: не удалось найти поле логина или пароля."
                        onStatus("Требуется ввод")
                    }
                }
            }
            return
        }
        if (job.type == MeterType.GAS) {
            // All gas apartments use the same native HTTP login algorithm and their own saved credentials.
            busy = true
            message = "Кв. ${job.apartmentId}: автоматически входим в личный кабинет…"
            onStatus("Автоматический вход…")
            startGasAutoLogin(w)
            fun openGasFormAfterLogin(attempt: Int = 0) {
                if (confirmed) return
                if (attempt >= 30) {
                    busy = false
                    message = "Газ: кабинет открыт. Проверьте раздел «Счётчики»."
                    onStatus("Кабинет открыт")
                    return
                }
                w.evaluateJavascript(openGasReadingFormScript()) { rr ->
                    if (confirmed) return@evaluateJavascript
                    when {
                        rr?.contains("gas_reading_form") == true -> {
                            message = "Газ: форма показаний открыта. Заполняем значение…"
                            onStatus("Заполнение показания")
                            w.postDelayed({
                                if (confirmed) return@postDelayed
                                w.evaluateJavascript(fillGasReadingScript(job.reading)) { fr ->
                                    if (confirmed) return@evaluateJavascript
                                    busy = false
                                    if (fr?.contains("gas_reading_filled") == true && fr.contains("\"ok\":true")) {
                                        message = "Газ: показание ${job.reading} заполнено. Проверьте значение и нажмите OK вручную."
                                        onStatus("Показание заполнено")
                                    } else {
                                        message = "Газ: форма открыта, но поле показания не найдено. Проверьте его вручную."
                                        onStatus("Требуется проверка")
                                    }
                                }
                            }, 80)
                        }
                        rr?.contains("gas_counters") == true -> {
                            message = "Газ: открываем раздел «Счётчики»…"
                            w.postDelayed({ openGasFormAfterLogin(attempt + 1) }, 300)
                        }
                        else -> w.postDelayed({ openGasFormAfterLogin(attempt + 1) }, 60)
                    }
                }
            }

            fun waitForGasCabinet(attempt: Int) {
                if (confirmed) return
                if (attempt >= 80) {
                    busy = false
                    message = "Газ: автоматический вход не завершён. Проверьте страницу — кнопку «Войти» можно нажать вручную."
                    onStatus("Проверьте вход")
                    return
                }
                w.postDelayed({
                    if (confirmed) return@postDelayed
                    w.evaluateJavascript("""(function(){
                        const visible=e=>!!(e&&(e.offsetWidth||e.offsetHeight||e.getClientRects().length));
                        const body=((document.body&&document.body.innerText)||'').toLowerCase();
                        const pwVisible=[...document.querySelectorAll('input[type="password"]')].some(visible);
                        const loginWords=/регистрационные данные|войти в систему|забыли пароль/i.test(body);
                        const cabinetWords=/лицев\s*сч[ёе]т|абонент|сч[ёе]тчики|характеристики|история платежей/i.test(body);
                        if(cabinetWords && !pwVisible) return 'CABINET_PAGE';
                        if(pwVisible || loginWords) return 'LOGIN_PAGE';
                        return 'WAIT';
                    })()""") { state ->
                        when {
                            state.contains("CABINET_PAGE") -> {
                                try {
                                    val cookies = android.webkit.CookieManager.getInstance().getCookie(GAS) ?: ""
                                    if (cookies.isNotBlank()) store.putGasCookies(job.apartmentId, cookies)
                                } catch (_: Exception) {}
                                message = "Газ: вход выполнен. Открываем «Счётчики»…"
                                onStatus("Открываем счётчики")
                                openGasFormAfterLogin()
                            }
                            else -> waitForGasCabinet(attempt + 1)
                        }
                    }
                }, 30)
            }
            waitForGasCabinet(0)
            return
        }
        busy = true
        onStatus("Заполняется…")
        message = "1/3 Заполняем данные…"
        w.evaluateJavascript(autoFillScript(job)) { result ->
            val r = result ?: ""
            val ok = r.contains("\\\"ok\\\":true")
            val phase = Regex("\\\"phase\\\":\\\"([^\\\"]+)\\\"").find(r)?.groupValues?.getOrNull(1) ?: "meter"
            val filled = Regex("\\\"filledCount\\\":(\\d+)").find(r)?.groupValues?.getOrNull(1) ?: "0"
            val loginUsed = Regex("\"loginUsed\":\"([^\"]*)\"").find(r)?.groupValues?.getOrNull(1) ?: ""
            if (phase == "navigate" || phase == "menu" || phase == "gas_lk" || phase == "gas_counters" || phase == "gas_readings" || phase == "login_wait") {
                busy = false
                message = when (phase) {
                    "menu" -> "Открываем меню Севэнергосбыта…"
                    "gas_counters" -> "Открываем раздел «Счётчики»…"
                    "gas_readings" -> "Открываем форму показаний газа…"
                    else -> "Открываем форму передачи показаний…"
                }
                onStatus("Открываем форму…")
                w.postDelayed({ if (!confirmed && !busy) runFillAndSend() }, 1200)
                return@evaluateJavascript
            }
            if (!ok) {
                busy = false
                message = "Не удалось автоматически заполнить нужные поля."
                onStatus("Требуется ввод")
                return@evaluateJavascript
            }
            if (phase == "login") {
                busy = false
                message = "2/3 Вход: $loginUsed…"
                onStatus("Вход…")
                w.postDelayed({ if (!confirmed && !busy) runFillAndSend() }, 3800)
                return@evaluateJavascript
            }
            message = "2/3 Показание ${job.reading} заполнено."
            onStatus("Данные заполнены")
            message = "3/3 Передаём показание…"
            onStatus("Передаётся…")
            w.postDelayed({
                    w.evaluateJavascript(autoSubmitScript(job.type)) { sr ->
                        val x = sr ?: ""
                        if (x.contains("\\\"ok\\\":true")) {
                            message = "3/3 Команда отправлена. Ждём подтверждение сайта…"
                            checkConfirmation(w)
                        } else {
                            busy = false
                            message = "Не удалось найти кнопку передачи. Откройте форму и попробуйте ещё раз."
                            onStatus("Требуется ввод")
                        }
                    }
                }, 900)
        }
    }

    fun sendNow() {
        val w = webViewRef ?: return
        if (busy) return
        busy = true
        message = "3/3 Передаём показание ${job.reading}…"
        onStatus("Передаётся…")
        w.evaluateJavascript(autoSubmitScript(job.type)) { r ->
            val x = r ?: ""
            if (x.contains("\\\"ok\\\":true")) {
                message = "Команда отправлена. Ждём подтверждение сайта…"
                checkConfirmation(w)
            } else {
                busy = false
                message = "Кнопку передачи не нашли."
                onStatus("Требуется ввод")
            }
        }
    }

    Column(Modifier.fillMaxSize()) {
        if (!reportMode) {
            Row(Modifier.fillMaxWidth().padding(8.dp), horizontalArrangement = Arrangement.SpaceBetween) {
                Text("Передача $index/$total", style = MaterialTheme.typography.titleMedium)
                TextButton(onClick = onBack, enabled = !busy) { Text("Назад") }
            }
            Text(message, Modifier.padding(horizontal = 12.dp))
            Row(Modifier.padding(8.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Button(onClick = { runFillAndSend() }, enabled = !busy && !confirmed) { Text("Передать") }
                Button(onClick = onBack, enabled = !busy) { Text("Назад") }
            }
            if (job.type == MeterType.GAS) {
                OutlinedButton(onClick = { webViewRef?.let { manualGasLogin(it) } }, enabled = !confirmed) {
                    Text("Войти вручную")
                }
                Text("Можно также нажать обычную кнопку «Войти в систему» прямо на странице — вход выполняется штатно, как в браузере.", Modifier.padding(horizontal = 12.dp))
                OutlinedButton(onClick = { webViewRef?.let { saveCurrentPageHtml(it) } }, enabled = !busy) {
                    Text("Сохранить HTML страницы")
                }
            }
        }
        AndroidView(factory = { context ->
            WebView(context).apply {
                webViewRef = this
                onWebViewReady(this)
                settings.javaScriptEnabled = true
                settings.domStorageEnabled = true
                settings.databaseEnabled = true
                settings.cacheMode = android.webkit.WebSettings.LOAD_DEFAULT
                // During the SevGaz login page, images are not needed for authentication.
                // Avoid waiting for image resources; restore them once the cabinet is reached.
                settings.loadsImagesAutomatically = (job.type != MeterType.GAS)
                settings.javaScriptCanOpenWindowsAutomatically = true
                settings.setSupportMultipleWindows(false)
                settings.mixedContentMode = android.webkit.WebSettings.MIXED_CONTENT_COMPATIBILITY_MODE
                android.webkit.CookieManager.getInstance().setAcceptCookie(true)
                android.webkit.CookieManager.getInstance().setAcceptThirdPartyCookies(this, true)
                // Each job starts a fresh cabinet session. For GAS we deliberately
                // keep the WebView cache for speed, but never keep cookies/session
                // from the previous apartment. Form data is also cleared so WebView
                // autofill cannot reinsert an old apartment's credentials.
                if (job.type != MeterType.GAS) {
                    android.webkit.CookieManager.getInstance().removeAllCookies(null)
                    android.webkit.CookieManager.getInstance().flush()
                    clearHistory()
                    clearCache(true)
                    clearFormData()
                    clearSslPreferences()
                } else {
                    clearFormData()
                }
                settings.useWideViewPort = true
                settings.loadWithOverviewMode = true
                // Разрешаем увеличение/уменьшение страницы жестом двумя пальцами.
                settings.setSupportZoom(true)
                settings.builtInZoomControls = true
                settings.displayZoomControls = false
                settings.textZoom = 100
                // Keep the standard Android WebView user-agent. The Sevgaz cabinet can reject modified WebView user-agents.
                webChromeClient = object : WebChromeClient() {
                    override fun onReceivedTitle(view: WebView, title: String) {
                        super.onReceivedTitle(view, title)
                        if (title.isNotBlank()) message = "Страница: $title"
                    }
                }
                webViewClient = object : WebViewClient() {
                    override fun shouldOverrideUrlLoading(view: WebView, request: android.webkit.WebResourceRequest): Boolean {
                        // Let WebView handle normal form POST/redirect navigation itself.
                        // Intercepting and re-loading the URL can turn a POST login into a GET.
                        return false
                    }
                    override fun shouldOverrideUrlLoading(view: WebView, url: String): Boolean {
                        return false
                    }
                    override fun onPageCommitVisible(view: WebView, url: String) {
                        super.onPageCommitVisible(view, url)
                        onWebViewReady(view)
                        // Start the gas login as soon as the first page content is visible,
                        // instead of waiting for every page resource to finish loading.
                        // This can remove several seconds of WebView resource-loading delay
                        // while keeping the same proven JSF login submission.
                        if (!confirmed && job.type == MeterType.GAS) {
                            // Do not wait for onPageFinished: the browser can display the
                            // SevGaz cabinet while images/scripts are still loading.
                            // WebView's onPageFinished waits for those resources and was
                            // the source of the long ~15s delay after successful login.
                            if (!gasInitialPrepared && !url.contains("/irb/view/abonentInfo.xhtml", ignoreCase = true)) {
                                gasInitialPrepared = true
                                message = "Газ: готовим поля входа…"
                                onStatus("Подготовка входа")
                                webViewRef = view
                                startGasAutoLogin(view)
                            }

                            if (!gasCabinetHandled && url.contains("/irb/view/abonentInfo.xhtml", ignoreCase = true)) {
                                fun continueGasFromCabinet(attempt: Int = 0) {
                                    if (confirmed || gasCabinetHandled) return
                                    if (attempt >= 80) return
                                    view.evaluateJavascript("""(function(){
                                        const visible=e=>!!(e&&(e.offsetWidth||e.offsetHeight||e.getClientRects().length));
                                        const body=((document.body&&document.body.innerText)||'').toLowerCase();
                                        const pw=[...document.querySelectorAll('input[type=\"password\"]')].some(visible);
                                        const cabinet=/лицев\s*сч[ёе]т|абонент|сч[ёе]тчики|характеристики|история платежей/i.test(body);
                                        return (cabinet && !pw) ? 'CABINET' : 'WAIT';
                                    })()""") { state ->
                                        if (state.contains("CABINET")) {
                                            gasCabinetHandled = true
                                            message = "Газ: вход выполнен. Открываем «Счётчики»…"
                                            onStatus("Открываем счётчики")
                                            fun openFast(attempt2: Int = 0) {
                                                if (confirmed) return
                                                if (attempt2 >= 50) {
                                                    busy = false
                                                    message = "Газ: кабинет открыт. Проверьте раздел «Счётчики»."
                                                    onStatus("Кабинет открыт")
                                                    return
                                                }
                                                view.evaluateJavascript(openGasReadingFormScript()) { rr ->
                                                    if (confirmed) return@evaluateJavascript
                                                    when {
                                                        rr?.contains("gas_reading_form") == true -> {
                                                            view.evaluateJavascript(fillGasReadingScript(job.reading)) { fr ->
                                                                if (confirmed) return@evaluateJavascript
                                                                busy = false
                                                                if (fr?.contains("gas_reading_filled") == true && fr.contains("\"ok\":true")) {
                                                                    message = "Газ: показание ${job.reading} заполнено. Проверьте значение и нажмите OK вручную."
                                                                    onStatus("Показание заполнено")
                                                                } else {
                                                                    message = "Газ: форма открыта, но поле показания не найдено. Проверьте его вручную."
                                                                    onStatus("Требуется проверка")
                                                                }
                                                            }
                                                        }
                                                        rr?.contains("gas_counters") == true || rr?.contains("gas_readings") == true ->
                                                            view.postDelayed({ openFast(attempt2 + 1) }, 50)
                                                        else -> view.postDelayed({ openFast(attempt2 + 1) }, 50)
                                                    }
                                                }
                                            }
                                            openFast()
                                        } else {
                                            view.postDelayed({ continueGasFromCabinet(attempt + 1) }, 50)
                                        }
                                    }
                                }
                                continueGasFromCabinet()
                            }
                        }
                    }
                    override fun onPageStarted(view: WebView, url: String, favicon: android.graphics.Bitmap?) {
                        onWebViewReady(view)
                        message = "Загрузка: ${url.take(80)}…"
                    }
                    override fun onReceivedError(view: WebView, request: android.webkit.WebResourceRequest, error: android.webkit.WebResourceError) {
                        if (request.isForMainFrame) message = "Ошибка загрузки: ${error.description}"
                    }
                    override fun onPageFinished(view: WebView, loadedUrl: String) {
                        onWebViewReady(view)
                        if (!confirmed) {
                            if (reportMode) {
                                if (gasReportMode && job.type == MeterType.GAS) {
                                    val loginPage = loadedUrl.contains("/irb/login", true) || loadedUrl.contains("login.xhtml", true) || loadedUrl.contains("/irb/", true) && view.url?.contains("login", true) == true
                                    if (loginPage && !reportStarted) {
                                        reportStarted = true
                                        message = "ЛК газа: выполняем вход…"
                                        startNativeGasLogin(view, job) { false }
                                    } else if (!reportStarted) {
                                        reportStarted = true
                                        message = "ЛК газа загружен. Читаем данные отчёта…"
                                        busy = true
                                        fun readGas(attempt:Int=0) {
                                            if (confirmed) return
                                            view.evaluateJavascript(gasReportExtractScript()) { raw ->
                                                val json=raw?.trim('"')?.replace("\\"",""") ?: "{}"
                                                try {
                                                    val o=JSONObject(json)
                                                    if(o.optBoolean("found",false) || attempt>=12) {
                                                        busy=false
                                                        onGasReportData?.invoke(o.optString("gasSupply","отсутствует"),o.optString("maintenance","отсутствует"),o.optString("debt","отсутствует"),o.optString("overpayment","отсутствует"))
                                                    } else view.postDelayed({readGas(attempt+1)},700)
                                                } catch(_:Exception) { if(attempt<12)view.postDelayed({readGas(attempt+1)},700) else {busy=false;onGasReportData?.invoke("не получено","не получено","не получено","не получено")} }
                                            }
                                        }
                                        readGas()
                                    }
                                } else {
                                    message = "ЛК воды загружен. Читаем данные отчёта…"
                                    busy = true
                                    if (!reportStarted) {
                                        reportStarted = true
                                        view.evaluateJavascript(autoFillScript(job)) { _ -> view.postDelayed({ runWaterReportRead(view) }, 3200) }
                                    } else view.postDelayed({ runWaterReportRead(view) }, 700)
                                }
                            } else if (job.type == MeterType.GAS) {
                                // Газ: используем тот же проверенный пошаговый сценарий, который
                                // применялся для квартиры 2: дождаться JSF-формы, заполнить
                                // логин/пароль, нажать штатную кнопку входа, дождаться кабинета,
                                // открыть «Счётчики» и форму показаний.
                                if (!gasCabinetHandled && loadedUrl.contains("/irb/view/abonentInfo.xhtml", ignoreCase = true)) {
                                    // The server can return abonentInfo.xhtml while still showing
                                    // the login form (for example when the first submit did not
                                    // establish the session). Do not report success from URL alone.
                                    view.evaluateJavascript("""(function(){
                                         const visible=e=>!!(e&&(e.offsetWidth||e.offsetHeight||e.getClientRects().length));
                                         const body=((document.body&&document.body.innerText)||'').toLowerCase();
                                         const pwVisible=[...document.querySelectorAll('input[type="password"]')].some(visible);
                                         const loginWords=/регистрационные данные|войти в систему|забыли пароль/i.test(body);
                                         const cabinetWords=/лицевой\s*сч[её]т|абонент|сч[ёе]тчики|характеристики|история платежей/i.test(body);
                                         const cabinet=cabinetWords && !pwVisible;
                                         return cabinet ? 'CABINET_PAGE' : ((pwVisible||loginWords) ? 'LOGIN_PAGE' : 'UNKNOWN_PAGE');
                                    })()""") { stateResult ->
                                        val state = stateResult ?: ""
                                        when {
                                            state.contains("CABINET_PAGE") -> {
                                                view.settings.loadsImagesAutomatically = true
                                                busy = true
                                                message = "Газ: вход выполнен. Открываем «Счётчики»…"
                                                onStatus("Открываем счётчики")
                                                fun openGasForm(attempt: Int = 0) {
                                                    if (confirmed) return
                                                    if (attempt >= 30) {
                                                        busy = false
                                                        message = "Газ: кабинет открыт. Откройте «Счётчики» вручную."
                                                        onStatus("Открыта страница")
                                                        return
                                                    }
                                                    view.evaluateJavascript(openGasReadingFormScript()) { rr ->
                                                        if (confirmed) return@evaluateJavascript
                                                        when {
                                                            rr?.contains("gas_reading_form") == true -> {
                                                                busy = true
                                                                message = "Газ: форма показаний открыта. Заполняем значение…"
                                                                onStatus("Заполнение показания")
                                                                view.postDelayed({
                                                                    if (confirmed) return@postDelayed
                                                                    view.evaluateJavascript(fillGasReadingScript(job.reading)) { fr ->
                                                                        if (confirmed) return@evaluateJavascript
                                                                        if (fr?.contains("gas_reading_filled") == true && fr.contains("\"ok\":true")) {
                                                                            busy = false
                                                                            message = "Газ: показание ${job.reading} заполнено. Проверьте значение и нажмите OK вручную."
                                                                            onStatus("Показание заполнено")
                                                                        } else {
                                                                            busy = false
                                                                            message = "Газ: форма открыта, но поле показания не найдено. Проверьте его вручную."
                                                                            onStatus("Требуется проверка")
                                                                        }
                                                                    }
                                                                }, 150)
                                                            }
                                                            rr?.contains("gas_counters") == true -> {
                                                                message = "Газ: открываем раздел «Счётчики»…"
                                                                view.postDelayed({ openGasForm(attempt + 1) }, 100)
                                                            }
                                                            else -> view.postDelayed({ openGasForm(attempt + 1) }, 80)
                                                        }
                                                    }
                                                }
                                                view.postDelayed({ openGasForm() }, 60)
                                            }
                                            state.contains("LOGIN_PAGE") -> {
                                                // Если JSF вернул нас на форму входа, снова запускаем тот же
                                                // polling-алгоритм. Важно не оставлять заполненную форму без клика.
                                                message = "Газ: автоматически выполняем вход…"
                                                onStatus("Автоматический вход…")
                                                busy = false
                                                startGasAutoLogin(view)
                                                fun waitForGasLoginResult(attempt: Int) {
                                                    if (confirmed) return
                                                    if (attempt >= 600) {
                                                        busy = false
                                                        message = "Газ: кабинет не обнаружен. Если кабинет уже открыт, нажми «Передать» ещё раз."
                                                        onStatus("Вход не подтверждён")
                                                        return
                                                    }
                                                    view.postDelayed({
                                                        if (confirmed) return@postDelayed
                                                        view.evaluateJavascript("""(function(){
                                                             const visible=e=>!!(e&&(e.offsetWidth||e.offsetHeight||e.getClientRects().length));
                                                             const body=((document.body&&document.body.innerText)||'').toLowerCase();
                                                             const pwVisible=[...document.querySelectorAll('input[type="password"]')].some(visible);
                                                             const loginWords=/регистрационные данные|войти в систему|забыли пароль/i.test(body);
                                                             const cabinetWords=/лицевой\s*сч[ёе]т|абонент|сч[ёе]тчики|характеристики|история платежей/i.test(body);
                                                             const cabinet=cabinetWords && !pwVisible;
                                                             if (cabinet) return 'CABINET_PAGE';
                                                             if (pwVisible || loginWords) return 'LOGIN_PAGE';
                                                             return 'UNKNOWN_PAGE';
                                                        })()""") { rr ->
                                                            if (!confirmed) {
                                                            when {
                                                                rr.contains("CABINET_PAGE") -> {
                                                                    view.settings.loadsImagesAutomatically = true
                                                                    busy = false
                                                                    try {
                                                                        val cookies = android.webkit.CookieManager.getInstance().getCookie(GAS) ?: ""
                                                                        if (cookies.isNotBlank()) store.putGasCookies(job.apartmentId, cookies)
                                                                    } catch (_: Exception) {}
                                                                    message = "Газ: вход выполнен. Открыт личный кабинет."
                                                                    onStatus("Вход выполнен")
                                                                }
                                                                attempt >= 30 -> {
                                                                    busy = false
                                                                    message = "Газ: ждём ответ сервера… Если кабинет уже открыт, можно продолжить."
                                                                    onStatus("Кабинет проверяется")
                                                                }
                                                                else -> waitForGasLoginResult(attempt + 1)
                                                            }
                                                            }
                                                        }
                                                    }, 50)
                                                }
                                                waitForGasLoginResult(0)
                                            }
                                            else -> {
                                                busy = false
                                                message = "Газ: проверяем результат входа…"
                                                onStatus("Проверка входа")
                                            }
                                        }
                                    }
                                } else if (!gasInitialPrepared) {
                                    gasInitialPrepared = true
                                    message = "Газ: готовим поля входа…"
                                    onStatus("Подготовка входа")
                                    webViewRef = view
                                    // The script itself polls for the JSF controls every 100 ms.
                                    // Start immediately after page load.
                                    startGasAutoLogin(view)
                                }
                            } else {
                                message = "Страница загружена. Подготовка передачи…"
                                view.postDelayed({ webViewRef = view; runFillAndSend() }, 1800)
                                view.postDelayed({ if (!confirmed) { busy = false; webViewRef = view; runFillAndSend() } }, 3000)
                                view.postDelayed({ if (!confirmed) { busy = false; webViewRef = view; runFillAndSend() } }, 6000)
                            }
                        }
                    }
                }
                if (job.type == MeterType.GAS) {
                    // Gas gets an isolated cookie jar per apartment. We still keep the
                    // WebView cache, but restore only this apartment's saved session.
                    // That makes repeat opens fast without leaking apartment A's session
                    // into apartment B.
                    val savedCookies = store.gasCookies(job.apartmentId)
                    val cm = android.webkit.CookieManager.getInstance()
                    val parts = savedCookies.split(';').map { it.trim() }.filter { it.contains('=') }
                    if (parts.isNotEmpty()) {
                        // Do not wipe the WebView cookie jar on every open when a saved
                        // Kv.1 session exists. Restoring a valid session is enough and
                        // avoids an unnecessary full login round-trip.
                        var left = parts.size
                        parts.forEach { cookie ->
                            cm.setCookie(GAS, cookie) {
                                left--
                                if (left == 0) {
                                    cm.flush()
                                    post { loadUrl(url) }
                                }
                            }
                        }
                    } else {
                        cm.removeAllCookies {
                            cm.flush()
                            post { loadUrl(url) }
                        }
                    }
                } else {
                    loadUrl(url)
                }
            }
            }, modifier = if (reportMode) Modifier.size(1.dp) else Modifier.fillMaxSize())
    }
}

