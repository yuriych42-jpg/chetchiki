@file:OptIn(ExperimentalMaterial3Api::class)
package ru.chetchiki.app

import android.annotation.SuppressLint
import android.content.Context
import android.os.Bundle
import android.webkit.WebView
import android.webkit.WebViewClient
import android.webkit.WebChromeClient
import org.json.JSONObject
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.viewinterop.AndroidView

enum class MeterType { ELECTRICITY, WATER, GAS }

data class Meter(
    val id: Int,
    val type: MeterType,
    val title: String,
    val serial: String = "",
    val reading: String = "",
    val status: String = "Не передано"
)

data class Apartment(val id: Int, val address: String, val meters: List<Meter>)

data class Credentials(
    val energySurname: String = "",
    val energyAccount: String = "",
    val energySerial: String = "",
    val waterLogin: String = "",
    val waterPassword: String = "",
    val gasLogin: String = "",
    val gasPassword: String = ""
)

data class Job(
    val apartmentId: Int,
    val address: String,
    val meterId: Int,
    val type: MeterType,
    val title: String,
    val reading: String,
    val serial: String = "",
    val credentials: Credentials = Credentials()
)

private const val ENERGY = "https://sevenergosbyt.ru/flk/index.php"
private const val WATER = "https://sevvodokanal.org.ru/app/webroot/account.php"
private const val GAS = "https://lk.gup-sevgaz.ru:8443/irb/login.xhtml"

private fun defaultApartments() = listOf(
    Apartment(1, "Адрес квартиры 1", listOf(
        Meter(1, MeterType.ELECTRICITY, "Электричество"), Meter(2, MeterType.WATER, "Вода №1"), Meter(3, MeterType.WATER, "Вода №2"), Meter(4, MeterType.GAS, "Газ")
    )),
    Apartment(2, "Адрес квартиры 2", listOf(
        Meter(5, MeterType.ELECTRICITY, "Электричество"), Meter(6, MeterType.WATER, "Вода"), Meter(7, MeterType.GAS, "Газ")
    )),
    Apartment(3, "Адрес квартиры 3", listOf(
        Meter(8, MeterType.ELECTRICITY, "Электричество"), Meter(9, MeterType.WATER, "Вода"), Meter(10, MeterType.GAS, "Газ")
    )),
    Apartment(4, "Адрес квартиры 4", listOf(
        Meter(11, MeterType.ELECTRICITY, "Электричество"), Meter(12, MeterType.WATER, "Вода №1"), Meter(13, MeterType.WATER, "Вода №2")
    ))
)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { MeterApp(applicationContext) }
    }
}

private class LocalStore(context: Context) {
    private val p = context.getSharedPreferences("meter_store", Context.MODE_PRIVATE)
    fun get(k: String, d: String = "") = p.getString(k, d) ?: d
    fun put(k: String, v: String) { p.edit().putString(k, v).apply() }
    fun commitAddress(k: String, v: String) { p.edit().putString(k, v).commit() }
    fun credentials(id: Int) = Credentials(
        get("energy_surname_$id"), get("energy_account_$id"), get("energy_serial_$id"),
        get("water_login_$id"), get("water_password_$id"), get("gas_login_$id"), get("gas_password_$id")
    )
}

@Composable
fun MeterApp(context: Context) {
    val store = remember { LocalStore(context) }
    var apartments by remember {
        mutableStateOf(defaultApartments().map { a -> a.copy(address = store.get("address_${a.id}", a.address), meters = a.meters.map { m -> m.copy(serial = store.get("serial_${m.id}"), reading = store.get("reading_${m.id}")) }) })
    }
    var credentialsVersion by remember { mutableIntStateOf(0) }
    var jobs by remember { mutableStateOf(listOf<Job>()) }
    var activeJobIndex by remember { mutableIntStateOf(0) }
    var webUrl by remember { mutableStateOf<String?>(null) }
    var webViewRef by remember { mutableStateOf<WebView?>(null) }
    var settings by remember { mutableStateOf(false) }

    fun updateMeter(apartmentId: Int, meterId: Int, reading: String? = null, serial: String? = null, status: String? = null) {
        apartments = apartments.map { a -> if (a.id != apartmentId) a else a.copy(meters = a.meters.map { m -> if (m.id != meterId) m else m.copy(reading = reading ?: m.reading, serial = serial ?: m.serial, status = status ?: m.status) }) }
        if (reading != null) store.put("reading_$meterId", reading)
        if (serial != null) store.put("serial_$meterId", serial)
    }
    fun updateStatus(job: Job, status: String) = updateMeter(job.apartmentId, job.meterId, status = status)
    fun makeJob(a: Apartment, m: Meter) = Job(a.id, a.address, m.id, m.type, m.title, m.reading, m.serial, store.credentials(a.id))
    fun startJobs(newJobs: List<Job>) { if (newJobs.isNotEmpty()) { jobs = newJobs; activeJobIndex = 0; webUrl = providerUrl(newJobs[0].type) } }
    fun nextJob() { val next = activeJobIndex + 1; if (next >= jobs.size) { webUrl = null } else { activeJobIndex = next; webUrl = providerUrl(jobs[next].type) } }

    if (settings) {
        SettingsScreen(
            apartments = apartments,
            store = store,
            onUpdateAddress = { id, value -> apartments = apartments.map { if (it.id == id) it.copy(address = value) else it }; store.commitAddress("address_$id", value) },
            onUpdateSerial = { id, value -> apartments = apartments.map { a -> a.copy(meters = a.meters.map { m -> if (m.id == id) m.copy(serial = value) else m }) }; store.put("serial_$id", value) },
            onSaved = { credentialsVersion++ },
            onBack = { settings = false }
        )
        return
    }

    if (webUrl != null && jobs.isNotEmpty()) {
        val job = jobs[activeJobIndex]
        ProviderScreen(url = webUrl!!, job = job, index = activeJobIndex + 1, total = jobs.size, onWebViewReady = { webViewRef = it }, onStatus = { updateStatus(job, it) }, onNext = { nextJob() }, onBack = { webUrl = null })
        return
    }

    Scaffold(topBar = { TopAppBar(title = { Text("Счётчики") }, actions = { TextButton({ settings = true }) { Text("Настройки") } }) }, bottomBar = {
        Button(onClick = { startJobs(apartments.flatMap { a -> a.meters.filter { it.reading.isNotBlank() }.map { makeJob(a, it) } }) }, modifier = Modifier.fillMaxWidth().padding(12.dp)) { Text("Передать всё — все квартиры") }
    }) { padding ->
        LazyColumn(Modifier.padding(padding).padding(12.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            items(apartments, key = { it.id }) { apartment ->
                Card(Modifier.fillMaxWidth()) { Column(Modifier.padding(12.dp)) {
                    Text(apartment.address, style = MaterialTheme.typography.titleMedium)
                    Spacer(Modifier.height(8.dp))
                    apartment.meters.forEach { meter ->
                        OutlinedTextField(value = meter.reading, onValueChange = { v -> updateMeter(apartment.id, meter.id, reading = v, status = "Не передано") }, label = { Text("${meter.title} — показание") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text(meter.status)
                            TextButton({ startJobs(listOf(makeJob(apartment, meter))) }) { Text("Передать") }
                        }
                    }
                    Button(onClick = { startJobs(apartment.meters.filter { it.reading.isNotBlank() }.map { makeJob(apartment, it) }) }, Modifier.fillMaxWidth()) { Text("Передать показания этой квартиры") }
                } }
            }
        }
    }
    @Suppress("UNUSED_VARIABLE") val _keep = credentialsVersion
}

@Composable
private fun SettingsScreen(apartments: List<Apartment>, store: LocalStore, onUpdateAddress: (Int, String) -> Unit, onUpdateSerial: (Int, String) -> Unit, onSaved: () -> Unit, onBack: () -> Unit) {
    var selectedId by remember { mutableIntStateOf(1) }
    val a = apartments.first { it.id == selectedId }
    var address by remember(selectedId) { mutableStateOf(store.get("address_$selectedId", a.address)) }
    var energySurname by remember(selectedId) { mutableStateOf(store.get("energy_surname_$selectedId")) }
    var energyAccount by remember(selectedId) { mutableStateOf(store.get("energy_account_$selectedId")) }
    var energySerial by remember(selectedId) { mutableStateOf(store.get("energy_serial_$selectedId")) }
    var waterLogin by remember(selectedId) { mutableStateOf(store.get("water_login_$selectedId")) }
    var waterPassword by remember(selectedId) { mutableStateOf(store.get("water_password_$selectedId")) }
    var gasLogin by remember(selectedId) { mutableStateOf(store.get("gas_login_$selectedId")) }
    var gasPassword by remember(selectedId) { mutableStateOf(store.get("gas_password_$selectedId")) }
    var showWaterPassword by remember(selectedId) { mutableStateOf(false) }
    var showGasPassword by remember(selectedId) { mutableStateOf(false) }

    fun save() {
        onUpdateAddress(selectedId, address)
        store.commitAddress("address_$selectedId", address)
        store.put("energy_surname_$selectedId", energySurname); store.put("energy_account_$selectedId", energyAccount); store.put("energy_serial_$selectedId", energySerial)
        store.put("water_login_$selectedId", waterLogin); store.put("water_password_$selectedId", waterPassword); store.put("gas_login_$selectedId", gasLogin); store.put("gas_password_$selectedId", gasPassword)
        a.meters.forEach { m -> if (m.type == MeterType.ELECTRICITY && energySerial.isNotBlank()) onUpdateSerial(m.id, energySerial) }
        onSaved()
    }
    Scaffold(topBar = { TopAppBar(title = { Text("Настройки") }, navigationIcon = { TextButton(onClick = onBack) { Text("Назад") } }) }) { padding ->
        LazyColumn(Modifier.padding(padding).padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            item { Text("Квартира", style = MaterialTheme.typography.titleMedium); Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) { apartments.forEach { Button(onClick = { save(); selectedId = it.id }, enabled = selectedId != it.id) { Text("${it.id}") } } } }
            item { OutlinedTextField(address, { value -> address = value; onUpdateAddress(selectedId, value); store.commitAddress("address_$selectedId", value) }, label = { Text("Адрес") }, modifier = Modifier.fillMaxWidth()) }
            item { Text("Севэнергосбыт", style = MaterialTheme.typography.titleMedium) }
            item { OutlinedTextField(energySurname, { energySurname = it }, label = { Text("Фамилия") }, modifier = Modifier.fillMaxWidth()) }
            item { OutlinedTextField(energyAccount, { energyAccount = it }, label = { Text("Лицевой счёт") }, modifier = Modifier.fillMaxWidth()) }
            item { OutlinedTextField(energySerial, { energySerial = it }, label = { Text("Номер счётчика") }, modifier = Modifier.fillMaxWidth()) }
            item { Text("Водоканал", style = MaterialTheme.typography.titleMedium) }
            item { OutlinedTextField(waterLogin, { waterLogin = it }, label = { Text("Лицевой счёт / логин") }, modifier = Modifier.fillMaxWidth()) }
            item { OutlinedTextField(waterPassword, { waterPassword = it }, label = { Text("Пароль") }, visualTransformation = if (showWaterPassword) androidx.compose.ui.text.input.VisualTransformation.None else PasswordVisualTransformation(), trailingIcon = { TextButton(onClick = { showWaterPassword = !showWaterPassword }) { Text(if (showWaterPassword) "Скрыть" else "Показать") } }, modifier = Modifier.fillMaxWidth()) }
            item { Text("Севгаз", style = MaterialTheme.typography.titleMedium) }
            item { OutlinedTextField(gasLogin, { gasLogin = it }, label = { Text("Логин") }, modifier = Modifier.fillMaxWidth()) }
            item { OutlinedTextField(gasPassword, { gasPassword = it }, label = { Text("Пароль") }, visualTransformation = if (showGasPassword) androidx.compose.ui.text.input.VisualTransformation.None else PasswordVisualTransformation(), trailingIcon = { TextButton(onClick = { showGasPassword = !showGasPassword }) { Text(if (showGasPassword) "Скрыть" else "Показать") } }, modifier = Modifier.fillMaxWidth()) }
            item { Text("Пароли сохраняются только на этом телефоне.") }
            item { Button(onClick = { save(); onBack() }, modifier = Modifier.fillMaxWidth()) { Text("Сохранить") } }
        }
    }
}

private fun providerUrl(type: MeterType) = when (type) { MeterType.ELECTRICITY -> ENERGY; MeterType.WATER -> WATER; MeterType.GAS -> GAS }

private fun autoFillScript(job: Job): String {
    val reading = JSONObject.quote(job.reading); val serial = JSONObject.quote(job.serial)
    val surname = JSONObject.quote(job.credentials.energySurname); val account = JSONObject.quote(job.credentials.energyAccount)
    val waterLogin = JSONObject.quote(job.credentials.waterLogin); val waterPassword = JSONObject.quote(job.credentials.waterPassword)
    val gasLogin = JSONObject.quote(job.credentials.gasLogin); val gasPassword = JSONObject.quote(job.credentials.gasPassword)
    return """
    (function(){
      const reading=$reading, serial=$serial, surname=$surname, account=$account, wl=$waterLogin, wp=$waterPassword, gl=$gasLogin, gp=$gasPassword;
      function all(){ return [...document.querySelectorAll('input,textarea,[contenteditable="true"]')]; }
      function visible(e){return e && (e.offsetWidth||e.offsetHeight||e.getClientRects().length)}
      function unlock(e){ if(!e)return; e.removeAttribute('disabled'); e.removeAttribute('readonly'); }
      function desc(e){ return ((e.getAttribute('aria-label')||'')+' '+(e.getAttribute('placeholder')||'')+' '+(e.getAttribute('name')||'')+' '+(e.id||'')+' '+((e.labels&&e.labels[0])?e.labels[0].innerText:'')+' '+(e.getAttribute('title')||'')).toLowerCase(); }
      function set(e,v){
        if(!e||v===undefined||v===null||v==='')return false;
        unlock(e); e.focus();
        try{ const proto=e instanceof HTMLTextAreaElement?HTMLTextAreaElement.prototype:HTMLInputElement.prototype; const d=Object.getOwnPropertyDescriptor(proto,'value'); if(d&&d.set)d.set.call(e,v); else e.value=v; }catch(_){e.value=v;}
        try{e.dispatchEvent(new InputEvent('input',{bubbles:true,inputType:'insertText',data:String(v)}));}catch(_){e.dispatchEvent(new Event('input',{bubbles:true}));}
        e.dispatchEvent(new Event('change',{bubbles:true}));
        try{e.dispatchEvent(new KeyboardEvent('keyup',{bubbles:true,key:'1'}));}catch(_){ }
        return true;
      }
      function clickLogin(form){
        const scope=form||document;
        const bs=[...scope.querySelectorAll('button,input[type=submit],input[type=button],a')].filter(visible);
        const b=bs.find(x=>/(войти|вход|login|sign in|авториз|личный кабинет)/i.test((x.innerText||x.value||x.getAttribute('aria-label')||'')+' '+desc(x))) || bs.find(x=>x.type==='submit');
        if(b){unlock(b); b.click(); return true;} return false;
      }
      let found=0, filled=0;
      if(location.host.includes('sevenergosbyt')){
        const f=all().find(e=>visible(e)&&/(фамил|surname)/i.test(desc(e))); if(f){found++; if(set(f,surname))filled++;}
        const a=all().find(e=>visible(e)&&/(лицев|account|абонент)/i.test(desc(e))); if(a){found++; if(set(a,account))filled++;}
        const sn=all().find(e=>visible(e)&&/(номер.*сч|serial|серийн)/i.test(desc(e))); if(sn){found++; if(set(sn,serial))filled++;}
      } else if(location.host.includes('sevvodokanal') || location.host.includes('gup-sevgaz')) {
        const gas=location.host.includes('gup-sevgaz'); const login=gas?gl:wl, pass=gas?gp:wp;
        const pw=all().find(e=>visible(e)&&String(e.type).toLowerCase()==='password');
        if(pw && login && pass){
          let form=pw.form || pw.closest('form'); let l=null;
          const loginRe=/(j_username|username|user(name)?|login|account(number)?|personal|lic|ls|лицев|абонент)/i;
          if(form) {
            const inputs=[...form.querySelectorAll('input')].filter(e=>visible(e)&&e!==pw&&!/(search|поиск)/i.test(desc(e)));
            l=inputs.find(e=>loginRe.test(desc(e)) && ['text','number','tel'].includes(String(e.type||'text').toLowerCase()));
            if(!l) l=inputs.find(e=>/username|login|account|personal|j_username/i.test((e.name||'')+' '+(e.id||'')+' '+(e.autocomplete||'')));
            if(!l) l=inputs.find(e=>['text','number','tel'].includes(String(e.type||'text').toLowerCase()));
          }
          if(!l) l=all().find(e=>visible(e)&&e!==pw&&loginRe.test(desc(e))&&['text','number','tel'].includes(String(e.type||'text').toLowerCase()));
          if(!l) l=all().find(e=>visible(e)&&e!==pw&&['text','number','tel'].includes(String(e.type||'text').toLowerCase())&&!/(search|поиск)/i.test(desc(e)));
          if(l) { found++; if(set(l,login)) filled++; }
          found++; if(set(pw,pass)) filled++;
          const loginValue=()=>l ? String(l.value||'').trim() : '';
          const passValue=()=>String(pw.value||'');
          setTimeout(function(){
            if(l && loginValue()!==String(login).trim()) set(l,login);
            if(passValue()!==String(pass)) set(pw,pass);
            if(form){try{form.dispatchEvent(new Event('input',{bubbles:true})); form.dispatchEvent(new Event('change',{bubbles:true}));}catch(_){}}
            setTimeout(function(){
              if(l && loginValue()===String(login).trim() && passValue()===String(pass)) {
                if(form) { const submit=[...form.querySelectorAll('button,input[type=submit],input[type=button]')].find(b=>visible(b)); if(submit){unlock(submit); submit.click(); return;} }
                clickLogin(form);
              }
            },500);
          },700);
          return JSON.stringify({ok:filled===2,phase:'login',found:found,filledCount:filled,loginUsed:login});
        }
        return JSON.stringify({ok:false,phase:'login',found:found,filledCount:filled,loginUsed:login});
      }
      const meterWords=['показани','показан','потреблен','потребл','текущие показ','текущее показ','объём','объем','reading','meter reading','значение счетчика','значение счётчика'];
      const badWords=['captcha','капч','код с картинки','код картинки','цифр с картинки','изображен','код подтвержден','проверочн','security','защит','с картинки'];
      let candidates=all().filter(e=>visible(e)&&!e.disabled&&e.type!=='hidden'&&e.type!=='password'&&!badWords.some(w=>desc(e).includes(w))&&(e.type==='text'||e.type==='number'||e.tagName==='TEXTAREA'));
      let target=candidates.find(e=>meterWords.some(w=>desc(e).includes(w)));
      if(!target && location.host.includes('sevenergosbyt')) target=candidates.find(e=>!['фамил','лицев','account','счётчик','счетчик','serial','серийн','captcha','капч','картин','код','парол','login'].some(w=>desc(e).includes(w)));
      if(target){found++; if(set(target,reading))filled++; try{target.scrollIntoView({block:'center'});}catch(_){} }
      return JSON.stringify({ok:filled>0,phase:'meter',found:found,filledCount:filled});
    })()
    """.trimIndent()
}

private fun autoSubmitScript(type: MeterType): String {
    val allow = type != MeterType.ELECTRICITY
    return """
    (function(){
      const allowAuto=$allow;
      const bad=/(captcha|капч|код с картинки|код картинки|цифр с картинки|изображен|код подтвержден|проверочн|security|защит)/i;
      const text=e=>((e.innerText||e.value||e.getAttribute('aria-label')||e.getAttribute('title')||'')+'').toLowerCase();
      const vis=e=>e&&(e.offsetWidth||e.offsetHeight||e.getClientRects().length);
      const buttons=[...document.querySelectorAll('button,input[type=submit],input[type=button],a')].filter(vis);
      const captcha=!![...document.querySelectorAll('input,textarea')].find(e=>vis(e)&&bad.test(((e.placeholder||'')+' '+(e.name||'')+' '+(e.id||'')+' '+(e.getAttribute('aria-label')||'')+' '+((e.parentElement&&e.parentElement.innerText)||''))));
      if(!allowAuto && captcha) return JSON.stringify({ok:false,manual:true,reason:'captcha'});
      const re=/(передать|отправить|отправка|сохранить|подтвердить|подтверждаю|продолжить|далее|submit|send|save|confirm|continue|next)/i;
      const candidates=buttons.filter(b=>re.test(text(b))&&!/(войти|вход|login|sign in|авториз)/i.test(text(b)));
      const btn=candidates.find(b=>/передать|отправить|submit|send/i.test(text(b)))||candidates[0];
      if(btn){ try{btn.removeAttribute('disabled');btn.removeAttribute('readonly');}catch(_){}; btn.click(); return JSON.stringify({ok:true,clicked:text(btn)}); }
      return JSON.stringify({ok:false,manual:false});
    })()
    """.trimIndent()
}

@SuppressLint("SetJavaScriptEnabled")
@Composable
fun ProviderScreen(url: String, job: Job, index: Int, total: Int, onWebViewReady: (WebView) -> Unit, onStatus: (String) -> Unit, onNext: () -> Unit, onBack: () -> Unit) {
    var message by remember(url, job.meterId) { mutableStateOf("${job.address}\n${job.title}: ${job.reading}\nПередача $index из $total") }
    var webViewRef by remember { mutableStateOf<WebView?>(null) }
    var busy by remember { mutableStateOf(false) }
    var confirmed by remember { mutableStateOf(false) }

    fun checkConfirmation(w: WebView, attempt: Int = 0) {
        if (confirmed) return
        w.evaluateJavascript("""
            (function(){
              const t=(document.body&&document.body.innerText||'').toLowerCase();
              const ok=/(данн(ые|ых).*(принят|передан|сохран)|показани.*(принят|передан|сохран)|успешн.*(перед|сохран)|спасибо|операция выполнен|передача выполнен|данные отправлен|успешно)/i.test(t);
              const fail=/(ошибк|не удалось|не принят|не передан|неверн|введите капч|captcha)/i.test(t);
              return JSON.stringify({ok:ok,fail:fail});
            })()
        """.trimIndent()) { raw ->
            val r = raw ?: ""
            if (r.contains("\\\"ok\\\":true")) {
                confirmed = true
                busy = false
                message = "✓ ${job.title}: ${job.reading} — показание подтверждено"
                onStatus("Передано ✓")
                w.postDelayed({ onNext() }, 1200)
            } else if (attempt < 10 && !r.contains("\\\"fail\\\":true")) {
                w.postDelayed({ checkConfirmation(w, attempt + 1) }, 900)
            } else {
                busy = false
                message = "Команда отправлена. Подтверждение сайта не найдено — проверь страницу."
                onStatus("Проверить результат")
            }
        }
    }

    fun runFillAndSend() {
        val w = webViewRef ?: run { message = "Страница ещё загружается."; return }
        if (busy) return
        busy = true
        onStatus("Заполняется…")
        message = "1/3 Заполняем данные…"
        w.evaluateJavascript(autoFillScript(job)) { result ->
            val r = result ?: ""
            val ok = r.contains("\\\"ok\\\":true")
            val phase = Regex("\\\"phase\\\":\\\"([^\\\"]+)\\\"").find(r)?.groupValues?.getOrNull(1) ?: "meter"
            val filled = Regex("\\\"filledCount\\\":(\\d+)").find(r)?.groupValues?.getOrNull(1) ?: "0"
            val loginUsed = Regex("\\"loginUsed\\":\\"([^\\"]*)\\"").find(r)?.groupValues?.getOrNull(1) ?: ""
            if (!ok) {
                busy = false
                message = "Не удалось автоматически заполнить нужные поля."
                onStatus("Требуется ввод")
                return@evaluateJavascript
            }
            if (phase == "login") {
                message = "2/3 Водоканал: вход с лицевым счётом $loginUsed…"
                onStatus("Вход…")
                // Login click is already scheduled by the page script. The next page load starts the process again.
                return@evaluateJavascript
            }
            message = "2/3 Показание ${job.reading} заполнено."
            onStatus("Данные заполнены")
            if (job.type == MeterType.ELECTRICITY) {
                busy = false
                message = "2/3 Показание заполнено. Введи CAPTCHA, затем нажми «Передать»."
                onStatus("Ожидает CAPTCHA")
            } else {
                message = "3/3 Передаём показание…"
                onStatus("Передаётся…")
                w.postDelayed({
                    w.evaluateJavascript(autoSubmitScript(job.type)) { sr ->
                        val x = sr ?: ""
                        if (x.contains("\\\"ok\\\":true")) {
                            message = "3/3 Команда отправлена. Ждём подтверждение сайта…"
                            checkConfirmation(w)
                        } else {
                            busy = false
                            message = "Не удалось найти кнопку передачи. Откройте форму и попробуйте ещё раз."
                            onStatus("Требуется ввод")
                        }
                    }
                }, 900)
            }
        }
    }

    fun sendNow() {
        val w = webViewRef ?: return
        if (busy) return
        busy = true
        message = "3/3 Передаём показание ${job.reading}…"
        onStatus("Передаётся…")
        w.evaluateJavascript(autoSubmitScript(job.type)) { r ->
            val x = r ?: ""
            if (x.contains("\\\"ok\\\":true")) {
                message = "Команда отправлена. Ждём подтверждение сайта…"
                checkConfirmation(w)
            } else {
                busy = false
                message = "Кнопку передачи не нашли."
                onStatus("Требуется ввод")
            }
        }
    }

    Column(Modifier.fillMaxSize()) {
        Row(Modifier.fillMaxWidth().padding(8.dp), horizontalArrangement = Arrangement.SpaceBetween) {
            Text("Передача $index/$total", style = MaterialTheme.typography.titleMedium)
            TextButton(onClick = onBack, enabled = !busy) { Text("Назад") }
        }
        Text(message, Modifier.padding(horizontal = 12.dp))
        Row(Modifier.padding(8.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Button(onClick = { runFillAndSend() }, enabled = !busy && !confirmed) { Text("Передать") }
            if (job.type == MeterType.ELECTRICITY) {
                Button(onClick = { sendNow() }, enabled = !busy && !confirmed) { Text("Отправить после CAPTCHA") }
            }
            Button(onClick = onNext, enabled = !busy) { Text(if (index < total) "Пропустить" else "Завершить") }
        }
        AndroidView(factory = { context ->
            WebView(context).apply {
                webViewRef = this
                onWebViewReady(this)
                settings.javaScriptEnabled = true
                settings.domStorageEnabled = true
                settings.databaseEnabled = true
                settings.loadsImagesAutomatically = true
                settings.javaScriptCanOpenWindowsAutomatically = true
                settings.useWideViewPort = true
                settings.loadWithOverviewMode = true
                settings.setSupportZoom(false)
                settings.userAgentString = settings.userAgentString + " ChetchikiApp/0.17"
                webChromeClient = WebChromeClient()
                webViewClient = object : WebViewClient() {
                    override fun onPageFinished(view: WebView, loadedUrl: String) {
                        onWebViewReady(view)
                        if (!confirmed) {
                            message = "Страница загружена. Подготовка передачи…"
                            if (job.type == MeterType.GAS || job.type == MeterType.WATER) {
                                view.postDelayed({ webViewRef = view; runFillAndSend() }, 700)
                                view.postDelayed({ if (!confirmed && !busy) { webViewRef = view; runFillAndSend() } }, 2200)
                                view.postDelayed({ if (!confirmed && !busy) { webViewRef = view; runFillAndSend() } }, 4500)
                            }
                        }
                    }
                }
                loadUrl(url)
            }
        }, modifier = Modifier.fillMaxSize())
    }
}

