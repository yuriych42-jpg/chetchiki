@file:OptIn(ExperimentalMaterial3Api::class)
package ru.chetchiki.app

import android.annotation.SuppressLint
import android.content.Context
import android.os.Bundle
import android.os.SystemClock
import android.view.MotionEvent
import android.webkit.WebView
import android.webkit.WebViewClient
import android.webkit.WebChromeClient
import org.json.JSONObject
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.rememberScrollState
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.viewinterop.AndroidView

enum class MeterType { ELECTRICITY, WATER, GAS }

data class Meter(
    val id: Int,
    val type: MeterType,
    val title: String,
    val serial: String = "",
    val reading: String = "",
    val status: String = "Не передано"
)

data class Apartment(val id: Int, val address: String, val meters: List<Meter>)

data class Credentials(
    val energySurname: String = "",
    val energyAccount: String = "",
    val energySerial: String = "",
    val waterLogin: String = "",
    val waterPassword: String = "",
    val gasLogin: String = "",
    val gasPassword: String = ""
)

data class Job(
    val apartmentId: Int,
    val address: String,
    val meterId: Int,
    val type: MeterType,
    val title: String,
    val reading: String,
    val serial: String = "",
    val credentials: Credentials = Credentials(),
    val providerUrl: String = ""
)

private const val ENERGY = "https://sevenergosbyt.ru/flk/index.php"
private const val WATER = "https://sevvodokanal.org.ru/app/webroot/account.php"
private const val GAS = "https://lk.gup-sevgaz.ru:8080/irb/login.xhtml"

private fun defaultApartments() = listOf(
    Apartment(1, "Адрес квартиры 1", listOf(
        Meter(1, MeterType.ELECTRICITY, "Электричество"), Meter(2, MeterType.WATER, "Вода №1"), Meter(3, MeterType.WATER, "Вода №2"), Meter(4, MeterType.GAS, "Газ")
    )),
    Apartment(2, "Адрес квартиры 2", listOf(
        Meter(5, MeterType.ELECTRICITY, "Электричество"), Meter(6, MeterType.WATER, "Вода"), Meter(7, MeterType.GAS, "Газ")
    )),
    Apartment(3, "Адрес квартиры 3", listOf(
        Meter(8, MeterType.ELECTRICITY, "Электричество"), Meter(9, MeterType.WATER, "Вода"), Meter(10, MeterType.GAS, "Газ")
    )),
    Apartment(4, "Адрес квартиры 4", listOf(
        Meter(11, MeterType.ELECTRICITY, "Электричество"), Meter(12, MeterType.WATER, "Вода №1"), Meter(13, MeterType.WATER, "Вода №2"), Meter(14, MeterType.GAS, "Газ")
    ))
)

private fun newApartment(id: Int) = Apartment(id, "Адрес квартиры $id", listOf(
    Meter(id * 100 + 1, MeterType.ELECTRICITY, "Электричество"),
    Meter(id * 100 + 2, MeterType.WATER, "Вода"),
    Meter(id * 100 + 3, MeterType.GAS, "Газ")
))

// ГАЗ КВАРТИР 1–4: автоматический вход и подготовка показания — ВЕРСИЯ 0.92
class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { MeterApp(applicationContext) }
    }
}

private class LocalStore(context: Context) {
    private val p = context.getSharedPreferences("meter_store", Context.MODE_PRIVATE)
    fun get(k: String, d: String = "") = p.getString(k, d) ?: d
    fun put(k: String, v: String) { p.edit().putString(k, v).commit() }
    fun gasCookies(id: Int): String = get("gas_cookies_$id")
    fun putGasCookies(id: Int, v: String) { p.edit().putString("gas_cookies_$id", v).apply() }
    fun commitAddress(k: String, v: String) { p.edit().putString(k, v).commit() }
    fun apartmentIds(): List<Int> {
        val saved = get("apartment_ids")
        if (saved.isBlank()) {
            val ids = defaultApartments().map { it.id }
            p.edit().putString("apartment_ids", ids.joinToString(",")).commit()
            return ids
        }
        return saved.split(",").mapNotNull { it.trim().toIntOrNull() }.distinct().sorted()
    }
    fun saveApartmentIds(ids: List<Int>) { p.edit().putString("apartment_ids", ids.distinct().sorted().joinToString(",")).commit() }
    fun providerUrl(id: Int, type: MeterType): String = get("provider_url_${type.name}_$id", when (type) { MeterType.ELECTRICITY -> ENERGY; MeterType.WATER -> WATER; MeterType.GAS -> GAS })
    fun saveProviderUrl(id: Int, type: MeterType, value: String) { put("provider_url_${type.name}_$id", value) }
    fun meterIds(id: Int, fallback: List<Meter>): List<Int> {
        val saved = get("meter_ids_$id")
        if (saved.isBlank()) {
            val ids = fallback.map { it.id }
            put("meter_ids_$id", ids.joinToString(","))
            return ids
        }
        return saved.split(",").mapNotNull { it.trim().toIntOrNull() }.distinct()
    }
    fun saveMeterIds(id: Int, ids: List<Int>) { put("meter_ids_$id", ids.distinct().joinToString(",")) }
    fun meterType(id: Int, meterId: Int, fallback: MeterType): MeterType = try { MeterType.valueOf(get("meter_type_${id}_$meterId", fallback.name)) } catch (_: Exception) { fallback }
    fun meterTitle(id: Int, meterId: Int, fallback: String): String = get("meter_title_${id}_$meterId", fallback)
    fun saveMeter(id: Int, meter: Meter) {
        put("meter_type_${id}_${meter.id}", meter.type.name)
        put("meter_title_${id}_${meter.id}", meter.title)
    }
    fun previousReading(meterId: Int): String = get("previous_reading_$meterId")
    fun savePreviousReading(meterId: Int, value: String) { if (value.isNotBlank()) put("previous_reading_$meterId", value) }
    fun clearReading(meterId: Int) {
        val current = get("reading_$meterId")
        if (current.isNotBlank()) savePreviousReading(meterId, current)
        p.edit().remove("reading_$meterId").putString("status_$meterId", "Не передано").apply()
    }
    fun deleteMeterData(meterId: Int) { p.edit().remove("reading_$meterId").remove("previous_reading_$meterId").remove("serial_$meterId").remove("status_$meterId").apply() }
    fun waterLogin(id: Int): String {
        // Only provide the known default for apartment 1 when no value exists.
        // Never overwrite a value that the user has entered and saved.
        val key = "water_login_$id"
        val saved = get(key)
        if (id == 1 && saved.isBlank()) {
            commitAddress(key, "30118")
            return "30118"
        }
        return saved
    }
    fun credentials(id: Int) = Credentials(
        get("energy_surname_$id"), get("energy_account_$id"), get("energy_serial_$id"),
        waterLogin(id), get("water_password_$id"), get("gas_login_$id"), get("gas_password_$id")
    )
}

@Composable
fun MeterApp(context: Context) {
    val store = remember { LocalStore(context) }
    var apartments by remember {
        mutableStateOf(store.apartmentIds().map { id ->
            val base = defaultApartments().firstOrNull { it.id == id } ?: newApartment(id)
            val baseById = base.meters.associateBy { it.id }
            val ids = store.meterIds(id, base.meters)
            val configuredMeters = ids.mapNotNull { meterId ->
                val fallback = baseById[meterId]
                if (fallback != null) fallback else {
                    val type = store.meterType(id, meterId, MeterType.WATER)
                    val title = store.meterTitle(id, meterId, if (type == MeterType.ELECTRICITY) "Электричество" else "Вода")
                    Meter(meterId, type, title)
                }
            }.map { m -> m.copy(type = store.meterType(id, m.id, m.type), title = store.meterTitle(id, m.id, m.title), serial = store.get("serial_${m.id}"), reading = store.get("reading_${m.id}"), status = store.get("status_${m.id}", "Не передано")) }
            base.copy(address = store.get("address_${id}", base.address), meters = configuredMeters)
        })
    }
    var credentialsVersion by remember { mutableIntStateOf(0) }
    var jobs by remember { mutableStateOf(listOf<Job>()) }
    var activeJobIndex by remember { mutableIntStateOf(0) }
    var webUrl by remember { mutableStateOf<String?>(null) }
    var webViewRef by remember { mutableStateOf<WebView?>(null) }
    var settings by remember { mutableStateOf(false) }

    fun updateMeter(apartmentId: Int, meterId: Int, reading: String? = null, serial: String? = null, status: String? = null) {
        apartments = apartments.map { a -> if (a.id != apartmentId) a else a.copy(meters = a.meters.map { m -> if (m.id != meterId) m else m.copy(reading = reading ?: m.reading, serial = serial ?: m.serial, status = status ?: m.status) }) }
        if (reading != null) store.put("reading_$meterId", reading)
        if (serial != null) store.put("serial_$meterId", serial)
        if (status != null) store.put("status_$meterId", status)
    }
    fun updateStatus(job: Job, status: String) = updateMeter(job.apartmentId, job.meterId, status = status)
    fun clearMeterReading(apartmentId: Int, meterId: Int) {
        apartments = apartments.map { a -> if (a.id != apartmentId) a else a.copy(meters = a.meters.map { m -> if (m.id == meterId) m.copy(reading = "", status = "Не передано") else m }) }
        store.clearReading(meterId)
    }
    fun clearApartmentReadings(apartmentId: Int) {
        val apartment = apartments.firstOrNull { it.id == apartmentId } ?: return
        apartment.meters.forEach { store.clearReading(it.id) }
        apartments = apartments.map { a -> if (a.id != apartmentId) a else a.copy(meters = a.meters.map { it.copy(reading = "", status = "Не передано") }) }
    }
    fun clearAllReadings() {
        apartments.flatMap { it.meters }.forEach { store.clearReading(it.id) }
        apartments = apartments.map { a -> a.copy(meters = a.meters.map { it.copy(reading = "", status = "Не передано") }) }
    }

    fun makeJob(a: Apartment, m: Meter): Job {
        // Критично: учётные данные всегда принадлежат выбранной квартире.
        // Раньше здесь для света и газа был ошибочный hard-code credentials(1),
        // из-за чего после переключения квартиры оставался ЛК предыдущей квартиры.
        // Алгоритм передачи света/газа общий, но credentials — выбранной квартиры.
        val credentials = store.credentials(a.id)
        return Job(a.id, a.address, m.id, m.type, m.title, m.reading, m.serial, credentials, store.providerUrl(a.id, m.type))
    }

    // Единый алгоритм передачи для каждой квартиры:
    // 1) электричество -> 2) вода -> 3) газ.
    // Порядок не зависит от того, как счётчики записаны в конфигурации квартиры.
    fun orderedJobs(a: Apartment, meters: List<Meter> = a.meters): List<Job> {
        val order = listOf(MeterType.ELECTRICITY, MeterType.WATER, MeterType.GAS)
        return order.flatMap { type ->
            meters.filter { it.type == type && it.reading.isNotBlank() }.map { makeJob(a, it) }
        }
    }

    fun startJobs(newJobs: List<Job>) {
        if (newJobs.isNotEmpty()) {
            jobs = newJobs
            activeJobIndex = 0
            webUrl = newJobs[0].providerUrl
        }
    }
    fun nextJob() { val next = activeJobIndex + 1; if (next >= jobs.size) { webUrl = null } else { activeJobIndex = next; webUrl = jobs[next].providerUrl } }

    if (settings) {
        SettingsScreen(
            apartments = apartments,
            store = store,
            onUpdateAddress = { id, value -> apartments = apartments.map { if (it.id == id) it.copy(address = value) else it }; store.commitAddress("address_$id", value) },
            onUpdateSerial = { id, value -> apartments = apartments.map { a -> a.copy(meters = a.meters.map { m -> if (m.id == id) m.copy(serial = value) else m }) }; store.put("serial_$id", value) },
            onAddMeter = addMeter@{ apartmentId, type ->
                val apartment = apartments.firstOrNull { it.id == apartmentId }
                if (apartment == null) return@addMeter
                val newMeterId = (apartments.flatMap { it.meters }.maxOfOrNull { it.id } ?: 0) + 1
                val count = apartment.meters.count { it.type == type } + 1
                val title = if (type == MeterType.ELECTRICITY) { if (count == 1) "Электричество" else "Электричество №$count" } else { if (count == 1) "Вода" else "Вода №$count" }
                val meter = Meter(newMeterId, type, title)
                apartments = apartments.map { if (it.id == apartmentId) it.copy(meters = it.meters + meter) else it }
                store.saveMeter(apartmentId, meter)
                store.saveMeterIds(apartmentId, apartments.first { it.id == apartmentId }.meters.map { it.id })
            },
            onDeleteMeter = deleteMeter@{ apartmentId, meterId ->
                val apartment = apartments.firstOrNull { it.id == apartmentId }
                if (apartment == null) return@deleteMeter
                val meter = apartment.meters.firstOrNull { it.id == meterId }
                if (meter == null || (meter.type != MeterType.ELECTRICITY && meter.type != MeterType.WATER)) return@deleteMeter
                val remaining = apartment.meters.filterNot { it.id == meterId }
                apartments = apartments.map { if (it.id == apartmentId) it.copy(meters = remaining) else it }
                store.saveMeterIds(apartmentId, remaining.map { it.id })
                store.deleteMeterData(meterId)
            },
            onAddApartment = {
                val newId = ((apartments.maxOfOrNull { it.id } ?: 0) + 1)
                val added = newApartment(newId)
                apartments = apartments + added
                store.saveApartmentIds(apartments.map { it.id })
            },
            onDeleteApartment = { id ->
                if (apartments.size > 1) {
                    apartments = apartments.filterNot { it.id == id }
                    store.saveApartmentIds(apartments.map { it.id })
                }
            },
            onSaved = { credentialsVersion++ },
            onBack = { settings = false }
        )
        return
    }

    if (webUrl != null && jobs.isNotEmpty()) {
        val job = jobs[activeJobIndex]
        ProviderScreen(url = webUrl!!, job = job, index = activeJobIndex + 1, total = jobs.size, store = store, onWebViewReady = { webViewRef = it }, onStatus = { updateStatus(job, it) }, onNext = { nextJob() }, onBack = { webUrl = null })
        return
    }

    Scaffold(topBar = { TopAppBar(title = { Text("Счётчики") }, actions = { TextButton({ settings = true }) { Text("Настройки") } }) }, bottomBar = {
        Button(onClick = { startJobs(apartments.flatMap { a -> orderedJobs(a) }) }, modifier = Modifier.fillMaxWidth().padding(12.dp)) { Text("Передать всё — все квартиры") }
    }) { padding ->
        Column(Modifier.fillMaxSize()) {
            Surface(Modifier.fillMaxWidth(), tonalElevation = 4.dp) {
                Text("КОНТРОЛЬНАЯ ВЕРСИЯ 1.03", modifier = Modifier.padding(16.dp), style = MaterialTheme.typography.headlineSmall)
            }
            LazyColumn(Modifier.weight(1f).padding(padding).padding(12.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            item {
                OutlinedButton(onClick = { clearAllReadings() }, modifier = Modifier.fillMaxWidth()) { Text("Очистить показания всех квартир") }
            }
            items(apartments, key = { it.id }) { apartment ->
                Card(Modifier.fillMaxWidth()) { Column(Modifier.padding(12.dp)) {
                    Text(apartment.address, style = MaterialTheme.typography.titleMedium)
                    Spacer(Modifier.height(8.dp))
                    val meterGroups = listOf(MeterType.ELECTRICITY, MeterType.WATER, MeterType.GAS)
                        .map { type -> type to apartment.meters.filter { it.type == type } }
                        .filter { it.second.isNotEmpty() }

                    meterGroups.forEach { (type, groupMeters) ->
                        val typeJobs = orderedJobs(apartment, groupMeters)
                        Column(
                            modifier = Modifier.fillMaxWidth(),
                            verticalArrangement = Arrangement.spacedBy(4.dp)
                        ) {
                            groupMeters.forEachIndexed { index, meter ->
                                val previous = store.previousReading(meter.id)
                                Box(modifier = Modifier.fillMaxWidth()) {
                                    OutlinedTextField(
                                        value = meter.reading,
                                        onValueChange = { v -> updateMeter(apartment.id, meter.id, reading = v, status = "Не передано") },
                                        label = { Text("${meter.title} — новое показание") },
                                        singleLine = true,
                                        modifier = Modifier.fillMaxWidth()
                                    )
                                    if (previous.isNotBlank()) {
                                        Text(
                                            text = "Предыдущее: $previous",
                                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                                            style = MaterialTheme.typography.bodySmall,
                                            maxLines = 1,
                                            softWrap = false,
                                            overflow = TextOverflow.Ellipsis,
                                            modifier = Modifier
                                                .align(Alignment.BottomStart)
                                                .padding(start = 16.dp, bottom = 6.dp)
                                        )
                                    }
                                }
                                Row(
                                    Modifier
                                        .fillMaxWidth()
                                        .height(40.dp),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text(meter.status)
                                    if (index != groupMeters.lastIndex) {
                                        TextButton(
                                            onClick = { clearMeterReading(apartment.id, meter.id) },
                                            contentPadding = PaddingValues(horizontal = 8.dp, vertical = 0.dp)
                                        ) { Text("Очистить") }
                                    }
                                }

                                // После последнего поля общая кнопка передачи будет рядом
                                // с кнопкой очистки именно этого последнего поля.
                                if (index == groupMeters.lastIndex) {
                                    Row(
                                        Modifier
                                            .fillMaxWidth()
                                            .height(40.dp),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Button(
                                            onClick = { startJobs(typeJobs) },
                                            enabled = typeJobs.isNotEmpty(),
                                            contentPadding = PaddingValues(horizontal = 16.dp, vertical = 0.dp)
                                        ) {
                                            Text("Передать")
                                        }
                                        TextButton(
                                            onClick = { clearMeterReading(apartment.id, meter.id) },
                                            contentPadding = PaddingValues(horizontal = 8.dp, vertical = 0.dp)
                                        ) {
                                            Text("Очистить")
                                        }
                                    }
                                }
                            }
                        }
                    }
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedButton(onClick = { clearApartmentReadings(apartment.id) }, modifier = Modifier.weight(1f)) { Text("Очистить всё") }
                        Button(onClick = { startJobs(orderedJobs(apartment)) }, modifier = Modifier.weight(1f)) { Text("Передать показания этой квартиры") }
                    }
                } }
            }
        }
        }
    }
    @Suppress("UNUSED_VARIABLE") val _keep = credentialsVersion
}

@Composable
private fun SettingsScreen(
    apartments: List<Apartment>,
    store: LocalStore,
    onUpdateAddress: (Int, String) -> Unit,
    onUpdateSerial: (Int, String) -> Unit,
    onAddMeter: (Int, MeterType) -> Unit,
    onDeleteMeter: (Int, Int) -> Unit,
    onAddApartment: () -> Unit,
    onDeleteApartment: (Int) -> Unit,
    onSaved: () -> Unit,
    onBack: () -> Unit
) {
    var selectedId by remember { mutableIntStateOf(apartments.firstOrNull()?.id ?: 1) }
    var address by remember { mutableStateOf("") }
    var apartmentLabel by remember { mutableStateOf("") }
    var showDeleteConfirmation by remember { mutableStateOf(false) }
    var energySurname by remember { mutableStateOf("") }
    var energyAccount by remember { mutableStateOf("") }
    var energySerial by remember { mutableStateOf("") }
    var waterLogin by remember { mutableStateOf("") }
    var waterPassword by remember { mutableStateOf("") }
    var gasLogin by remember { mutableStateOf("") }
    var gasPassword by remember { mutableStateOf("") }
    var energyUrl by remember { mutableStateOf(ENERGY) }
    var waterUrl by remember { mutableStateOf(WATER) }
    var gasUrl by remember { mutableStateOf(GAS) }
    var showWaterPassword by remember { mutableStateOf(false) }
    var showGasPassword by remember { mutableStateOf(false) }

    fun loadApartment(id: Int) {
        val a = apartments.firstOrNull { it.id == id } ?: return
        selectedId = id
        address = store.get("address_$id", a.address)
        apartmentLabel = store.get("apartment_label_$id", "Кв. $id")
        energySurname = store.get("energy_surname_$id")
        energyAccount = store.get("energy_account_$id")
        energySerial = store.get("energy_serial_$id")
        waterLogin = store.waterLogin(id)
        waterPassword = store.get("water_password_$id")
        gasLogin = store.get("gas_login_$id")
        gasPassword = store.get("gas_password_$id")
        energyUrl = store.providerUrl(id, MeterType.ELECTRICITY)
        waterUrl = store.providerUrl(id, MeterType.WATER)
        gasUrl = store.providerUrl(id, MeterType.GAS)
        showWaterPassword = false
        showGasPassword = false
    }

    LaunchedEffect(Unit) { loadApartment(selectedId) }

    fun saveApartment(id: Int = selectedId) {
        // IMPORTANT: only write fields when id is the currently displayed apartment.
        // This prevents a stale Compose field from being written to another apartment.
        if (id != selectedId) return
        store.commitAddress("address_$id", address)
        store.put("apartment_label_$id", apartmentLabel.trim().ifBlank { "Кв. $id" })
        onUpdateAddress(id, address)
        store.put("energy_surname_$id", energySurname)
        store.put("energy_account_$id", energyAccount)
        store.put("energy_serial_$id", energySerial)
        store.put("water_login_$id", waterLogin)
        store.put("water_password_$id", waterPassword)
        store.put("gas_login_$id", gasLogin)
        store.put("gas_password_$id", gasPassword)
        store.saveProviderUrl(id, MeterType.ELECTRICITY, energyUrl.trim().ifBlank { ENERGY })
        store.saveProviderUrl(id, MeterType.WATER, waterUrl.trim().ifBlank { WATER })
        store.saveProviderUrl(id, MeterType.GAS, gasUrl.trim().ifBlank { GAS })
        apartments.firstOrNull { it.id == id }?.meters?.forEach { m ->
            if (m.type == MeterType.ELECTRICITY && energySerial.isNotBlank()) onUpdateSerial(m.id, energySerial)
        }
        onSaved()
    }

    Scaffold(topBar = { TopAppBar(title = { Text("Настройки") }, navigationIcon = { TextButton(onClick = onBack) { Text("Назад") } }) }) { padding ->
        LazyColumn(Modifier.padding(padding).padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            item {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text("Квартиры", style = MaterialTheme.typography.titleMedium)
                    Button(onClick = { saveApartment(); onAddApartment() }) { Text("+ Добавить") }
                }
            }
            item {
                Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    apartments.forEach { apartment ->
                        Button(
                            onClick = {
                                if (selectedId != apartment.id) {
                                    saveApartment(selectedId)
                                    loadApartment(apartment.id)
                                }
                            },
                            enabled = selectedId != apartment.id,
                            contentPadding = PaddingValues(horizontal = 10.dp, vertical = 8.dp)
                        ) {
                            Column {
                                Text(
                                    store.get("apartment_label_${apartment.id}", "Кв. ${apartment.id}"),
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                                Text(
                                    store.get("address_${apartment.id}", apartment.address).ifBlank { "Без адреса" },
                                    maxLines = 2,
                                    overflow = TextOverflow.Ellipsis,
                                    style = MaterialTheme.typography.labelSmall
                                )
                            }
                        }
                    }
                }
            }
            item {
                OutlinedTextField(
                    apartmentLabel,
                    { apartmentLabel = it },
                    label = { Text("Название кнопки квартиры") },
                    supportingText = { Text("Это название будет показано вместо «Кв. $selectedId».") },
                    modifier = Modifier.fillMaxWidth()
                )
            }
            item { OutlinedTextField(address, { address = it }, label = { Text("Адрес") }, modifier = Modifier.fillMaxWidth()) }
            item {
                if (apartments.size > 1) {
                    OutlinedButton(
                        onClick = { showDeleteConfirmation = true },
                        modifier = Modifier.fillMaxWidth()
                    ) { Text("Удалить квартиру $selectedId") }
                }
            }
            item {
                Text("Поля для передачи показаний", style = MaterialTheme.typography.titleMedium)
                Text("Можно добавлять и удалять поля для воды и электричества. Газ остаётся отдельным полем.", style = MaterialTheme.typography.bodySmall)
            }
            item {
                apartments.firstOrNull { it.id == selectedId }?.meters?.filter { it.type == MeterType.ELECTRICITY || it.type == MeterType.WATER }?.forEach { meter ->
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text(meter.title, modifier = Modifier.weight(1f))
                        TextButton(onClick = { onDeleteMeter(selectedId, meter.id) }) { Text("Удалить") }
                    }
                }
            }
            item {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Button(onClick = { onAddMeter(selectedId, MeterType.ELECTRICITY) }, modifier = Modifier.weight(1f)) { Text("+ Свет") }
                    Button(onClick = { onAddMeter(selectedId, MeterType.WATER) }, modifier = Modifier.weight(1f)) { Text("+ Вода") }
                }
            }
            item { Text("Севэнергосбыт", style = MaterialTheme.typography.titleMedium) }
            item { OutlinedTextField(energySurname, { energySurname = it }, label = { Text("Фамилия") }, modifier = Modifier.fillMaxWidth()) }
            item { OutlinedTextField(energyAccount, { energyAccount = it }, label = { Text("Лицевой счёт") }, modifier = Modifier.fillMaxWidth()) }
            item { OutlinedTextField(energySerial, { energySerial = it }, label = { Text("Номер счётчика") }, modifier = Modifier.fillMaxWidth()) }
            item { OutlinedTextField(energyUrl, { energyUrl = it }, label = { Text("Адрес личного кабинета") }, modifier = Modifier.fillMaxWidth()) }
            item { Text("Водоканал", style = MaterialTheme.typography.titleMedium) }
            item { OutlinedTextField(waterLogin, { waterLogin = it }, label = { Text("Лицевой счёт / логин") }, modifier = Modifier.fillMaxWidth()) }
            item { OutlinedTextField(waterPassword, { waterPassword = it }, label = { Text("Пароль") }, visualTransformation = if (showWaterPassword) androidx.compose.ui.text.input.VisualTransformation.None else PasswordVisualTransformation(), trailingIcon = { TextButton(onClick = { showWaterPassword = !showWaterPassword }) { Text(if (showWaterPassword) "Скрыть" else "Показать") } }, modifier = Modifier.fillMaxWidth()) }
            item { OutlinedTextField(waterUrl, { waterUrl = it }, label = { Text("Адрес личного кабинета") }, modifier = Modifier.fillMaxWidth()) }
            item { Text("Севгаз", style = MaterialTheme.typography.titleMedium) }
            item { OutlinedTextField(gasLogin, { gasLogin = it }, label = { Text("Логин") }, modifier = Modifier.fillMaxWidth()) }
            item { OutlinedTextField(gasPassword, { gasPassword = it }, label = { Text("Пароль") }, visualTransformation = if (showGasPassword) androidx.compose.ui.text.input.VisualTransformation.None else PasswordVisualTransformation(), trailingIcon = { TextButton(onClick = { showGasPassword = !showGasPassword }) { Text(if (showGasPassword) "Скрыть" else "Показать") } }, modifier = Modifier.fillMaxWidth()) }
            item { OutlinedTextField(gasUrl, { gasUrl = it }, label = { Text("Адрес личного кабинета") }, modifier = Modifier.fillMaxWidth()) }
            item { Text("Адреса личных кабинетов сохраняются отдельно для каждой квартиры.") }
            item { Text("Пароли сохраняются только на этом телефоне.") }
            item { Button(onClick = { saveApartment() }, modifier = Modifier.fillMaxWidth()) { Text("Сохранить") } }
        }
    }

    if (showDeleteConfirmation) {
        AlertDialog(
            onDismissRequest = { showDeleteConfirmation = false },
            title = { Text("Удалить квартиру?") },
            text = {
                Text(
                    "Квартира «${apartmentLabel.ifBlank { "Кв. $selectedId" }}» будет удалена вместе с её настройками. Это действие нельзя отменить."
                )
            },
            confirmButton = {
                TextButton(
                    onClick = {
                        showDeleteConfirmation = false
                        val deletedId = selectedId
                        saveApartment(deletedId)
                        onDeleteApartment(deletedId)
                        val next = apartments.firstOrNull { it.id != deletedId }
                        if (next != null) loadApartment(next.id)
                    }
                ) { Text("Удалить") }
            },
            dismissButton = {
                TextButton(onClick = { showDeleteConfirmation = false }) { Text("Отмена") }
            }
        )
    }
}

private fun providerUrl(type: MeterType) = when (type) { MeterType.ELECTRICITY -> ENERGY; MeterType.WATER -> WATER; MeterType.GAS -> GAS }

private fun autoFillScript(job: Job): String {
    val reading = JSONObject.quote(job.reading); val serial = JSONObject.quote(job.serial)
    val surname = JSONObject.quote(job.credentials.energySurname); val account = JSONObject.quote(job.credentials.energyAccount)
    val waterLogin = JSONObject.quote(job.credentials.waterLogin); val waterPassword = JSONObject.quote(job.credentials.waterPassword)
    val gasLogin = JSONObject.quote(job.credentials.gasLogin); val gasPassword = JSONObject.quote(job.credentials.gasPassword)
    return """
    (function(){
      const reading=$reading, serial=$serial, surname=$surname, account=$account, wl=$waterLogin, wp=$waterPassword, gl=$gasLogin, gp=$gasPassword;
      function all(){ return [...document.querySelectorAll('input,textarea,[contenteditable="true"]')]; }
      function visible(e){return e && (e.offsetWidth||e.offsetHeight||e.getClientRects().length)}
      function unlock(e){ if(!e)return; e.removeAttribute('disabled'); e.removeAttribute('readonly'); }
      function desc(e){ return ((e.getAttribute('aria-label')||'')+' '+(e.getAttribute('placeholder')||'')+' '+(e.getAttribute('name')||'')+' '+(e.id||'')+' '+((e.labels&&e.labels[0])?e.labels[0].innerText:'')+' '+(e.getAttribute('title')||'')).toLowerCase(); }
      function set(e,v){
        if(!e||v===undefined||v===null||v==='')return false;
        unlock(e); e.focus();
        try{ const proto=e instanceof HTMLTextAreaElement?HTMLTextAreaElement.prototype:HTMLInputElement.prototype; const d=Object.getOwnPropertyDescriptor(proto,'value'); if(d&&d.set)d.set.call(e,v); else e.value=v; }catch(_){e.value=v;}
        try{e.dispatchEvent(new InputEvent('input',{bubbles:true,inputType:'insertText',data:String(v)}));}catch(_){e.dispatchEvent(new Event('input',{bubbles:true}));}
        e.dispatchEvent(new Event('change',{bubbles:true}));
        try{e.dispatchEvent(new KeyboardEvent('keyup',{bubbles:true,key:'1'}));}catch(_){ }
        return true;
      }
      function clickLogin(form){
        const scope=form||document;
        const bs=[...scope.querySelectorAll('button,input[type=submit],input[type=button],a')].filter(visible);
        const b=bs.find(x=>/(войти|вход|login|sign in|авториз|личный кабинет)/i.test((x.innerText||x.value||x.getAttribute('aria-label')||'')+' '+desc(x))) || bs.find(x=>x.type==='submit');
        if(b){unlock(b); b.click(); return true;} return false;
      }
      let found=0, filled=0;
      if(location.host.includes('gup-sevgaz.ru') && !location.host.includes('lk.gup-sevgaz.ru')){
        const links=[...document.querySelectorAll('a,button,[role=button],div[onclick],span[onclick]')].filter(visible);
        const lk=links.find(e=>/(личный кабинет|личный\s+кабинет)/i.test((e.innerText||e.textContent||e.getAttribute('aria-label')||'')+' '+desc(e)))
          || links.find(e=>/личный.?кабинет|lk\.|irb\/login|login/i.test((e.getAttribute('href')||'')+' '+(e.getAttribute('data-href')||'')+' '+(e.getAttribute('onclick')||'')));
        if(lk){ unlock(lk); try{lk.click();}catch(_){} return JSON.stringify({ok:false,phase:'gas_lk'}); }
        return JSON.stringify({ok:false,phase:'login_wait'});
      }
      if(location.host.includes('sevenergosbyt')){
        const f=all().find(e=>visible(e)&&/(фамил|surname)/i.test(desc(e))); if(f){found++; if(set(f,surname))filled++;}
        const a=all().find(e=>visible(e)&&/(лицев|account|абонент)/i.test(desc(e))); if(a){found++; if(set(a,account))filled++;}
        const sn=all().find(e=>visible(e)&&/(номер.*сч|serial|серийн)/i.test(desc(e))); if(sn){found++; if(set(sn,serial))filled++;}
      } else if(location.host.includes('sevvodokanal') || location.host.includes('gup-sevgaz') || location.host.includes('sevgas')) {
        const gas=location.host.includes('gup-sevgaz') || location.host.includes('sevgas'); const login=gas?gl:wl, pass=gas?gp:wp;
        const pw=all().find(e=>visible(e)&&String(e.type).toLowerCase()==='password');
        if(pw && login && pass){
          let form=pw.form || pw.closest('form'); let l=null;
          const loginRe=/(j_username|username|user(name)?|login|account(number)?|personal|lic|ls|лицев|абонент)/i;
          if(form) {
            const inputs=[...form.querySelectorAll('input')].filter(e=>visible(e)&&e!==pw&&!/(search|поиск)/i.test(desc(e)));
            l=inputs.find(e=>/j_username/i.test((e.name||'')+' '+(e.id||'')));
            if(!l) l=inputs.find(e=>loginRe.test(desc(e)) && ['text','number','tel'].includes(String(e.type||'text').toLowerCase()));
            if(!l) l=inputs.find(e=>/username|login|account|personal|j_username/i.test((e.name||'')+' '+(e.id||'')+' '+(e.autocomplete||'')));
            if(!l) l=inputs.find(e=>['text','number','tel'].includes(String(e.type||'text').toLowerCase()));
          }
          if(!l) l=all().find(e=>visible(e)&&e!==pw&&loginRe.test(desc(e))&&['text','number','tel'].includes(String(e.type||'text').toLowerCase()));
          if(!l) l=all().find(e=>visible(e)&&e!==pw&&['text','number','tel'].includes(String(e.type||'text').toLowerCase())&&!/(search|поиск)/i.test(desc(e)));
          if(l) { found++; if(set(l,login)) filled++; }
          found++; if(set(pw,pass)) filled++;
          const loginValue=()=>l ? String(l.value||'').trim() : '';
          const passValue=()=>String(pw.value||'');
          function doLogin(){
            if(l && loginValue()!==String(login).trim()) set(l,login);
            if(passValue()!==String(pass)) set(pw,pass);
            if(!form) return clickLogin(document);
            try{form.dispatchEvent(new Event('input',{bubbles:true})); form.dispatchEvent(new Event('change',{bubbles:true}));}catch(_){}
            const inForm=[...form.querySelectorAll('button,input[type=submit],input[type=button],input[type=image],a,[role=button]')];
            const allSubmit=[...document.querySelectorAll('button,input[type=submit],input[type=button],input[type=image],a,[role=button]')];
            const submit=inForm.find(b=>visible(b) && /(войти|вход|login|sign in|авториз|посмотреть)/i.test((b.innerText||b.value||b.getAttribute('aria-label')||'')+' '+desc(b)))
              || inForm.find(b=>visible(b))
              || allSubmit.find(b=>visible(b) && /(войти|вход|login|sign in|авториз|посмотреть)/i.test((b.innerText||b.value||b.getAttribute('aria-label')||'')+' '+desc(b)));
            if(submit){
              unlock(submit);
              try{submit.focus();}catch(_){}
              try{submit.dispatchEvent(new MouseEvent('mousedown',{bubbles:true,cancelable:true}));}catch(_){}
              try{submit.dispatchEvent(new MouseEvent('mouseup',{bubbles:true,cancelable:true}));}catch(_){}
              try{submit.click();}catch(_){}
              setTimeout(function(){try{if(typeof form.requestSubmit==='function')form.requestSubmit(submit);}catch(_){}},300);
              return true;
            }
            try{if(form.requestSubmit){form.requestSubmit(); return true;}}catch(_){}
            try{HTMLFormElement.prototype.submit.call(form); return true;}catch(_){}
            return clickLogin(form);
          }
          setTimeout(function(){
            doLogin();
            try{if(pw){pw.focus(); pw.dispatchEvent(new KeyboardEvent('keydown',{bubbles:true,key:'Enter',code:'Enter',keyCode:13,which:13})); pw.dispatchEvent(new KeyboardEvent('keyup',{bubbles:true,key:'Enter',code:'Enter',keyCode:13,which:13}));}}catch(_){}
          },700);
          setTimeout(doLogin,2200);
          return JSON.stringify({ok:filled===2,phase:'login',found:found,filledCount:filled,loginUsed:login});
        }
        return JSON.stringify({ok:false,phase:'login',found:found,filledCount:filled,loginUsed:login});
      }
      // IMPORTANT: login pages are handled above. Never search for a meter-reading
      // field while a provider login form is still visible.
      const pageText=(document.body&&document.body.innerText||'').toLowerCase();
      if(location.host.includes('gup-sevgaz') || location.host.includes('sevgas')){
        const clickables=[...document.querySelectorAll('button,input[type=button],input[type=submit],input[type=image],a,[role=button]')].filter(visible);
        const clickText=e=>((e.innerText||e.value||e.getAttribute('aria-label')||e.getAttribute('title')||'')+' '+desc(e)).toLowerCase();
        const hasCounters=/(сч[её]тчики|узлы\s*уч[её]та|приборы\s*уч[её]та)/i.test(pageText);
        const hasReadingForm=/(предоставление показаний|показания сч[её]тчика|передать показания)/i.test(pageText);
        if(!hasCounters){
          const b=clickables.find(e=>/^(сч[её]тчики|узлы\s*уч[её]та)$/i.test((e.innerText||e.value||'').trim()))
            || clickables.find(e=>/сч[её]тчики|узлы\s*уч[её]та/i.test(clickText(e)));
          if(b){unlock(b); b.click(); return JSON.stringify({ok:false,phase:'gas_counters'});}
        }
        if(hasCounters && !hasReadingForm){
          const b=clickables.find(e=>/предоставление показаний|показания сч[её]тчика|передать показания/i.test(clickText(e)));
          if(b){unlock(b); b.click(); return JSON.stringify({ok:false,phase:'gas_readings'});}
        }
      }
      const visiblePassword=[...document.querySelectorAll('input[type=password]')].find(visible);
      const loginButtons=[...document.querySelectorAll('button,input[type=submit],input[type=button],input[type=image],a,[role=button]')].filter(visible)
        .filter(e=>/(войти|вход|login|sign in|авториз|посмотреть)/i.test((e.innerText||e.value||e.getAttribute('aria-label')||e.getAttribute('title')||'')+' '+desc(e)));
      if((location.host.includes('sevvodokanal') || location.host.includes('gup-sevgaz') || location.host.includes('sevgas')) && visiblePassword && loginButtons.length){
        return JSON.stringify({ok:false,phase:'login',found:0,filledCount:0,loginUsed:''});
      }
      // HARD GUARD: on water/gas login screens never search or submit meter readings.
      if(location.host.includes('sevvodokanal') || location.host.includes('gup-sevgaz') || location.host.includes('sevgas')){
        const pwNow=[...document.querySelectorAll('input[type=password]')].find(visible);
        const bodyNow=(document.body&&document.body.innerText||'').toLowerCase();
        const loginFormNow=pwNow || /(лицевый\s*сч[её]т|личный кабинет|войти в систему|введите.*парол|логин|пароль)/i.test(bodyNow);
        if(loginFormNow) return JSON.stringify({ok:false,phase:'login_wait',found:0,filledCount:0,loginUsed:''});
      }
      const meterWords=['показани','показан','потреблен','потребл','текущие показ','текущее показ','объём','объем','reading','meter reading','значение счетчика','значение счётчика'];
      const badWords=['captcha','капч','код с картинки','код картинки','цифр с картинки','изображен','код подтвержден','проверочн','security','защит','с картинки'];
      let candidates=all().filter(e=>visible(e)&&!e.disabled&&e.type!=='hidden'&&e.type!=='password'&&!badWords.some(w=>desc(e).includes(w))&&(e.type==='text'||e.type==='number'||e.tagName==='TEXTAREA'));
      let target=candidates.find(e=>meterWords.some(w=>desc(e).includes(w)));
      if(!target && location.host.includes('sevenergosbyt')) target=candidates.find(e=>!['фамил','лицев','account','счётчик','счетчик','serial','серийн','captcha','капч','картин','код','парол','login'].some(w=>desc(e).includes(w)));
      if(target){found++; if(set(target,reading))filled++; try{target.scrollIntoView({block:'center'});}catch(_){} }
      if(!target && location.host.includes('sevenergosbyt')) {
        const clickable=[...document.querySelectorAll('button,input[type=button],a,[role=button]')].filter(visible);
        const nav=clickable.find(e=>/(показани|передач.*показ|сч[её]тчик|meter)/i.test((e.innerText||e.value||e.getAttribute('aria-label')||e.getAttribute('title')||'')+' '+desc(e)));
        if(nav){ unlock(nav); nav.click(); return JSON.stringify({ok:false,phase:'navigate'}); }
        const menu=clickable.find(e=>/(menu|меню|навигац)/i.test((e.innerText||e.value||e.getAttribute('aria-label')||e.getAttribute('title')||'')+' '+desc(e)));
        if(menu){ unlock(menu); menu.click(); return JSON.stringify({ok:false,phase:'menu'}); }
      }
      return JSON.stringify({ok:filled>0,phase:'meter',found:found,filledCount:filled});
    })()
    """.trimIndent()
}


private fun loginFillOnlyScript(job: Job): String {
    val waterLogin = JSONObject.quote(job.credentials.waterLogin)
    val waterPassword = JSONObject.quote(job.credentials.waterPassword)
    val gasLogin = JSONObject.quote(job.credentials.gasLogin)
    val gasPassword = JSONObject.quote(job.credentials.gasPassword)
    return """
    (function(){
      const wl=$waterLogin, wp=$waterPassword, gl=$gasLogin, gp=$gasPassword;
      const gas=location.host.includes('gup-sevgaz') || location.host.includes('sevgas');
      const login=gas?gl:wl, pass=gas?gp:wp;
      function visible(e){return e && (e.offsetWidth||e.offsetHeight||e.getClientRects().length)}
      function desc(e){ return ((e.getAttribute('aria-label')||'')+' '+(e.getAttribute('placeholder')||'')+' '+(e.getAttribute('name')||'')+' '+(e.id||'')+' '+((e.labels&&e.labels[0])?e.labels[0].innerText:'')+' '+(e.getAttribute('title')||'')).toLowerCase(); }
      function setValue(e,v){
        if(!e||v==null)return false;
        try{e.removeAttribute('disabled'); e.removeAttribute('readonly');}catch(_){}
        const proto=e instanceof HTMLTextAreaElement?HTMLTextAreaElement.prototype:HTMLInputElement.prototype;
        try{const d=Object.getOwnPropertyDescriptor(proto,'value'); if(d&&d.set)d.set.call(e,String(v)); else e.value=String(v);}catch(_){e.value=String(v);}
        try{e.dispatchEvent(new Event('focus',{bubbles:true}));}catch(_){}
        try{e.dispatchEvent(new InputEvent('input',{bubbles:true,inputType:'insertText',data:String(v)}));}catch(_){try{e.dispatchEvent(new Event('input',{bubbles:true}));}catch(_) {}}
        try{e.dispatchEvent(new Event('change',{bubbles:true}));}catch(_){}
        try{e.dispatchEvent(new KeyboardEvent('keydown',{bubbles:true,key:'End',code:'End'}));}catch(_){}
        try{e.dispatchEvent(new KeyboardEvent('keyup',{bubbles:true,key:'End',code:'End'}));}catch(_){}
        return true;
      }
      const inputs=[...document.querySelectorAll('input')].filter(visible);
      const pw=inputs.find(e=>String(e.type).toLowerCase()==='password');
      if(!pw) return JSON.stringify({ok:false,phase:'no_password',url:location.href});
      const form=pw.form || pw.closest('form');
      const candidates=form?[...form.querySelectorAll('input')].filter(e=>visible(e)&&e!==pw):inputs.filter(e=>e!==pw);
      const loginRe=/(j_username|username|user(name)?|login|account(number)?|personal|lic|ls|лицев|абонент)/i;
      let l=candidates.find(e=>/j_username/i.test((e.name||'')+' '+(e.id||'')));
      if(!l) l=candidates.find(e=>loginRe.test(desc(e))&&['text','number','tel'].includes(String(e.type||'text').toLowerCase()));
      if(!l) l=candidates.find(e=>/username|login|account|personal|j_username/i.test((e.name||'')+' '+(e.id||'')+' '+(e.autocomplete||'')));
      if(!l) l=candidates.find(e=>['text','number','tel'].includes(String(e.type||'text').toLowerCase()));
      if(!l) return JSON.stringify({ok:false,phase:'no_login',url:location.href});
      const a=setValue(l,login), b=setValue(pw,pass);
      const buttons=[...document.querySelectorAll('button,input[type=submit],input[type=button],a')].filter(visible);
      const submit=buttons.find(e=>/(войти в систему|войти|вход|login|sign in|авториз)/i.test((e.innerText||e.value||e.getAttribute('aria-label')||e.getAttribute('title')||'')+' '+desc(e)));
      if(submit){ try{submit.removeAttribute('disabled'); submit.removeAttribute('readonly');}catch(_){} }
      if(a&&b&&submit){
        try{submit.focus();}catch(_){}
        try{submit.dispatchEvent(new MouseEvent('mousedown',{bubbles:true,cancelable:true,view:window}));}catch(_){}
        try{submit.dispatchEvent(new MouseEvent('mouseup',{bubbles:true,cancelable:true,view:window}));}catch(_){}
        try{submit.click();}catch(_){}
      }
      return JSON.stringify({ok:a&&b,phase:(a&&b&&submit)?'login_submitted':'login_filled',loginField:l.name||l.id||l.type,passwordField:pw.name||pw.id||'password',submitEnabled:!!submit,url:location.href});
    })()
    """.trimIndent()
}


private fun autoGasLoginScript(job: Job): String {
    // Gas: fill credentials and report the real button coordinates.
    // The final click is generated by Android at WebView level, not by JS,
    // so JSF receives the same kind of pointer event as a user tap.
    val gasLogin = JSONObject.quote(job.credentials.gasLogin)
    val gasPassword = JSONObject.quote(job.credentials.gasPassword)
    return """
    (function(){
      const login=$gasLogin, pass=$gasPassword;
      const visible=e=>!!(e&&(e.offsetWidth||e.offsetHeight||e.getClientRects().length));
      const desc=e=>(((e.getAttribute('aria-label')||'')+' '+(e.getAttribute('placeholder')||'')+' '+(e.getAttribute('name')||'')+' '+(e.id||'')+' '+(e.getAttribute('title')||'')+' '+((e.labels&&e.labels[0])?e.labels[0].innerText:''))+'').toLowerCase();
      const text=e=>((e.innerText||e.value||e.textContent||e.getAttribute('aria-label')||e.getAttribute('title')||'')+' '+desc(e));
      function setValue(e,v){
        if(!e)return false;
        try{e.removeAttribute('disabled');e.removeAttribute('readonly');}catch(_){}
        try{
          const proto=e instanceof HTMLTextAreaElement?HTMLTextAreaElement.prototype:HTMLInputElement.prototype;
          const d=Object.getOwnPropertyDescriptor(proto,'value');
          if(d&&d.set)d.set.call(e,String(v)); else e.value=String(v);
        }catch(_){try{e.value=String(v);}catch(__){}}
        try{e.dispatchEvent(new Event('input',{bubbles:true}));}catch(_){}
        try{e.dispatchEvent(new Event('change',{bubbles:true}));}catch(_){}
        return String(e.value||'')===String(v);
      }
      const pw=[...document.querySelectorAll('input[type=password]')].find(visible);
      if(!pw) return JSON.stringify({ok:false,phase:'login_wait'});
      const form=pw.form||pw.closest('form');
      const pool=form?[...form.querySelectorAll('input')].filter(visible):[...document.querySelectorAll('input')].filter(visible);
      const re=/(j_username|username|user(name)?|login|account(number)?|personal|lic|ls|лицев|абонент)/i;
      let lf=pool.find(e=>e!==pw&&/j_username/i.test((e.name||'')+' '+(e.id||'')));
      if(!lf)lf=pool.find(e=>e!==pw&&re.test(desc(e))&&['text','number','tel'].includes(String(e.type||'text').toLowerCase()));
      if(!lf)lf=pool.find(e=>e!==pw&&['text','number','tel'].includes(String(e.type||'text').toLowerCase()));
      if(!lf) return JSON.stringify({ok:false,phase:'login_wait'});
      const loginOk=setValue(lf,login), passOk=setValue(pw,pass);
      const buttons=form?[...form.querySelectorAll('button,input[type=submit],input[type=button],a,[role=button]')].filter(visible):[];
      const submit=buttons.find(e=>/(войти в систему|войти|вход|login|sign in|авториз)/i.test(text(e)))||buttons.find(e=>String(e.type||'').toLowerCase()==='submit');
      if(!submit) return JSON.stringify({ok:loginOk&&passOk,phase:'login_filled'});
      try{submit.removeAttribute('disabled');submit.removeAttribute('readonly');submit.scrollIntoView({block:'center',inline:'center'});}catch(_){}
      const r=submit.getBoundingClientRect();
      return JSON.stringify({ok:loginOk&&passOk,phase:'login_ready',x:r.left+r.width/2,y:r.top+r.height/2,w:r.width,h:r.height});
    })()
    """.trimIndent()
}

private fun openGasReadingFormScript(): String {
    return """
    (function(){
      const norm=s=>(s||'').replace(/\\s+/g,' ').trim().toLowerCase();
      const text=e=>norm((e.innerText||e.value||e.textContent||e.getAttribute('aria-label')||e.getAttribute('title')||'')+'');
      const vis=e=>!!(e&&(e.offsetWidth||e.offsetHeight||e.getClientRects().length));
      const body=norm(document.body&&document.body.innerText||'');
      // The counters page itself contains the button text “Предоставление показаний счётчика”.
      // That text alone is NOT proof that the input dialog is open. Require a real visible
      // reading input/dialog marker instead.
      const visibleInputs=[...document.querySelectorAll('input,textarea')].filter(vis);
      const readingInput=visibleInputs.find(e=>/показани|значени|сч[её]тчик/i.test(text(e)) || /показани|значени|сч[её]тчик/i.test((e.name||'')+' '+(e.id||'')+' '+(e.placeholder||'')));
      const dialogText=[...document.querySelectorAll('[role="dialog"], .ui-dialog, .modal, .modal-dialog')].filter(vis).some(e=>/предоставление показаний|введите показания|показания сч[её]тчика/i.test(text(e)));
      const formOpen=!!readingInput || dialogText || /введите показания/i.test(body);
      if(formOpen) return JSON.stringify({ok:true,phase:'gas_reading_form'});

      function activate(el){
        if(!el) return false;
        let x=el;
        for(let i=0;i<7 && x;i++,x=x.parentElement){
          try{x.removeAttribute('disabled');x.removeAttribute('readonly');}catch(_){}
          try{x.scrollIntoView({block:'center',inline:'center'});}catch(_){}
          try{x.focus();}catch(_){}
          try{x.dispatchEvent(new MouseEvent('mousedown',{bubbles:true,cancelable:true,view:window}));}catch(_){}
          try{x.dispatchEvent(new MouseEvent('mouseup',{bubbles:true,cancelable:true,view:window}));}catch(_){}
          try{x.dispatchEvent(new MouseEvent('click',{bubbles:true,cancelable:true,view:window}));}catch(_){}
          try{if(typeof x.click==='function') x.click();}catch(_){}
          try{if(typeof x.onclick==='function') x.onclick.call(x); }catch(_){}
          if(x.matches && x.matches('a,button,input[type=button],input[type=submit],[role=button]')) return true;
        }
        return false;
      }

      const all=[...document.querySelectorAll('*')].filter(vis);
      const readingRe=/предоставление показаний|показания сч[её]тчика|передать показания/i;
      const counterRe=/^сч[её]тчики$|^сч[её]тчики\s*$/i;

      // First look for the actual control, not just its parent text.
      let reading=all.find(e=>readingRe.test(text(e)) && text(e).length<120 &&
        (e.matches('a,button,input[type=button],input[type=submit],[role=button]') || e.onclick || e.closest('a,button,input[type=button],input[type=submit],[role=button]')));
      if(reading){
        const target=reading.closest('a,button,input[type=button],input[type=submit],[role=button]') || reading;
        if(activate(target)) return JSON.stringify({ok:true,phase:'gas_readings'});
      }

      // Some JSF pages put the command text inside a table cell or span.
      let readingText=all.find(e=>readingRe.test(text(e)) && text(e).length<120);
      if(readingText && activate(readingText)) return JSON.stringify({ok:true,phase:'gas_readings'});

      // If still on the cabinet info page, open Counters. Prefer the actual tab/control.
      let counters=all.find(e=>counterRe.test(text(e)) &&
        (e.matches('a,button,input[type=button],input[type=submit],[role=button],td,li') || e.onclick || e.closest('a,button,input[type=button],input[type=submit],[role=button]')));
      if(!counters) counters=all.find(e=>/сч[её]тчики/.test(text(e)) && text(e).length<50);
      if(counters){
        const target=counters.closest('a,button,input[type=button],input[type=submit],[role=button]') || counters;
        if(activate(target)) return JSON.stringify({ok:true,phase:'gas_counters'});
      }

      return JSON.stringify({ok:false,phase:'gas_wait',bodyHasCounters:/сч[её]тчики/.test(body),bodyHasReading:readingRe.test(body)});
    })()
    """.trimIndent()
}


private fun fillGasReadingScript(reading: String): String {
    val value = JSONObject.quote(reading)
    return """
    (function(){
      const wanted=$value;
      const vis=e=>!!(e&&(e.offsetWidth||e.offsetHeight||e.getClientRects().length));
      const desc=e=>(((e.getAttribute('aria-label')||'')+' '+(e.getAttribute('placeholder')||'')+' '+(e.getAttribute('name')||'')+' '+(e.id||'')+' '+(e.getAttribute('title')||'')+' '+((e.labels&&e.labels[0])?e.labels[0].innerText:''))+'').toLowerCase();
      const set=(e,v)=>{
        if(!e) return false;
        try{e.removeAttribute('disabled');e.removeAttribute('readonly');e.focus();}catch(_){}
        try{
          const proto=e instanceof HTMLTextAreaElement?HTMLTextAreaElement.prototype:HTMLInputElement.prototype;
          const d=Object.getOwnPropertyDescriptor(proto,'value');
          if(d&&d.set)d.set.call(e,v); else e.value=v;
        }catch(_){try{e.value=v;}catch(__){return false;}}
        try{e.dispatchEvent(new InputEvent('input',{bubbles:true,inputType:'insertText',data:String(v)}));}catch(_){try{e.dispatchEvent(new Event('input',{bubbles:true}));}catch(__){}}
        try{e.dispatchEvent(new Event('change',{bubbles:true}));}catch(_){}
        try{e.dispatchEvent(new KeyboardEvent('keyup',{bubbles:true,key:'End'}));}catch(_){}
        return String(e.value||'')===String(v);
      };
      const dialogs=[...document.querySelectorAll('[role="dialog"], .ui-dialog, .modal, .modal-dialog')].filter(vis);
      const scopes=dialogs.length?dialogs:[document];
      let target=null;
      for(const scope of scopes){
        const inputs=[...scope.querySelectorAll('input,textarea')].filter(vis).filter(e=>e.type!=='hidden'&&e.type!=='password'&&e.type!=='button'&&e.type!=='submit');
        target=inputs.find(e=>/показани|значени|введите.*показ|сч[её]тчик/i.test(desc(e)));
        if(!target) target=inputs.find(e=>['text','number','tel'].includes(String(e.type||'text').toLowerCase()) && !/год|year|поиск|search/i.test(desc(e)));
        if(target) break;
      }
      if(!target) return JSON.stringify({ok:false,phase:'gas_reading_input_not_found'});
      const ok=set(target,wanted);
      try{target.scrollIntoView({block:'center',inline:'center'});}catch(_){}
      return JSON.stringify({ok:ok,phase:'gas_reading_filled',value:String(target.value||'')});
    })()
    """.trimIndent()
}

private fun autoSubmitScript(type: MeterType): String {
    return """
    (function(){
      const text=e=>((e.innerText||e.value||e.getAttribute('aria-label')||e.getAttribute('title')||'')+'').toLowerCase();
      const vis=e=>e&&(e.offsetWidth||e.offsetHeight||e.getClientRects().length);
      const bad=/(captcha|капч|код с картинки|код картинки|цифр с картинки|изображен|код подтвержден|проверочн|security|защит)/i;
      const buttons=[...document.querySelectorAll('button,input[type=submit],input[type=button],input[type=image],a,[role=button]')].filter(vis);
      const body=(document.body&&document.body.innerText||'').toLowerCase();
      if(typeName==='GAS'){}
      function clickBy(re){
        const b=buttons.find(e=>re.test(text(e)));
        if(b){try{b.removeAttribute('disabled');b.removeAttribute('readonly');b.focus();}catch(_){} try{b.click();return true;}catch(_){} }
        return false;
      }
      const typeName='%TYPE%';
      if(typeName==='GAS'){
        // After login the gas cabinet requires entering the Counters section first.
        if(!/(предоставление показаний|показания счетчика|показания сч[её]тчика|сч[её]тчики)/i.test(body)){
          if(clickBy(/^(сч[её]тчики|показания)$/i)) return JSON.stringify({ok:true,phase:'gas_counters'});
          if(clickBy(/сч[её]тчики|показани/i)) return JSON.stringify({ok:true,phase:'gas_counters'});
        }
        if(!/(предоставление показаний|показания счетчика|показания сч[её]тчика)/i.test(body)){
          if(clickBy(/предоставление показаний|показания счетчика|показания сч[её]тчика/i)) return JSON.stringify({ok:true,phase:'gas_readings'});
        }
      }
      const captcha=!![...document.querySelectorAll('input,textarea')].find(e=>vis(e)&&bad.test(((e.placeholder||'')+' '+(e.name||'')+' '+(e.id||'')+' '+(e.getAttribute('aria-label')||'')+' '+((e.parentElement&&e.parentElement.innerText)||''))));
      const re=/(передать|отправить|отправка|записать(?:\s+показания)?|записать|сохранить|подтвердить|подтверждаю|submit|send|save|confirm)/i;
      const candidates=buttons.filter(b=>re.test(text(b))&&!/(войти|вход|login|sign in|авториз|посмотреть)/i.test(text(b)));
      const btn=(typeName==='WATER' ? candidates.find(b=>/записать(?:\s+показания)?|передать|отправить/i.test(text(b))) : null)||candidates.find(b=>/передать|отправить|записать|submit|send/i.test(text(b)))||candidates[0];
      if(btn){ try{btn.removeAttribute('disabled');btn.removeAttribute('readonly');}catch(_){}; try{btn.click();}catch(_){} return JSON.stringify({ok:true,clicked:text(btn)}); }
      return JSON.stringify({ok:false,manual:false,captcha:captcha});
    })()
    """.trimIndent().replace("%TYPE%", type.name)
}

@SuppressLint("SetJavaScriptEnabled")
@Composable
private fun ProviderScreen(url: String, job: Job, index: Int, total: Int, store: LocalStore, onWebViewReady: (WebView) -> Unit, onStatus: (String) -> Unit, onNext: () -> Unit, onBack: () -> Unit) {
    var message by remember(url, job.meterId) { mutableStateOf("${job.address}\n${job.title}: ${job.reading}\nПередача $index из $total") }
    var webViewRef by remember { mutableStateOf<WebView?>(null) }
    var busy by remember { mutableStateOf(false) }
    var gasInitialPrepared by remember(url, job.meterId) { mutableStateOf(false) }
    var gasLoginFormPolls by remember(url, job.meterId) { mutableStateOf(0) }
    var confirmed by remember { mutableStateOf(false) }

    fun checkConfirmation(w: WebView, attempt: Int = 0) {
        if (confirmed) return
        w.evaluateJavascript("""
            (function(){
              const t=(document.body&&document.body.innerText||'').toLowerCase();
              const ok=/(данн(ые|ых).*(принят|передан|сохран)|показани.*(принят|передан|сохран)|успешн.*(перед|сохран)|спасибо|операция выполнен|передача выполнен|данные отправлен|успешно)/i.test(t);
              const fail=/(ошибк|не удалось|не принят|не передан|неверн|введите капч|captcha)/i.test(t);
              return JSON.stringify({ok:ok,fail:fail});
            })()
        """.trimIndent()) { raw ->
            val r = raw ?: ""
            if (r.contains("\\\"ok\\\":true")) {
                confirmed = true
                busy = false
                message = "✓ ${job.title}: ${job.reading} — показание подтверждено"
                onStatus("Передано ✓")
                w.postDelayed({ onNext() }, 1200)
            } else if (attempt < 10 && !r.contains("\\\"fail\\\":true")) {
                w.postDelayed({ checkConfirmation(w, attempt + 1) }, 900)
            } else {
                busy = false
                message = "Команда отправлена. Подтверждение сайта не найдено — проверь страницу."
                onStatus("Проверить результат")
            }
        }
    }

    fun nativeGasTap(w: WebView, cssX: Float, cssY: Float) {
        // getBoundingClientRect() is in CSS viewport pixels. WebView dispatchTouchEvent()
        // expects view-local physical pixels, so convert using the current WebView scale.
        val scale = try { w.scale } catch (_: Exception) { 1f }
        val scrollX = try { w.scrollX } catch (_: Exception) { 0 }
        val scrollY = try { w.scrollY } catch (_: Exception) { 0 }
        val x = ((cssX + scrollX) * scale).coerceIn(1f, (w.width - 1).coerceAtLeast(1).toFloat())
        val y = ((cssY + scrollY) * scale).coerceIn(1f, (w.height - 1).coerceAtLeast(1).toFloat())
        val downTime = SystemClock.uptimeMillis()
        val down = MotionEvent.obtain(downTime, downTime, MotionEvent.ACTION_DOWN, x, y, 0)
        val move = MotionEvent.obtain(downTime, downTime + 30, MotionEvent.ACTION_MOVE, x, y, 0)
        val up = MotionEvent.obtain(downTime, downTime + 80, MotionEvent.ACTION_UP, x, y, 0)
        try {
            w.dispatchTouchEvent(down)
            w.postDelayed({
                w.dispatchTouchEvent(move)
                move.recycle()
                w.dispatchTouchEvent(up)
                up.recycle()
            }, 30)
        } finally {
            down.recycle()
        }
    }

    fun startGasAutoLogin(w: WebView, attempt: Int = 0) {
        if (confirmed || attempt >= 120) {
            if (!confirmed) {
                busy = false
                message = "Газ: диагностика формы не завершена. Проверьте страницу."
                onStatus("Диагностика не завершена")
            }
            return
        }
        w.evaluateJavascript(autoGasLoginScript(job)) { raw ->
            if (confirmed) return@evaluateJavascript
            val r = raw ?: ""
            if (r.contains("login_ready") || r.contains("login_filled")) {
                busy = false
                onStatus("Форма входа найдена")
                w.evaluateJavascript("""
                    (function(){
                      const vis=e=>!!(e&&(e.offsetWidth||e.offsetHeight||e.getClientRects().length));
                      const pw=[...document.querySelectorAll('input[type=password]')].find(vis);
                      const form=pw && (pw.form||pw.closest('form'));
                      if(!form) return JSON.stringify({ok:false,reason:'NO_FORM',url:location.href});
                      const txt=e=>((e.innerText||e.value||e.textContent||e.getAttribute('aria-label')||e.getAttribute('title')||'')+'').trim();
                      const submit=[...form.querySelectorAll('button,input[type=submit],input[type=button],a,[role=button]')].filter(vis)
                        .find(e=>/(войти в систему|войти|вход|login|sign in|авториз)/i.test(txt(e)))
                        || [...form.querySelectorAll('button,input[type=submit],input[type=button]')].find(vis);
                      const hidden=[...form.querySelectorAll('input[type=hidden]')].map(e=>({name:e.name||'',id:e.id||'',hasValue:!!e.value}));
                      const controls=[...form.querySelectorAll('input,button,select,textarea')].filter(vis).map(e=>({tag:e.tagName.toLowerCase(),type:e.type||'',name:e.name||'',id:e.id||'',valueLength:(e.value||'').length}));
                      return JSON.stringify({ok:true,url:location.href,action:form.action||'',method:(form.method||'get').toUpperCase(),formId:form.id||'',formName:form.name||'',submit:submit?{tag:submit.tagName.toLowerCase(),type:submit.type||'',name:submit.name||'',id:submit.id||'',value:submit.value||'',text:txt(submit)}:null,hidden:hidden,controls:controls});
                    })()
                """) { diagRaw ->
                    // Diagnostic details are intentionally hidden in the normal UI.
                    // Keep the form available for a manual click.
                    message = "Газ: данные входа заполнены. Нажмите «Войти в систему»."
                    onStatus("Готово к входу")
                }
                return@evaluateJavascript
            }
            w.postDelayed({ startGasAutoLogin(w, attempt + 1) }, 120)
        }
    }

    fun runFillAndSend() {
        val w = webViewRef ?: run { message = "Страница ещё загружается."; return }
        if (busy) return
        // Water: fill credentials and click the site's normal login button.
        // There is no CAPTCHA handling here; the site login is used as-is.
        // Gas remains in the manual-click test flow for now.
        if (job.type == MeterType.WATER) {
            busy = true
            message = "Вода: заполняем логин и пароль и выполняем вход…"
            onStatus("Вход…")
            w.evaluateJavascript(autoFillScript(job)) { result ->
                val r = result ?: ""
                val ok = r.contains("\"ok\":true") || r.contains("login_filled")
                val phase = Regex("\"phase\":\"([^\"]+)\"").find(r)?.groupValues?.getOrNull(1) ?: ""
                if (ok || phase == "login") {
                    message = "Вода: данные заполнены, выполняем вход…"
                    onStatus("Вход…")
                    w.postDelayed({
                    // After login, distinguish a real password error from a still-loading page.
                    w.evaluateJavascript("""(function(){
                        const t=((document.body&&document.body.innerText)||'').toLowerCase();
                        if(/неверн\s*(?:ый|ая|ое)?\s*парол|неправильн\s*(?:ый|ая|ое)?\s*парол|ошибк\w*.*парол/i.test(t)) return 'WATER_BAD_PASSWORD';
                        if(/личный кабинет|войти в систему|регистрационные данные|введите.*парол|логин|пароль/i.test(t) && document.querySelector('input[type=password]')) return 'WATER_LOGIN_STILL_VISIBLE';
                        return 'WATER_LOGIN_PASSED';
                    })()""") { stateResult ->
                        busy = false
                        val state = stateResult ?: ""
                        when {
                            state.contains("WATER_BAD_PASSWORD") -> {
                                message = "Вода: сайт сообщил «Неверный пароль». Проверь пароль Водоканала в настройках."
                                onStatus("Неверный пароль")
                            }
                            state.contains("WATER_LOGIN_STILL_VISIBLE") -> {
                                message = "Вода: вход не выполнен. Проверь логин и пароль."
                                onStatus("Вход не выполнен")
                            }
                            else -> {
                                if (!confirmed) runFillAndSend()
                            }
                        }
                    }
                }, 4200)
                } else {
                    busy = false
                    message = "Вода: не удалось найти поле логина или пароля."
                    onStatus("Требуется ввод")
                }
            }
            return
        }
        if (job.type == MeterType.GAS) {
            busy = true
            message = "Газ: автоматически входим в личный кабинет…"
            onStatus("Автоматический вход…")
            startGasAutoLogin(w)
            fun openGasFormAfterLogin(attempt: Int = 0) {
                if (confirmed) return
                if (attempt >= 30) {
                    busy = false
                    message = "Газ: кабинет открыт. Проверьте раздел «Счётчики»."
                    onStatus("Кабинет открыт")
                    return
                }
                w.evaluateJavascript(openGasReadingFormScript()) { rr ->
                    if (confirmed) return@evaluateJavascript
                    when {
                        rr?.contains("gas_reading_form") == true -> {
                            message = "Газ: форма показаний открыта. Заполняем значение…"
                            onStatus("Заполнение показания")
                            w.postDelayed({
                                if (confirmed) return@postDelayed
                                w.evaluateJavascript(fillGasReadingScript(job.reading)) { fr ->
                                    if (confirmed) return@evaluateJavascript
                                    busy = false
                                    if (fr?.contains("gas_reading_filled") == true && fr.contains("\"ok\":true")) {
                                        message = "Газ: показание ${job.reading} заполнено. Проверьте значение и нажмите OK вручную."
                                        onStatus("Показание заполнено")
                                    } else {
                                        message = "Газ: форма открыта, но поле показания не найдено. Проверьте его вручную."
                                        onStatus("Требуется проверка")
                                    }
                                }
                            }, 150)
                        }
                        rr?.contains("gas_counters") == true -> {
                            message = "Газ: открываем раздел «Счётчики»…"
                            w.postDelayed({ openGasFormAfterLogin(attempt + 1) }, 300)
                        }
                        else -> w.postDelayed({ openGasFormAfterLogin(attempt + 1) }, 200)
                    }
                }
            }

            fun waitForGasCabinet(attempt: Int) {
                if (confirmed) return
                if (attempt >= 40) {
                    busy = false
                    message = "Газ: автоматический вход не завершён. Проверьте страницу — кнопку «Войти» можно нажать вручную."
                    onStatus("Проверьте вход")
                    return
                }
                w.postDelayed({
                    if (confirmed) return@postDelayed
                    w.evaluateJavascript("""(function(){
                        const visible=e=>!!(e&&(e.offsetWidth||e.offsetHeight||e.getClientRects().length));
                        const body=((document.body&&document.body.innerText)||'').toLowerCase();
                        const pwVisible=[...document.querySelectorAll('input[type="password"]')].some(visible);
                        const loginWords=/регистрационные данные|войти в систему|забыли пароль/i.test(body);
                        const cabinetWords=/лицев\s*сч[ёе]т|абонент|сч[ёе]тчики|характеристики|история платежей/i.test(body);
                        if(cabinetWords && !pwVisible) return 'CABINET_PAGE';
                        if(pwVisible || loginWords) return 'LOGIN_PAGE';
                        return 'WAIT';
                    })()""") { state ->
                        when {
                            state.contains("CABINET_PAGE") -> {
                                try {
                                    val cookies = android.webkit.CookieManager.getInstance().getCookie(GAS) ?: ""
                                    if (cookies.isNotBlank()) store.putGasCookies(job.apartmentId, cookies)
                                } catch (_: Exception) {}
                                message = "Газ: вход выполнен. Открываем «Счётчики»…"
                                onStatus("Открываем счётчики")
                                openGasFormAfterLogin()
                            }
                            else -> waitForGasCabinet(attempt + 1)
                        }
                    }
                }, 250)
            }
            waitForGasCabinet(0)
            return
        }
        busy = true
        onStatus("Заполняется…")
        message = "1/3 Заполняем данные…"
        w.evaluateJavascript(autoFillScript(job)) { result ->
            val r = result ?: ""
            val ok = r.contains("\\\"ok\\\":true")
            val phase = Regex("\\\"phase\\\":\\\"([^\\\"]+)\\\"").find(r)?.groupValues?.getOrNull(1) ?: "meter"
            val filled = Regex("\\\"filledCount\\\":(\\d+)").find(r)?.groupValues?.getOrNull(1) ?: "0"
            val loginUsed = Regex("\"loginUsed\":\"([^\"]*)\"").find(r)?.groupValues?.getOrNull(1) ?: ""
            if (phase == "navigate" || phase == "menu" || phase == "gas_lk" || phase == "gas_counters" || phase == "gas_readings" || phase == "login_wait") {
                busy = false
                message = when (phase) {
                    "menu" -> "Открываем меню Севэнергосбыта…"
                    "gas_counters" -> "Открываем раздел «Счётчики»…"
                    "gas_readings" -> "Открываем форму показаний газа…"
                    else -> "Открываем форму передачи показаний…"
                }
                onStatus("Открываем форму…")
                w.postDelayed({ if (!confirmed && !busy) runFillAndSend() }, 1200)
                return@evaluateJavascript
            }
            if (!ok) {
                busy = false
                message = "Не удалось автоматически заполнить нужные поля."
                onStatus("Требуется ввод")
                return@evaluateJavascript
            }
            if (phase == "login") {
                busy = false
                message = "2/3 Вход: $loginUsed…"
                onStatus("Вход…")
                w.postDelayed({ if (!confirmed && !busy) runFillAndSend() }, 3800)
                return@evaluateJavascript
            }
            message = "2/3 Показание ${job.reading} заполнено."
            onStatus("Данные заполнены")
            message = "3/3 Передаём показание…"
            onStatus("Передаётся…")
            w.postDelayed({
                    w.evaluateJavascript(autoSubmitScript(job.type)) { sr ->
                        val x = sr ?: ""
                        if (x.contains("\\\"ok\\\":true")) {
                            message = "3/3 Команда отправлена. Ждём подтверждение сайта…"
                            checkConfirmation(w)
                        } else {
                            busy = false
                            message = "Не удалось найти кнопку передачи. Откройте форму и попробуйте ещё раз."
                            onStatus("Требуется ввод")
                        }
                    }
                }, 900)
        }
    }

    fun sendNow() {
        val w = webViewRef ?: return
        if (busy) return
        busy = true
        message = "3/3 Передаём показание ${job.reading}…"
        onStatus("Передаётся…")
        w.evaluateJavascript(autoSubmitScript(job.type)) { r ->
            val x = r ?: ""
            if (x.contains("\\\"ok\\\":true")) {
                message = "Команда отправлена. Ждём подтверждение сайта…"
                checkConfirmation(w)
            } else {
                busy = false
                message = "Кнопку передачи не нашли."
                onStatus("Требуется ввод")
            }
        }
    }

    Column(Modifier.fillMaxSize()) {
        Row(Modifier.fillMaxWidth().padding(8.dp), horizontalArrangement = Arrangement.SpaceBetween) {
            Text("Передача $index/$total", style = MaterialTheme.typography.titleMedium)
            TextButton(onClick = onBack, enabled = !busy) { Text("Назад") }
        }
        Text(message, Modifier.padding(horizontal = 12.dp))
        Row(Modifier.padding(8.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Button(onClick = { runFillAndSend() }, enabled = !busy && !confirmed) { Text("Передать") }
            Button(onClick = onNext, enabled = !busy) { Text(if (index < total) "Пропустить" else "Завершить") }
        }
        AndroidView(factory = { context ->
            WebView(context).apply {
                webViewRef = this
                onWebViewReady(this)
                settings.javaScriptEnabled = true
                settings.domStorageEnabled = true
                settings.databaseEnabled = true
                settings.cacheMode = android.webkit.WebSettings.LOAD_DEFAULT
                settings.loadsImagesAutomatically = true
                settings.javaScriptCanOpenWindowsAutomatically = true
                settings.setSupportMultipleWindows(false)
                settings.mixedContentMode = android.webkit.WebSettings.MIXED_CONTENT_COMPATIBILITY_MODE
                android.webkit.CookieManager.getInstance().setAcceptCookie(true)
                android.webkit.CookieManager.getInstance().setAcceptThirdPartyCookies(this, true)
                // Each job starts a fresh cabinet session. For GAS we deliberately
                // keep the WebView cache for speed, but never keep cookies/session
                // from the previous apartment. Form data is also cleared so WebView
                // autofill cannot reinsert an old apartment's credentials.
                if (job.type != MeterType.GAS) {
                    android.webkit.CookieManager.getInstance().removeAllCookies(null)
                    android.webkit.CookieManager.getInstance().flush()
                    clearHistory()
                    clearCache(true)
                    clearFormData()
                    clearSslPreferences()
                } else {
                    clearFormData()
                }
                settings.useWideViewPort = true
                settings.loadWithOverviewMode = true
                // Разрешаем увеличение/уменьшение страницы жестом двумя пальцами.
                settings.setSupportZoom(true)
                settings.builtInZoomControls = true
                settings.displayZoomControls = false
                settings.textZoom = 100
                // Keep the standard Android WebView user-agent. The Sevgaz cabinet can reject modified WebView user-agents.
                webChromeClient = object : WebChromeClient() {
                    override fun onReceivedTitle(view: WebView, title: String) {
                        super.onReceivedTitle(view, title)
                        if (title.isNotBlank()) message = "Страница: $title"
                    }
                }
                webViewClient = object : WebViewClient() {
                    override fun shouldOverrideUrlLoading(view: WebView, request: android.webkit.WebResourceRequest): Boolean {
                        // Let WebView handle normal form POST/redirect navigation itself.
                        // Intercepting and re-loading the URL can turn a POST login into a GET.
                        return false
                    }
                    override fun shouldOverrideUrlLoading(view: WebView, url: String): Boolean {
                        return false
                    }
                    override fun onPageStarted(view: WebView, url: String, favicon: android.graphics.Bitmap?) {
                        onWebViewReady(view)
                        message = "Загрузка: ${url.take(80)}…"
                    }
                    override fun onReceivedError(view: WebView, request: android.webkit.WebResourceRequest, error: android.webkit.WebResourceError) {
                        if (request.isForMainFrame) message = "Ошибка загрузки: ${error.description}"
                    }
                    override fun onPageFinished(view: WebView, loadedUrl: String) {
                        onWebViewReady(view)
                        if (!confirmed) {
                            if (job.type == MeterType.GAS) {
                                // Газ: используем тот же проверенный пошаговый сценарий, который
                                // применялся для квартиры 2: дождаться JSF-формы, заполнить
                                // логин/пароль, нажать штатную кнопку входа, дождаться кабинета,
                                // открыть «Счётчики» и форму показаний.
                                if (loadedUrl.contains("/irb/view/abonentInfo.xhtml", ignoreCase = true)) {
                                    // The server can return abonentInfo.xhtml while still showing
                                    // the login form (for example when the first submit did not
                                    // establish the session). Do not report success from URL alone.
                                    view.evaluateJavascript("""(function(){
                                         const visible=e=>!!(e&&(e.offsetWidth||e.offsetHeight||e.getClientRects().length));
                                         const body=((document.body&&document.body.innerText)||'').toLowerCase();
                                         const pwVisible=[...document.querySelectorAll('input[type="password"]')].some(visible);
                                         const loginWords=/регистрационные данные|войти в систему|забыли пароль/i.test(body);
                                         const cabinetWords=/лицевой\s*сч[её]т|абонент|сч[ёе]тчики|характеристики|история платежей/i.test(body);
                                         const cabinet=cabinetWords && !pwVisible;
                                         return cabinet ? 'CABINET_PAGE' : ((pwVisible||loginWords) ? 'LOGIN_PAGE' : 'UNKNOWN_PAGE');
                                    })()""") { stateResult ->
                                        val state = stateResult ?: ""
                                        when {
                                            state.contains("CABINET_PAGE") -> {
                                                busy = true
                                                message = "Газ: вход выполнен. Открываем «Счётчики»…"
                                                onStatus("Открываем счётчики")
                                                fun openGasForm(attempt: Int = 0) {
                                                    if (confirmed) return
                                                    if (attempt >= 30) {
                                                        busy = false
                                                        message = "Газ: кабинет открыт. Откройте «Счётчики» вручную."
                                                        onStatus("Открыта страница")
                                                        return
                                                    }
                                                    view.evaluateJavascript(openGasReadingFormScript()) { rr ->
                                                        if (confirmed) return@evaluateJavascript
                                                        when {
                                                            rr?.contains("gas_reading_form") == true -> {
                                                                busy = true
                                                                message = "Газ: форма показаний открыта. Заполняем значение…"
                                                                onStatus("Заполнение показания")
                                                                view.postDelayed({
                                                                    if (confirmed) return@postDelayed
                                                                    view.evaluateJavascript(fillGasReadingScript(job.reading)) { fr ->
                                                                        if (confirmed) return@evaluateJavascript
                                                                        if (fr?.contains("gas_reading_filled") == true && fr.contains("\"ok\":true")) {
                                                                            busy = false
                                                                            message = "Газ: показание ${job.reading} заполнено. Проверьте значение и нажмите OK вручную."
                                                                            onStatus("Показание заполнено")
                                                                        } else {
                                                                            busy = false
                                                                            message = "Газ: форма открыта, но поле показания не найдено. Проверьте его вручную."
                                                                            onStatus("Требуется проверка")
                                                                        }
                                                                    }
                                                                }, 150)
                                                            }
                                                            rr?.contains("gas_counters") == true -> {
                                                                message = "Газ: открываем раздел «Счётчики»…"
                                                                view.postDelayed({ openGasForm(attempt + 1) }, 350)
                                                            }
                                                            else -> view.postDelayed({ openGasForm(attempt + 1) }, 250)
                                                        }
                                                    }
                                                }
                                                view.postDelayed({ openGasForm() }, 200)
                                            }
                                            state.contains("LOGIN_PAGE") -> {
                                                // Если JSF вернул нас на форму входа, снова запускаем тот же
                                                // polling-алгоритм. Важно не оставлять заполненную форму без клика.
                                                message = "Газ: автоматически выполняем вход…"
                                                onStatus("Автоматический вход…")
                                                busy = false
                                                startGasAutoLogin(view)
                                                fun waitForGasLoginResult(attempt: Int) {
                                                    if (confirmed) return
                                                    if (attempt >= 50) {
                                                        busy = false
                                                        message = "Газ: кабинет не обнаружен. Если кабинет уже открыт, нажми «Передать» ещё раз."
                                                        onStatus("Вход не подтверждён")
                                                        return
                                                    }
                                                    view.postDelayed({
                                                        if (confirmed) return@postDelayed
                                                        view.evaluateJavascript("""(function(){
                                                             const visible=e=>!!(e&&(e.offsetWidth||e.offsetHeight||e.getClientRects().length));
                                                             const body=((document.body&&document.body.innerText)||'').toLowerCase();
                                                             const pwVisible=[...document.querySelectorAll('input[type="password"]')].some(visible);
                                                             const loginWords=/регистрационные данные|войти в систему|забыли пароль/i.test(body);
                                                             const cabinetWords=/лицевой\s*сч[ёе]т|абонент|сч[ёе]тчики|характеристики|история платежей/i.test(body);
                                                             const cabinet=cabinetWords && !pwVisible;
                                                             if (cabinet) return 'CABINET_PAGE';
                                                             if (pwVisible || loginWords) return 'LOGIN_PAGE';
                                                             return 'UNKNOWN_PAGE';
                                                        })()""") { rr ->
                                                            if (!confirmed) {
                                                            when {
                                                                rr.contains("CABINET_PAGE") -> {
                                                                    busy = false
                                                                    try {
                                                                        val cookies = android.webkit.CookieManager.getInstance().getCookie(GAS) ?: ""
                                                                        if (cookies.isNotBlank()) store.putGasCookies(job.apartmentId, cookies)
                                                                    } catch (_: Exception) {}
                                                                    message = "Газ: вход выполнен. Открыт личный кабинет."
                                                                    onStatus("Вход выполнен")
                                                                }
                                                                attempt >= 30 -> {
                                                                    busy = false
                                                                    message = "Газ: не дождались ответа сервера. Если кабинет уже открыт, можно продолжить."
                                                                    onStatus("Кабинет проверяется")
                                                                }
                                                                else -> waitForGasLoginResult(attempt + 1)
                                                            }
                                                            }
                                                        }
                                                    }, 500)
                                                }
                                                waitForGasLoginResult(0)
                                            }
                                            else -> {
                                                busy = false
                                                message = "Газ: проверяем результат входа…"
                                                onStatus("Проверка входа")
                                            }
                                        }
                                    }
                                } else if (!gasInitialPrepared) {
                                    gasInitialPrepared = true
                                    message = "Газ: готовим поля входа…"
                                    onStatus("Подготовка входа")
                                    webViewRef = view
                                    // The script itself polls for the JSF controls every 100 ms.
                                    // Start immediately after page load.
                                    startGasAutoLogin(view)
                                }
                            } else {
                                message = "Страница загружена. Подготовка передачи…"
                                view.postDelayed({ webViewRef = view; runFillAndSend() }, 1800)
                                view.postDelayed({ if (!confirmed) { busy = false; webViewRef = view; runFillAndSend() } }, 3000)
                                view.postDelayed({ if (!confirmed) { busy = false; webViewRef = view; runFillAndSend() } }, 6000)
                            }
                        }
                    }
                }
                if (job.type == MeterType.GAS) {
                    // Gas gets an isolated cookie jar per apartment. We still keep the
                    // WebView cache, but restore only this apartment's saved session.
                    // That makes repeat opens fast without leaking apartment A's session
                    // into apartment B.
                    val savedCookies = store.gasCookies(job.apartmentId)
                    val cm = android.webkit.CookieManager.getInstance()
                    cm.removeAllCookies {
                        val parts = savedCookies.split(';').map { it.trim() }.filter { it.contains('=') }
                        if (parts.isEmpty()) {
                            cm.flush()
                            post { loadUrl(url) }
                        } else {
                            var left = parts.size
                            parts.forEach { cookie ->
                                cm.setCookie(GAS, cookie) {
                                    left--
                                    if (left == 0) {
                                        cm.flush()
                                        post { loadUrl(url) }
                                    }
                                }
                            }
                        }
                    }
                } else {
                    loadUrl(url)
                }
            }
            }, modifier = Modifier.fillMaxSize())
    }
}

